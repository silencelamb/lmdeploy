# GLM-5.3 full R11 validation data

These runs use synthetic prompts, real weights and eight H200s. The current integration sources and the analysis command are in LMDeploy PR #5195. The separate kernel kit is pinned in the PR's Full R11 guide.

For example, use analyze_full_r11.py with --device device-current-final --serving http-final. The device-frozen run restores a real prefill produced by the historical environment. The device-original-env run uses the new code and builds that prefill anew. The device-rebuilt run compares an independently recompiled kit against the device-frozen stock oracle. Each 512-step digest is over native BF16 vocabulary bytes. Each rank's timing JSON includes every device timestamp.

The compact CUPTI files retain all positive-duration GPU kernels and memory activities from the diagnostic windows in Chrome trace format, in relative microseconds. The http-final control traces two GPU boundaries per selected step. The http-warm-routes diagnostic also records the actual physical per-expert loads. Its first timer entry is the reused startup warmup graph's synthetic call, so use --startup-samples 1 with these older dumps. The final timer-only collection records the warmup count in warmup-rank files. The http-plain run contains uninstrumented streaming arrivals and generated token IDs.
