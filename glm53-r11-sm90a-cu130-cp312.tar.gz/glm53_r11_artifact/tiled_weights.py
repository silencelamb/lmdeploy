# Copyright (c) OpenMMLab. All rights reserved.
"""Lossless [expert, N/256, K/128, 256, 128] FP8 storage with SW128."""

import torch
import triton
import triton.language as tl


@triton.jit
def rearrange(X, Y, SIZE: tl.constexpr, N: tl.constexpr, K: tl.constexpr,
              INVERSE: tl.constexpr, KMAJOR: tl.constexpr, BLOCK: tl.constexpr):
    i = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    row = i // 128
    col = (i % 128) ^ ((row % 8) * 16)
    nr = row % 256
    if KMAJOR:
        nb = (row // 256) % (N // 256)
        kb = (row // (256 * (N // 256))) % (K // 128)
    else:
        kb = (row // 256) % (K // 128)
        nb = (row // (256 * (K // 128))) % (N // 256)
    e = row // (256 * (K // 128) * (N // 256))
    logical = ((e * N + nb * 256 + nr) * K + kb * 128 + col).to(tl.int64)
    if INVERSE:
        tl.store(Y + logical, tl.load(X + i, i < SIZE, 0), i < SIZE)
    else:
        tl.store(Y + i, tl.load(X + logical, i < SIZE, 0), i < SIZE)


def convert_pair(pair, inverse=False, kmajor=False):
    weight, scale = pair
    assert weight.ndim == scale.ndim == 3 and weight.is_contiguous() and scale.is_contiguous()
    assert weight.dtype == torch.float8_e4m3fn and scale.dtype == torch.float32
    packed = torch.empty_like(weight)
    rearrange[(triton.cdiv(weight.numel(), 1024),)](
        weight.view(torch.uint8),
        packed.view(torch.uint8),
        weight.numel(),
        weight.shape[1],
        weight.shape[2],
        inverse,
        kmajor,
        1024,
    )
    if inverse:
        return packed, scale.clone()
    storage = torch.empty(scale.numel() + 2, dtype=torch.float32, device=scale.device)
    storage[:-2].copy_(scale.flatten())
    storage[-2:].view(torch.uint64).copy_(torch.tensor([packed.data_ptr()], dtype=torch.uint64, device=weight.device))
    packed._r4_tiled = True
    packed._glm53_tiled_order = "kmajor" if kmajor else "nmajor"
    return packed, storage[:-2].view_as(scale)


def convert(weights, inverse=False, kmajor=False):
    return tuple(convert_pair(pair, inverse, kmajor) for pair in weights)
