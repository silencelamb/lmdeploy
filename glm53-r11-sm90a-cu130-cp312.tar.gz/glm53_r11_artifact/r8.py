# Copyright (c) OpenMMLab. All rights reserved.
"""Fixed SM90/B8 QKV tiles, FP32 routing and the EP8 planner inbox."""
import ctypes
import functools
import os
from pathlib import Path

import torch
import triton
import triton.language as tl

from .native import check


@functools.lru_cache
def _library(name, device):
    path = Path(os.environ['GLM53_R8_NATIVE_DIR'])
    lib = ctypes.CDLL(str(path / f'lib{name}.so'))
    if name in ('qkv', 'qkv_sink'):
        lib.qkv_init.argtypes = [ctypes.c_char_p]
        lib.qkv_launch.argtypes = [ctypes.c_void_p] * (5 if name == 'qkv_sink' else 4)
        check(lib.qkv_init(str(path / f'{name}.cubin').encode()))
    elif name in ('hc_packed', 'hc_deferred'):
        lib.hc_mono.argtypes = [ctypes.c_void_p] * 12 + [ctypes.c_int] * 2 + [
            ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p]
    elif name in ('mail', 'mail_sink'):
        lib.replica_prepare_map.argtypes = [ctypes.c_void_p] * (12 if name == 'mail_sink' else 11)
    else:
        raise ValueError(name)
    if name == 'hc_deferred':
        lib.hc_finish.argtypes = [ctypes.c_void_p] * 2
    return lib


@triton.jit
def _pack(W, P, B: tl.constexpr):
    i = tl.program_id(0) * B + tl.arange(0, B)
    tile = i // 8192
    n = tile // 4096 * 128 + tile % 128
    k = tile // 128 % 32
    row = i // 64 % 64
    col = i % 64 ^ ((row % 8) * 8)
    source = (n * 64 + row) * 4096 + k * 128 + (i // 4096 % 2) * 64 + col
    tl.store(P + i, tl.load(W + source))


def packed_qkv(attention):
    weight = attention.qkv_proj.weight
    key = (weight.data_ptr(), 0 if weight.is_inference() else weight._version)
    if getattr(attention, '_glm53_r8_key', None) != key:
        if torch.cuda.is_current_stream_capturing():
            raise RuntimeError('Warm up the packed GLM-5.3 QKV weights before capture.')
        if weight.shape != (24576, 4096) or not weight.is_contiguous() or weight.dtype != torch.bfloat16:
            raise ValueError('The R8 QKV reader requires contiguous BF16 [24576,4096].')
        packed = torch.empty_like(weight)
        _pack[(weight.numel() // 512,)](weight.view(torch.int16), packed.view(torch.int16), 512)
        attention._glm53_r8_packed = packed
        attention._glm53_r8_key = key
    return attention._glm53_r8_packed


def qkv(x, packed, sink=None):
    out = x.new_empty((8, 24576))
    args = [x.data_ptr(), packed.data_ptr(), out.data_ptr()]
    if sink is not None:
        args.append(sink.data_ptr())
    check(_library('qkv_sink' if sink is not None else 'qkv', x.device).qkv_launch(
        *args, torch.cuda.current_stream().cuda_stream))
    if sink is not None:
        sink._glm53_pending = False
    return out


def deferred_library(device):
    return _library('hc_deferred', device)


def finish_sink(comb):
    if getattr(comb, '_glm53_pending', False):
        check(deferred_library(comb.device).hc_finish(comb.data_ptr(), torch.cuda.current_stream().cuda_stream))
        comb._glm53_pending = False


def hint_library(device):
    return _library('hc_packed', device)


def prepare_mailbox(replica, tensors):
    if getattr(replica, '_mail_ptrs', None) is None:
        if torch.cuda.is_current_stream_capturing():
            raise RuntimeError('Warm up the EP8 planner inbox before capture.')
        import torch.distributed._symmetric_memory as symm

        inbox = symm.empty(145, device=replica.work.device, dtype=torch.int64)
        inbox.zero_()
        # Two banks of 8 x 9 tagged words. Slot 144 is this rank's local
        # sequence number, independent of any interleaved R7 invocations.
        torch.cuda.synchronize()
        handle = symm.rendezvous(inbox, replica._r8_ep_group)
        peers = torch.tensor([*handle.buffer_ptrs, replica.rank], device=inbox.device, dtype=torch.uint64)
        replica._mail_inbox = inbox
        replica._mail_handle = handle
        replica._mail_ptrs = torch.cat((replica.ptrs, peers))
    hidden, weights, ids, x, xs, ws, work, _, out, loads = tensors
    args = (hidden, weights, ids, x, xs, ws, work, replica._mail_ptrs, out, loads)
    sink = getattr(ids, '_glm53_sink', None)
    pointers = [a.data_ptr() for a in args]
    if sink is not None:
        pointers.append(sink.data_ptr())
    check(_library('mail_sink' if sink is not None else 'mail', hidden.device).replica_prepare_map(
        *pointers, torch.cuda.current_stream().cuda_stream))
    if sink is not None:
        sink._glm53_pending = False


@triton.jit
def _select(Logits, Bias, Weights, Ids):
    row = tl.program_id(0)
    i = tl.arange(0, 512)
    x = tl.load(Logits + row * 288 + i, i < 288, 0.)
    bias = tl.load(Bias + i, i < 288, 0.)
    score = tl.sigmoid(x)
    choice = score + bias
    k = tl.arange(0, 8)
    # Mirror the baseline's repeated argmax for exceptional scores.
    bits = choice.to(tl.uint32, bitcast=True)
    if tl.max(((i < 288) & ((bits & 0x7f800000) == 0x7f800000)).to(tl.int32), 0):
        candidates = tl.where(i < 288, choice, -float('inf'))
        ids = tl.zeros((8,), tl.int32)
        raw = tl.zeros((8,), tl.float32)
        for rank in range(8):
            expert = tl.argmax(candidates, 0)
            weight = tl.sum(tl.where(i == expert, score, 0.), 0)
            ids += tl.where(k == rank, expert, 0)
            raw += tl.where(k == rank, weight, 0.)
            candidates = tl.where(i == expert, -float('inf'), candidates)
    else:
        bits = tl.where(choice == 0., 0, bits).to(tl.uint32)
        order = tl.where((bits >> 31) != 0, ~bits, bits ^ 0x80000000)
        key = (order.to(tl.uint64) << 32) | (511 - i).to(tl.uint64)
        winners = tl.topk(tl.where(i < 288, key, 0), 8)
        ids = (511 - (winners.to(tl.uint32) & 511)).to(tl.int32)
        raw = tl.gather(score, ids, 0)
    # The reference FP32 reduction uses XOR strides 4, 2, 1. A generic
    # tl.sum after topk may choose a different order for this output layout.
    denom = raw + tl.gather(raw, k ^ 4, 0)
    denom = denom + tl.gather(denom, k ^ 2, 0)
    denom = denom + tl.gather(denom, k ^ 1, 0)
    tl.store(Weights + row * 8 + k, raw / (denom + 1.e-20))
    tl.store(Ids + row * 8 + k, ids)


def select(logits, bias):
    w = logits.new_empty((8, 8))
    ids = w.new_empty((8, 8), dtype=torch.int64)
    _select[(8,)](logits, bias, w, ids, num_warps=4)
    return w, ids
