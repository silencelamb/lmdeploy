"""A: whole-step GPU loop. Device graph tasks retain all original operator bodies.

Explicit limitation: this is a GPU-controlled execution prototype, not one fused
computation kernel. Both host-loop and GPU-loop controls use the same step graph.
"""
import ctypes
import os
import time
from pathlib import Path
import torch
import torch.distributed as dist
import triton
import triton.language as tl

_LIB=None

def library():
    global _LIB
    if _LIB is None:
        candidates=[Path(__file__).resolve().parents[1]/'vendor/whole_step/libdevice_loop.so',
                    Path(__file__).resolve().parent/'native/whole_step/libdevice_loop.so']
        if os.environ.get('GLM53_DEVICE_LOOP_LIBRARY'):
            candidates.insert(0,Path(os.environ['GLM53_DEVICE_LOOP_LIBRARY']))
        p=next((p for p in candidates if p.is_file()),None)
        if p is None:raise RuntimeError('Run build_device_loop.py, or set GLM53_DEVICE_LOOP_LIBRARY.')
        _LIB=ctypes.CDLL(str(p))
        for name in ('mark_start','mark_finish'):
            getattr(_LIB,name).argtypes=[ctypes.c_void_p]*3
        _LIB.instantiate.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_void_p),ctypes.c_void_p,ctypes.c_int,ctypes.c_char_p]
        _LIB.launch.argtypes=[ctypes.c_void_p]*2
        _LIB.destroy.argtypes=[ctypes.c_void_p]
        _LIB.error_string.restype=ctypes.c_char_p
    return _LIB

def check(code):
    if code:raise RuntimeError(f'CUDA device graph: {code}: {library().error_string(code).decode()}')

@triton.jit
def _record(CONTROL, IDS, LOGITS, TOKENS, SAVED, N:tl.constexpr, LOGIT_STEPS:tl.constexpr, B:tl.constexpr=1024):
    i=tl.load(CONTROL)
    x=tl.program_id(0)*B+tl.arange(0,B)
    if i<LOGIT_STEPS:
        v=tl.load(LOGITS+x,x<N,other=0)
        tl.store(SAVED+i*N+x,v,x<N)
    if tl.program_id(0)==0:
        t=tl.arange(0,8)
        tl.store(TOKENS+i*8+t,tl.load(IDS+t))

class Executable:
    def __init__(self,graph,device=True,dot=None):
        self.graph=graph
        self.handle=ctypes.c_void_p()
        self.lib=library()
        check(self.lib.instantiate(graph.raw_cuda_graph(),ctypes.byref(self.handle),torch.cuda.current_stream().cuda_stream,int(device),str(dot).encode() if dot else None))
    def replay(self):check(self.lib.launch(self.handle,torch.cuda.current_stream().cuda_stream))
    def close(self):
        if self.handle.value:
            check(self.lib.destroy(self.handle));self.handle=ctypes.c_void_p()


def execute(agent,initial,restore,spec,outdir,rank):
    from lmdeploy.pytorch.compact_state import SSMStateMetadata
    steps=int(spec['steps']);keep=int(spec.get('logit_steps',4))
    self_loop=spec['whole_step']=='gpu'
    current=initial.clone(input_ids=initial.input_ids.clone(),history_lengths=initial.history_lengths.clone(),
        max_kv_seqlen=initial.max_kv_seqlen+steps+1,sum_kv_seqlen=(initial.max_kv_seqlen+steps+1)*8)
    m=initial.ssm_state_meta
    if m is not None:
        current=current.clone(ssm_state_meta=SSMStateMetadata(m.state_ids.clone(),m.input_state_ids.clone(),m.output_state_ids.clone(),partial_bank=m.partial_bank))
    def reset_inputs():
        current.input_ids.copy_(initial.input_ids);current.history_lengths.copy_(initial.history_lengths)
        if m is not None:
            for n in ('input_state_ids','output_state_ids'):
                getattr(current.ssm_state_meta,n).copy_(getattr(m,n))
    restore();reset_inputs()
    out=agent._forward_impl(current)
    logits=agent.get_logits(out['hidden_states'])
    # All kernels, including argmax/state advancement, must be warmed before capture.
    next_ids=logits.argmax(-1).reshape(-1)
    current.step(next_ids,ssm_state_cursor=agent.ssm_state_cursor)
    control=torch.zeros(4,dtype=torch.int64,device='cuda')
    starts=torch.empty(steps,dtype=torch.int64,device='cuda');ends=torch.empty_like(starts)
    token_buffer=torch.empty(steps,8,dtype=torch.long,device='cuda')
    saved=torch.empty((keep,*logits.shape),dtype=logits.dtype,device='cuda')
    _record[(triton.cdiv(logits.numel(),1024),)](control,next_ids,logits,token_buffer,saved,logits.numel(),keep)
    restore();reset_inputs()
    lib=library();stream=torch.cuda.current_stream().cuda_stream
    graph=torch.cuda.CUDAGraph(keep_graph=True)
    # cudaGraphLaunch cannot itself be captured. Inline the same prepared
    # model callable into the enclosing graph instead of replaying a child.
    from lmdeploy.pytorch.backends.cuda.graph_runner.full_graph import CUDASingleGraphRunner
    original_forward=CUDASingleGraphRunner.forward
    def inline_forward(runner, **kwargs):
        if not torch.cuda.is_current_stream_capturing():
            return original_forward(runner, **kwargs)
        padded=runner._bind_inputs(**kwargs)
        output=runner._model_forward(**padded)
        buffers=runner.model.make_output_buffers(output)
        return runner.model.get_outputs_cudagraph(buffers, **kwargs)
    CUDASingleGraphRunner.forward=inline_forward
    try:
        with torch.cuda.graph(graph,stream=torch.cuda.current_stream(),capture_error_mode='thread_local'):
            check(lib.mark_start(control.data_ptr(),starts.data_ptr(),stream))
            out=agent._forward_impl(current)
            logits=agent.get_logits(out['hidden_states'])
            next_ids=logits.argmax(-1).reshape(-1)
            nxt=current.step(next_ids,ssm_state_cursor=agent.ssm_state_cursor)
            _record[(triton.cdiv(logits.numel(),1024),)](control,next_ids,logits,token_buffer,saved,logits.numel(),keep)
            current.input_ids.copy_(nxt.input_ids)
            current.history_lengths.copy_(nxt.history_lengths)
            if m is not None:
                current.ssm_state_meta.input_state_ids.copy_(nxt.ssm_state_meta.input_state_ids)
                current.ssm_state_meta.output_state_ids.copy_(nxt.ssm_state_meta.output_state_ids)
            check(lib.mark_finish(control.data_ptr(),ends.data_ptr(),stream))
    finally:
        CUDASingleGraphRunner.forward=original_forward
    exe=Executable(graph,device=self_loop,dot=Path(outdir)/f"{spec['name']}_rank{rank}.dot")
    # Upload and a replay are outside timing. Run one step without tail recursion.
    restore();reset_inputs();control.copy_(torch.tensor([0,1,0,0],device='cuda'))
    exe.replay();torch.cuda.synchronize()
    restore();reset_inputs();control.copy_(torch.tensor([0,steps,int(self_loop),0],device='cuda'))
    torch.cuda.synchronize();dist.barrier()
    begin=torch.cuda.Event(enable_timing=True);end=torch.cuda.Event(enable_timing=True)
    wall=time.perf_counter();begin.record()
    timed=[];wall_steps=[]
    for _ in range(1 if self_loop else steps):
        if spec['whole_step']=='host_sync':
            a=torch.cuda.Event(enable_timing=True);b=torch.cuda.Event(enable_timing=True)
            t=time.perf_counter();a.record();exe.replay();b.record();b.synchronize()
            timed.append((a,b));wall_steps.append((time.perf_counter()-t)*1000)
        else:
            exe.replay()
    end.record();end.synchronize()
    elapsed=time.perf_counter()-wall;gpu=begin.elapsed_time(end)
    c=control.cpu().tolist()
    assert c[0]==steps and c[3]==0,c
    span=(ends-starts).double().cpu()/1e6
    # Matched whole-loop GPU latency includes inter-step tail/admission gaps.
    report=dict(mode=spec['whole_step'],completed=c[0],device_error=c[3],gpu_loop_ms=gpu,
        wall_loop_ms=elapsed*1000,step_body_ms=span.tolist(),starts_ns=starts.cpu().tolist(),ends_ns=ends.cpu().tolist(),
        scope='metadata + all 45 layers + LM head + argmax + token/position/cursor feedback + recording')
    import json
    (Path(outdir)/f"{spec['name']}_rank{rank}_whole_step.json").write_text(json.dumps(report,indent=2))
    exe.close()
    if timed:
        gpu_steps=[a.elapsed_time(b) for a,b in timed]
    else:
        gpu_steps=[gpu/steps]*steps
        wall_steps=[elapsed*1000/steps]*steps
    return gpu_steps,wall_steps,list(token_buffer.unbind()),list(saved.unbind()),elapsed
