# Copyright (c) OpenMMLab. All rights reserved.
import torch

from .kda_norm_kernel import fused_recurrent_gated_delta_rule_fwd


def forward(
    mixed_qkv,
    raw_gate,
    raw_beta,
    conv_weight,
    conv_bias,
    a_log,
    dt_bias,
    conv_state,
    recurrent_state,
    metadata,
    num_heads,
    head_dim,
    lower_bound,
    norm_gate,
    norm_weight,
    norm_eps,
):
    assert mixed_qkv.shape == (1, 8, 24576) and num_heads == 64 and head_dim == 128 and conv_bias is None
    assert conv_state.size(0) == recurrent_state.size(0) and conv_state.size(-1) == conv_weight.size(-1) - 1
    assert metadata.ssm_state_meta.output_state_ids.shape == (8, 1)
    mixed = torch.empty_like(mixed_qkv)
    q, k, v = [x.reshape(8, 1, 64, 128) for x in mixed.split(8192, -1)]
    out = torch.empty((8, 1, 64, 128), dtype=q.dtype, device=q.device)
    g = raw_gate.reshape(8, 1, 64, 128).contiguous()
    beta = raw_beta.reshape(8, 1, 64).contiguous()
    state = recurrent_state.unsqueeze(1)
    ids = metadata.ssm_state_meta
    kernel = fused_recurrent_gated_delta_rule_fwd(
        1,
        64,
        128,
        64,
        128,
        NUM_STATE=1,
        q_stride=q.stride(),
        k_stride=k.stride(),
        v_stride=v.stride(),
        state_stride=state.stride(),
        scale=128**-0.5,
        dtype=q.dtype,
        state_dtype=state.dtype,
        g_dtype=g.dtype,
        beta_dtype=beta.dtype,
        use_g=True,
        use_beta=True,
        use_qk_l2norm_in_kernel=True,
        output_final_state=True,
        use_state_indices=True,
        is_circular_buffer=True,
        transpose_state_layout=True,
        num_warps=4,
        channelwise_g=True,
        fuse_kda_gate=True,
        kda_lower_bound=lower_bound,
        has_dt_bias=True,
        use_output_state_indices=True,
        conv_stride=conv_state.stride(),
        conv_width=conv_weight.size(-1),
        norm_eps=norm_eps,
    )
    kernel(
        q,
        k,
        v,
        out,
        g,
        beta,
        state,
        ids.input_state_ids,
        None,
        ids.output_state_ids,
        a_log,
        dt_bias.reshape(64, 128),
        mixed_qkv.view(8, 24576),
        conv_state,
        conv_weight.view(24576, -1),
        norm_gate.reshape(8, 1, 64, 128).contiguous(),
        norm_weight,
    )
    return out.reshape(1, 8, 64, 128)
