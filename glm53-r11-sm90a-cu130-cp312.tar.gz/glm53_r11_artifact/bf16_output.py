# Copyright (c) OpenMMLab. All rights reserved.
import torch
import triton
from triton.experimental import gluon
from triton.experimental.gluon import language as gl
from triton.experimental.gluon.language.nvidia.hopper import (
    fence_async_shared,
    mbarrier,
    tma,
    warpgroup_mma,
    warpgroup_mma_wait,
)
from triton.experimental.gluon.nvidia.hopper import TensorDescriptor


@gluon.jit
def gemm_split(A, B, D, BUFFERS: gl.constexpr):
    n = gl.program_id(0)
    s = gl.program_id(1)
    BN: gl.constexpr = A.block_type.shape[0]
    BK: gl.constexpr = 64
    ash = gl.allocate_shared_memory(A.dtype, [BUFFERS] + A.block_type.shape, A.layout)
    bsh = gl.allocate_shared_memory(B.dtype, [BUFFERS] + B.block_type.shape, B.layout)
    bars = gl.allocate_shared_memory(gl.int64, [BUFFERS, 1], mbarrier.MBarrierLayout())
    count = gl.where(s == 2, 42, 43)
    for i in gl.static_range(BUFFERS):
        mbarrier.init(bars.index(i), count=1)
        mbarrier.expect(bars.index(i), A.block_type.nbytes + B.block_type.nbytes)
        tma.async_copy_global_to_shared(A, [n * BN, s * 2752 + i * BK], bars.index(i), ash.index(i))
        tma.async_copy_global_to_shared(B, [0, s * 2752 + i * BK], bars.index(i), bsh.index(i))
    layout: gl.constexpr = gl.NVMMADistributedLayout(version=[3, 0], warps_per_cta=[4, 1], instr_shape=[16, 8, 16])
    acc = gl.zeros((BN, 8), gl.float32, layout)
    for z in range(count):
        stage = z % BUFFERS
        phase = (z // BUFFERS) % 2
        mbarrier.wait(bars.index(stage), phase=phase)
        acc = warpgroup_mma(ash.index(stage), bsh.index(stage).permute((1, 0)), acc, is_async=True)
        acc = warpgroup_mma_wait(num_outstanding=0, deps=(acc,))
        if z + BUFFERS < count:
            mbarrier.expect(bars.index(stage), A.block_type.nbytes + B.block_type.nbytes)
            tma.async_copy_global_to_shared(
                A, [n * BN, s * 2752 + (z + BUFFERS) * BK], bars.index(stage), ash.index(stage)
            )
            tma.async_copy_global_to_shared(B, [0, s * 2752 + (z + BUFFERS) * BK], bars.index(stage), bsh.index(stage))
    sm = gl.allocate_shared_memory(D.dtype, D.block_type.shape, D.layout)
    sm.store(acc.permute((1, 0)))
    fence_async_shared()
    tma.async_copy_shared_to_global(D, [s * 8, n * BN], sm)
    tma.store_wait(pendings=0)
    for i in gl.static_range(BUFFERS):
        mbarrier.invalidate(bars.index(i))


@gluon.jit
def reduce(P, O, N: gl.constexpr, BLOCK: gl.constexpr):
    i = gl.program_id(0) * BLOCK + gl.arange(0, BLOCK, layout=gl.BlockedLayout([1], [32], [4], [0]))
    p0 = gl.load(P + i, i < N, 0)
    p1 = gl.load(P + N + i, i < N, 0)
    p2 = gl.load(P + 2 * N + i, i < N, 0)
    out = (p0 + p1) + p2
    gl.store(O + i, out.to(gl.bfloat16), i < N)


def forward(x, w, bn=64, buffers=4):
    assert x.shape == (8, 8192) and w.shape == (4096, 8192)
    p = torch.empty((24, 4096), dtype=torch.float32, device=x.device)
    out = torch.empty((8, 4096), dtype=x.dtype, device=x.device)
    desc = []
    for tensor, shape in [(w, [bn, 64]), (x, [8, 64]), (p, [8, bn])]:
        dtype = gl.float32 if tensor.dtype == torch.float32 else gl.bfloat16
        desc.append(TensorDescriptor.from_tensor(tensor, shape, gl.NVMMASharedLayout.get_default_for(shape, dtype)))
    gemm_split[(triton.cdiv(4096, bn), 3)](*desc, buffers, num_warps=4)
    reduce[(triton.cdiv(out.numel(), 256),)](p, out, out.numel(), 256, num_warps=4)
    return out
