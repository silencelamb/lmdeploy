# Copyright (c) OpenMMLab. All rights reserved.
"""Eight-token batched WGMMA, preserving each head's K accumulation order."""

import triton
from triton.experimental import gluon
from triton.experimental.gluon import language as gl
from triton.experimental.gluon.language.nvidia.hopper import (
    fence_async_shared,
    mbarrier,
    tma,
    warpgroup_mma,
    warpgroup_mma_wait,
)
from triton.experimental.gluon.nvidia.hopper import TensorDescriptor


@gluon.jit
def gemm(A, B, D, K: gl.constexpr, N: gl.constexpr, BUFFERS: gl.constexpr, HEAD_MAJOR: gl.constexpr):
    tile = gl.program_id(0)
    head = gl.program_id(1)
    BN: gl.constexpr = A.block_type.shape[0]
    BK: gl.constexpr = A.block_type.shape[1]
    ash = gl.allocate_shared_memory(A.dtype, [BUFFERS] + A.block_type.shape, A.layout)
    bsh = gl.allocate_shared_memory(B.dtype, [BUFFERS] + B.block_type.shape, B.layout)
    bars = gl.allocate_shared_memory(gl.int64, [BUFFERS, 1], mbarrier.MBarrierLayout())
    for i in gl.static_range(BUFFERS):
        mbarrier.init(bars.index(i), count=1)
        mbarrier.expect(bars.index(i), A.block_type.nbytes + B.block_type.nbytes)
        tma.async_copy_global_to_shared(A, [head * N + tile * BN, i * BK], bars.index(i), ash.index(i))
        tma.async_copy_global_to_shared(B, [0, head * K + i * BK], bars.index(i), bsh.index(i))
    layout: gl.constexpr = gl.NVMMADistributedLayout(version=[3, 0], warps_per_cta=[4, 1], instr_shape=[16, 8, 16])
    acc = gl.zeros((BN, 8), gl.float32, layout)
    for z in range(K // BK):
        stage = z % BUFFERS
        mbarrier.wait(bars.index(stage), phase=(z // BUFFERS) % 2)
        acc = warpgroup_mma(ash.index(stage), bsh.index(stage).permute((1, 0)), acc, is_async=True)
        acc = warpgroup_mma_wait(num_outstanding=0, deps=(acc,))
        if z + BUFFERS < K // BK:
            mbarrier.expect(bars.index(stage), A.block_type.nbytes + B.block_type.nbytes)
            tma.async_copy_global_to_shared(
                A, [head * N + tile * BN, (z + BUFFERS) * BK], bars.index(stage), ash.index(stage)
            )
            tma.async_copy_global_to_shared(B, [0, head * K + (z + BUFFERS) * BK], bars.index(stage), bsh.index(stage))
    sm = gl.allocate_shared_memory(D.dtype, D.block_type.shape, D.layout)
    sm.store(acc.to(D.dtype).permute((1, 0)))
    fence_async_shared()
    if HEAD_MAJOR:
        tma.async_copy_shared_to_global(D, [head * 8, tile * BN], sm)
    else:
        tma.async_copy_shared_to_global(D, [0, head * N + tile * BN], sm)
    tma.store_wait(pendings=0)
    for i in gl.static_range(BUFFERS):
        mbarrier.invalidate(bars.index(i))


def forward(x, weight, output, bn=64, bk=128, buffers=2, head_major=False):
    h, n, k = weight.shape
    assert x.shape == (8, h, k) and output.shape == ((h, 8, n) if head_major else (8, h, n))
    desc = []
    for tensor, shape in [
        (weight.reshape(h * n, k), [bn, bk]),
        (x.reshape(8, h * k), [8, bk]),
        (output.reshape(h * 8, n) if head_major else output.reshape(8, h * n), [8, bn]),
    ]:
        desc.append(
            TensorDescriptor.from_tensor(tensor, shape, gl.NVMMASharedLayout.get_default_for(shape, gl.bfloat16))
        )
    gemm[(triton.cdiv(n, bn), h)](*desc, k, n, buffers, head_major, num_warps=4)
    return output
