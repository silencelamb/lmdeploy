# Copyright (c) OpenMMLab. All rights reserved.
"""Indexed B8 KDA with convolution in the owning recurrence CTA.

The recurrence and its reduction order are inherited from gated_delta_rule.
The convolution retains FP32 ordered FMA, SiLU and the BF16 store boundary.
"""

from collections.abc import Sequence

import tilelang
import tilelang.language as T
import torch

from lmdeploy.pytorch.kernels.cuda.gated_delta_rule import (
    _shfl_sync,
    compute_output_tile,
    load_global_qk,
    load_shared_qk,
    load_transposed_state_tile,
    load_value_tile,
    precompute_shared_token_inputs,
    round_state_tile_to_cache_dtype,
    store_transposed_state_tile,
    update_recurrent_state,
    vec_store_output,
    zero_output_tile,
)

NORM_SOURCE = r"""#include <cuda_bf16.h>
extern "C" __device__ __forceinline__ int glm53_norm_gate(void* data,const void* gate,const void* weights,float eps) {
    auto x=reinterpret_cast<__nv_bfloat16*>(data);
    auto g=reinterpret_cast<const __nv_bfloat16*>(gate);
    auto w=reinterpret_cast<const __nv_bfloat16*>(weights);
    __shared__ float reciprocal;
    int tid=threadIdx.x;
    if(tid<16) {
        float values[8];
        #pragma unroll
        for(int j=0;j<8;j++)values[j]=__bfloat162float(x[tid*8+j]);
        float sum=__fmul_rn(values[1],values[1]);
        sum=__fmaf_rn(values[0],values[0],sum);
        #pragma unroll
        for(int j=2;j<8;j++)sum=__fmaf_rn(values[j],values[j],sum);
        #pragma unroll
        for(int delta=8;delta;delta>>=1)sum=__fadd_rn(sum,__shfl_xor_sync(0xffff,sum,delta));
        if(tid==0) {
            float variance;
            asm("div.full.f32 %0, %1, %2;":"=f"(variance):"f"(sum),"f"(128.f));
            float input=__fadd_rn(variance,eps),root;
            asm("sqrt.approx.ftz.f32 %0, %1;":"=f"(root):"f"(input));
            asm("div.full.f32 %0, %1, %2;":"=f"(reciprocal):"f"(1.f),"f"(root));
        }
    }
    __syncthreads();
    float exponent=__fmul_rn(__fsub_rn(0.f,__bfloat162float(g[tid])),__int_as_float(0x3fb8aa3b));
    float e,sigmoid;
    asm("ex2.approx.f32 %0, %1;":"=f"(e):"f"(exponent));
    float denominator=__fadd_rn(e,1.f);
    asm("div.full.f32 %0, %1, %2;":"=f"(sigmoid):"f"(1.f),"f"(denominator));
    float value=__fmul_rn(__fmul_rn(__bfloat162float(x[tid]),reciprocal),__bfloat162float(w[tid]));
    x[tid]=__float2bfloat16_rn(__fmul_rn(value,sigmoid));
    return 0;
}

extern "C" __device__ float __nv_expf(float);
"""


@tilelang.jit(
    pass_configs={
        tilelang.PassConfigKey.TL_ENABLE_FAST_MATH: True,
    },
)
def fused_recurrent_gated_delta_rule_fwd(
    SEQLEN,
    H,
    K,
    HV,
    V,
    NUM_STATE,
    q_stride: Sequence[int],
    k_stride: Sequence[int],
    v_stride: Sequence[int],
    state_stride: Sequence[int],
    scale,
    dtype,
    state_dtype,
    g_dtype=None,
    beta_dtype=None,
    use_g: bool = False,
    use_beta: bool = False,
    use_qk_l2norm_in_kernel: bool = False,
    output_final_state: bool = False,
    use_state_indices: bool = False,
    is_circular_buffer: bool = False,
    transpose_state_layout: bool = False,
    num_warps: int = 1,
    channelwise_g: bool = False,
    fuse_kda_gate: bool = False,
    kda_lower_bound: float = -5.0,
    has_dt_bias: bool = False,
    use_output_state_indices: bool = False,
    conv_stride=(0, 0, 0),
    conv_width: int = 4,
    norm_eps: float = 1e-5,
):
    """Build the layout-specific recurrent GDR TileLang kernel.

    Common compile-time metadata is computed once here. The only structural branch is the returned T.prim_func body,
    because default and transposed state layouts use different state IO strategies.
    """

    num_threads = num_warps * 32
    state_num_bits = T.DataType(state_dtype).bits
    data_num_bits = T.DataType(dtype).bits
    state_vec_width = 128 // state_num_bits
    data_vec_width = 128 // data_num_bits
    warp_size = 32
    k_per_thr = T.ceildiv(K, warp_size)
    v_per_warp = max(state_vec_width, data_vec_width, 8)
    # One indexed AR output uses the legacy AR tile geometry. Treating it as
    # a speculative ring needlessly changes occupancy just to change addresses.
    if is_circular_buffer and not (use_output_state_indices and SEQLEN == 1):
        # Circular buffer writes state to global memory at every timestep.
        # The transposed path can use smaller V tiles because its state IO is
        # already coalesced and benefits more from lower register pressure.
        min_v_per_warp = v_per_warp
        max_v_per_warp = 128 // k_per_thr
        if transpose_state_layout:
            max_v_per_warp = min(max_v_per_warp, 8 if state_num_bits <= 16 else 16)
        desired = T.ceildiv(V, num_warps)
        v_per_warp = T.ceildiv(min(desired, max_v_per_warp), min_v_per_warp) * min_v_per_warp
        v_per_warp = max(v_per_warp, min_v_per_warp)
        # Channelwise KDA has independent V tiles. Distribute them across
        # CTAs instead of serial state waves, especially for small batches.
        target_v_per_cta = v_per_warp * num_warps if channelwise_g and K == V == 128 else V
    else:
        target_v_per_cta = max(V, v_per_warp * num_warps * 2)

    data_vw = min(data_vec_width, v_per_warp)
    num_waves = T.ceildiv(target_v_per_cta, v_per_warp * num_warps)
    v_per_cta = v_per_warp * num_warps * num_waves
    use_shared_token_inputs = SEQLEN <= 8 and not channelwise_g
    write_circular_state = output_final_state and is_circular_buffer
    write_final_state = output_final_state and not is_circular_buffer
    roundtrip_state_between_tokens = state_dtype != torch.float32

    B = T.dynamic("B")
    N = B if not use_state_indices else T.dynamic("N")
    g_shape = [B, SEQLEN, HV, K] if channelwise_g else [B, SEQLEN, HV]

    if g_dtype is None:
        g_dtype = dtype
    if beta_dtype is None:
        beta_dtype = dtype

    @T.prim_func
    def fused_recurrent_gated_delta_rule_transposed_main(
        Query: T.StridedTensor([B, SEQLEN, H, K], dtype=dtype, strides=q_stride),
        Key: T.StridedTensor([B, SEQLEN, H, K], dtype=dtype, strides=k_stride),
        Value: T.StridedTensor([B, SEQLEN, HV, V], dtype=dtype, strides=v_stride),
        Out: T.Tensor([B, SEQLEN, HV, V], dtype=dtype),
        G: T.Tensor(g_shape, dtype=g_dtype),
        Beta: T.Tensor([B, SEQLEN, HV], dtype=beta_dtype),
        State: T.StridedTensor([N, NUM_STATE, HV, V, K], dtype=state_dtype, strides=state_stride),
        StateIndices: T.Tensor([B], dtype=torch.int64) = None,
        CacheSeqlens: T.Tensor([B], dtype=torch.int32) = None,
        OutputStateIndices: T.Tensor([B, SEQLEN], dtype=torch.int64) = None,
        ALog: T.Tensor([HV], dtype=torch.float32) = None,
        DtBias: T.Tensor([HV, K], dtype=torch.float32) = None,
        Mixed: T.Tensor([B, 3 * HV * K], dtype=dtype) = None,
        Conv: T.StridedTensor([N, 3 * HV * K, conv_width - 1], dtype=dtype, strides=conv_stride) = None,
        ConvWeight: T.Tensor([3 * HV * K, conv_width], dtype=torch.float32) = None,
        NormGate: T.Tensor([B, SEQLEN, HV, V], dtype=dtype) = None,
        NormWeight: T.Tensor([V], dtype=dtype) = None,
    ):
        with T.Kernel(T.ceildiv(V, v_per_cta), B * HV, threads=num_threads) as (v_start, bhv_idx):
            if fuse_kda_gate:
                T.import_source(NORM_SOURCE)
            tidx = T.get_thread_binding(0)
            b_id = bhv_idx // HV
            hv_id = bhv_idx % HV
            h_id = hv_id // (HV // H)
            warp_id = tidx // warp_size
            lane_id = tidx % warp_size
            k_off = lane_id * k_per_thr

            if use_state_indices:
                state_id = T.cast(StateIndices[b_id], T.int64)
            else:
                state_id = b_id

            if use_output_state_indices:
                state_seq_id = 0
                state_update_id = T.alloc_var(T.int32)
                state_update_id = 0
            elif is_circular_buffer:
                state_seq_id = CacheSeqlens[b_id] % NUM_STATE
                state_update_id = T.alloc_var(T.int32)
                state_update_id = (state_seq_id + 1) % NUM_STATE
            else:
                state_seq_id = 0
                state_update_id = 0

            if use_shared_token_inputs:
                q_smem = T.alloc_shared([SEQLEN, K], T.float32)
                k_smem = T.alloc_shared([SEQLEN, K], T.float32)
                g_exp_smem = T.alloc_shared([SEQLEN], T.float32)
            if use_shared_token_inputs or fuse_kda_gate:
                beta_smem = T.alloc_shared([SEQLEN], T.float32)

            if fuse_kda_gate:
                kda_decay_smem = T.alloc_shared([SEQLEN, K], T.float32)

            if state_id >= 0 and state_id < N:
                # One AR CTA owns all V channels of one (token, head).
                # Keep the original FP32 convolution FMAs and BF16 SiLU boundary.
                for role, c in T.Parallel(3, K):
                    channel = role * HV * K + hv_id * K + c
                    history = T.alloc_local([conv_width], T.float32)
                    for j in T.Unroll(conv_width - 1):
                        history[j] = T.cast(Conv[state_id, channel, j], T.float32)
                    history[conv_width - 1] = T.cast(Mixed[b_id, channel], T.float32)
                    destination = T.cast(OutputStateIndices[b_id, 0], T.int64)
                    if destination > 0 and destination < N:
                        for j in T.Unroll(conv_width - 1):
                            Conv[destination, channel, j] = history[j + 1]
                    conv_value = T.alloc_var(T.float32)
                    conv_value = 0.0
                    for j in T.Unroll(conv_width):
                        conv_value += ConvWeight[channel, j] * history[j]
                    conv_value = T.sigmoid(conv_value) * conv_value
                    if role == 0:
                        Query[b_id, 0, hv_id, c] = conv_value
                    elif role == 1:
                        Key[b_id, 0, hv_id, c] = conv_value
                    else:
                        Value[b_id, 0, hv_id, c] = conv_value
                T.sync_threads()
                if use_shared_token_inputs:
                    precompute_shared_token_inputs(
                        Query,
                        Key,
                        G,
                        Beta,
                        q_smem,
                        k_smem,
                        g_exp_smem,
                        beta_smem,
                        b_id,
                        h_id,
                        hv_id,
                        warp_id,
                        k_off,
                        K,
                        SEQLEN,
                        k_per_thr,
                        scale,
                        use_qk_l2norm_in_kernel,
                        use_g,
                        use_beta,
                    )
                elif fuse_kda_gate:
                    # Preserve PyTorch sigmoid rounding; reuse gates across state waves.
                    for s in T.Parallel(SEQLEN):
                        beta_smem[s] = T.ieee_frcp(
                            1.0 + T.call_extern("float32", "__nv_expf", -T.cast(Beta[b_id, s, hv_id], T.float32))
                        )
                    for s, c in T.Parallel(SEQLEN, K):
                        gate_value = T.alloc_var(T.float32)
                        gate_value = T.cast(G[b_id, s, hv_id, c], T.float32)
                        if has_dt_bias:
                            gate_value += DtBias[hv_id, c]
                        gate_value = kda_lower_bound / (1.0 + T.exp(-T.exp(ALog[hv_id]) * gate_value))
                        kda_decay_smem[s, c] = T.exp(gate_value)
                    T.sync_threads()

                for wave_id in range(num_waves):
                    v_warp_off = wave_id * num_warps * v_per_warp + warp_id * v_per_warp
                    v_off = v_start * v_per_cta + v_warp_off

                    h_local = T.alloc_local([k_per_thr, v_per_warp], T.float32)
                    if is_circular_buffer:
                        state_update_id = (state_seq_id + 1) % NUM_STATE

                    load_transposed_state_tile(
                        State, h_local, state_id, state_seq_id, hv_id, k_off, v_off, K, V, k_per_thr, v_per_warp
                    )

                    for seq_id in range(SEQLEN):
                        if use_output_state_indices:
                            write_state_id = T.cast(OutputStateIndices[b_id, seq_id], T.int64)
                            # Each CTA owns a disjoint state tile and has loaded
                            # its input before this loop. Only the final candidate
                            # may reuse an owner-authorized exclusive input.
                            write_valid = (
                                write_state_id > 0
                                and write_state_id < N
                                and (write_state_id != state_id or (seq_id == SEQLEN - 1))
                            )
                        else:
                            write_state_id = state_id
                            write_valid = True
                        q_local = T.alloc_local([k_per_thr], T.float32)
                        k_local = T.alloc_local([k_per_thr], T.float32)
                        if use_shared_token_inputs:
                            load_shared_qk(q_smem, k_smem, q_local, k_local, seq_id, k_off, K, k_per_thr)
                        else:
                            load_global_qk(
                                Query,
                                Key,
                                q_local,
                                k_local,
                                b_id,
                                seq_id,
                                h_id,
                                k_off,
                                K,
                                k_per_thr,
                                scale,
                                use_qk_l2norm_in_kernel,
                            )

                        g_exp = T.alloc_var(T.float32)
                        beta = T.alloc_var(T.float32)
                        if use_shared_token_inputs:
                            g_exp = g_exp_smem[seq_id]
                            beta = beta_smem[seq_id]
                        elif fuse_kda_gate:
                            g_exp = 1.0
                            beta = beta_smem[seq_id]
                        else:
                            if use_g and not channelwise_g:
                                if lane_id == 0:
                                    g = T.cast(G[b_id, seq_id, hv_id], T.float32)
                                    g_exp = T.exp(g)
                                else:
                                    g_exp = 0.0
                                g_exp = _shfl_sync(g_exp, 0)
                            else:
                                g_exp = 1.0
                            if use_beta:
                                if lane_id == 0:
                                    beta = T.cast(Beta[b_id, seq_id, hv_id], T.float32)
                                else:
                                    beta = 0.0
                                beta = _shfl_sync(beta, 0)
                            else:
                                beta = 1.0

                        v_local = T.alloc_local([v_per_warp], dtype)
                        load_value_tile(Value, v_local, b_id, seq_id, hv_id, v_off, V, v_per_warp, data_vw)
                        if channelwise_g:
                            g_local = T.alloc_local([k_per_thr], T.float32)
                            for j in T.Unroll(k_per_thr):
                                if fuse_kda_gate:
                                    g_local[j] = kda_decay_smem[seq_id, k_off + j]
                                else:
                                    g_local[j] = T.exp(T.cast(G[b_id, seq_id, hv_id, k_off + j], T.float32))
                            update_recurrent_state(
                                h_local, k_local, v_local, g_local, beta, k_per_thr, v_per_warp, channelwise_g=True
                            )
                        else:
                            update_recurrent_state(h_local, k_local, v_local, g_exp, beta, k_per_thr, v_per_warp)

                        if write_circular_state:
                            if write_valid:
                                store_transposed_state_tile(
                                    State,
                                    h_local,
                                    write_state_id,
                                    state_update_id,
                                    hv_id,
                                    k_off,
                                    v_off,
                                    K,
                                    V,
                                    k_per_thr,
                                    v_per_warp,
                                )

                        o_local = T.alloc_local([v_per_warp], dtype)
                        compute_output_tile(q_local, h_local, o_local, k_per_thr, v_per_warp)

                        if lane_id == 0:
                            vec_store_output(Out, o_local, b_id, seq_id, hv_id, v_off, V, v_per_warp, data_vw)

                        if roundtrip_state_between_tokens and write_circular_state and seq_id < SEQLEN - 1:
                            round_state_tile_to_cache_dtype(
                                h_local, k_off, v_off, K, V, k_per_thr, v_per_warp, state_dtype
                            )
                        if write_circular_state:
                            state_update_id = (state_update_id + 1) % NUM_STATE

                    if write_final_state:
                        store_transposed_state_tile(
                            State, h_local, state_id, state_update_id, hv_id, k_off, v_off, K, V, k_per_thr, v_per_warp
                        )
            else:
                zero_output_tile(
                    Out,
                    b_id,
                    hv_id,
                    v_start,
                    lane_id,
                    warp_id,
                    V,
                    SEQLEN,
                    num_waves,
                    num_warps,
                    v_per_warp,
                    v_per_cta,
                    data_vw,
                )

            T.sync_threads()
            T.evaluate(
                T.call_extern(
                    "int32",
                    "glm53_norm_gate",
                    T.address_of(Out[b_id, 0, hv_id, 0]),
                    T.address_of(NormGate[b_id, 0, hv_id, 0]),
                    T.address_of(NormWeight[0]),
                    norm_eps,
                )
            )

    return fused_recurrent_gated_delta_rule_transposed_main
