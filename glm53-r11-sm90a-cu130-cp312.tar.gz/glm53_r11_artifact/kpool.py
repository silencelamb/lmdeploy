# Copyright (c) OpenMMLab. All rights reserved.
import torch
import triton
import triton.language as tl
from triton.language.extra.cuda import libdevice

from lmdeploy.pytorch.kernels.cuda.kpool import _normalized_hadamard


@triton.jit
def fused(Q, Gate, O, W, ROWS: tl.constexpr, HEAD_FACTOR: tl.constexpr, SCALE: tl.constexpr, ROUND: tl.constexpr):
    rows = tl.program_id(0) * 4 + tl.arange(0, 4)
    d = tl.arange(0, 128)
    v = tl.load(Q + rows[:, None] * 128 + d[None, :], rows[:, None] < ROWS, 0).to(tl.float32)
    v = _normalized_hadamard(v, 128, 7).to(tl.bfloat16).to(tl.float32)
    scale = tl.maximum(tl.max(tl.abs(v), 1), 1e-4) * (1.0 / 448.0)
    if ROUND:
        scale = libdevice.exp2(libdevice.ceil(libdevice.log2(scale)))
    q = tl.minimum(tl.maximum(tl.div_rn(v, scale[:, None]), -448.0), 448.0)
    tl.store(O + rows[:, None] * 128 + d[None, :], q.to(tl.float8e4nv), rows[:, None] < ROWS)
    gate = tl.load(Gate + rows, rows < ROWS, 0)
    w = ((gate * HEAD_FACTOR) * scale) * SCALE
    tl.store(W + rows, w, rows < ROWS)


def query(indexer, hidden_states, q_lora):
    q = indexer.project_query(q_lora)[0]
    gates = indexer.weights_proj(hidden_states.float())[0]
    out = torch.empty(q.shape, dtype=torch.float8_e4m3fn, device=q.device)
    w = torch.empty(q.shape[:-1], dtype=torch.float32, device=q.device)
    fused[(triton.cdiv(w.numel(), 4),)](
        q,
        gates,
        out,
        w,
        w.numel(),
        indexer.n_heads**-0.5,
        indexer.softmax_scale,
        indexer.scale_fmt is not None,
        num_warps=4,
        enable_fp_fusion=False,
    )
    return out, w
