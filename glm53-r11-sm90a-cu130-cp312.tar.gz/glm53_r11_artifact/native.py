# Copyright (c) OpenMMLab. All rights reserved.
"""Small C-ABI launchers; each helper runs on the caller's CUDA stream."""

import ctypes
import functools
import os
from pathlib import Path

import torch


@functools.lru_cache
def library(name):
    directory = os.getenv("GLM53_DECODE_NATIVE_DIR")
    if directory is None:
        raise RuntimeError(
            "Set GLM53_DECODE_NATIVE_DIR to the output of benchmark/glm53_monokernel/build_decode_native.py."
        )
    if name == "hc_prefetch":
        directory = os.getenv("GLM53_HC_PREFETCH_NATIVE_DIR", directory)
    if name == "topk_r09":
        directory = os.environ["GLM53_R09_NATIVE_DIR"]
    path = Path(directory) / f"libglm53_{name}.so"
    lib = ctypes.CDLL(str(path))
    if name == "hc_mono":
        lib.hc_mono.argtypes = [ctypes.c_void_p] * 12 + [ctypes.c_int] * 2 + [ctypes.c_void_p]
        lib.hc_mono.restype = ctypes.c_int
    elif name == "hc_prefetch":
        lib.hc_mono.argtypes = (
            [ctypes.c_void_p] * 12 + [ctypes.c_int] * 2
            + [ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p]
        )
        lib.hc_mono.restype = ctypes.c_int
    elif name == "mla":
        lib.glm53_sparse_mla.argtypes = [ctypes.c_void_p] * 7 + [ctypes.c_int] * 9 + [ctypes.c_float, ctypes.c_void_p]
        lib.glm53_sparse_mla.restype = ctypes.c_int
    elif name == "bf16_qkv_cache":
        lib.qkv_init.argtypes = [ctypes.c_char_p]
        lib.qkv_init.restype = ctypes.c_int
        check(lib.qkv_init(str(Path(directory) / "bf16_qkv_cache.cubin").encode()))
        lib.qkv_launch.argtypes = [ctypes.c_void_p] * 4
        lib.qkv_launch.restype = ctypes.c_int
    elif name in ("topk_cluster", "topk_r09"):
        lib.glm53_topk.argtypes = [ctypes.c_void_p] * 3 + [ctypes.c_int] * 6 + [ctypes.c_void_p]
        lib.glm53_topk.restype = ctypes.c_int
    elif name.startswith("replica_"):
        lib.replica_prepare.argtypes = [ctypes.c_void_p] * 8
        lib.replica_map.argtypes = [ctypes.c_void_p] * 5
        lib.replica_prepare.restype = lib.replica_map.restype = ctypes.c_int
        if name in ("replica_pair_bitmap", "replica_pair_bitmap_r5"):
            lib.replica_prepare_map.argtypes = [ctypes.c_void_p] * 11
            lib.replica_prepare_map.restype = ctypes.c_int
    else:
        raise ValueError(name)
    return lib


def check(code):
    if code:
        raise RuntimeError(f"GLM-5.3 native CUDA launch failed: {code}")


def qkv_cache_first(x, weight):
    out = x.new_empty((8, 24576))
    check(
        library("bf16_qkv_cache").qkv_launch(
            x.data_ptr(), weight.data_ptr(), out.data_ptr(), torch.cuda.current_stream().cuda_stream
        )
    )
    return out


def stable_topk(scores, lengths, k):
    """Hopper cluster selection with stable ties and ascending output indices.

    Eight co-resident CTAs cooperate through distributed shared memory. Longer
    rows use the original ordered radix algorithm inside the leader CTA.
    """
    from lmdeploy.pytorch import envs

    variant = "topk_r09" if envs.glm53_r09_topk and scores.size(0) == 8 else "topk_cluster"
    output = torch.empty((scores.size(0), k), dtype=torch.int32, device=scores.device)
    check(
        library(variant).glm53_topk(
            scores.data_ptr(), lengths.data_ptr(), output.data_ptr(), scores.size(0),
            scores.size(1), scores.stride(0), k, -1, lengths.element_size() * 8,
            torch.cuda.current_stream().cuda_stream,
        )
    )
    return output


def hc_workspace(x):
    if torch.cuda.is_current_stream_capturing():
        raise RuntimeError("Warm up the GLM-5.3 mHC workspace before graph capture.")
    rows = x.numel() // 16384
    return (
        torch.empty((rows, 128, 32), device=x.device, dtype=torch.float32),
        torch.empty((rows, 32), device=x.device, dtype=torch.float32),
        torch.zeros(rows, device=x.device, dtype=torch.int32),
    )


def hc_pre(x, x32, weight, scale, base, norm_weight, buffers, prefetch_weight=None, defer_sink=False):
    out = x.new_empty((*x.shape[:-2], 4096))
    post = x32.new_empty((*x.shape[:-2], 4))
    comb = x32.new_empty((*x.shape[:-2], 4, 4))
    tensors = (x32, weight, *buffers, x, base, scale, norm_weight, out, post, comb)
    if defer_sink:
        from .r8 import deferred_library
        check(deferred_library(x.device).hc_mono(
            *[t.data_ptr() for t in tensors], 8, 1, prefetch_weight.data_ptr() if prefetch_weight is not None else 0,
            -1 if prefetch_weight is not None else 1, torch.cuda.current_stream().cuda_stream))
        comb._glm53_pending = True
        return out, post, comb
    if prefetch_weight is not None:
        if (x.numel() != 8 * 16384 or prefetch_weight.shape != (24576, 4096)
                or prefetch_weight.dtype != torch.bfloat16 or not prefetch_weight.is_contiguous()
                or prefetch_weight.device != x.device):
            raise ValueError("GLM-5.3 QKV prefetch requires fixed B8 BF16 decode operands.")
        from lmdeploy.pytorch import envs
        if envs.glm53_decode_r8:
            from .r8 import hint_library
            helper, hint_arg = hint_library(x.device), 128
        else:
            helper, hint_arg = library("hc_prefetch"), 1
        check(helper.hc_mono(
            *[t.data_ptr() for t in tensors], 8, 1, prefetch_weight.data_ptr(), hint_arg,
            torch.cuda.current_stream().cuda_stream
        ))
        return out, post, comb
    check(
        library("hc_mono").hc_mono(
            *[t.data_ptr() for t in tensors], x.numel() // 16384, 1, torch.cuda.current_stream().cuda_stream
        )
    )
    return out, post, comb


def sparse_mla(q, kv, indices, scale):
    out = torch.empty_like(q, memory_format=torch.contiguous_format)
    maximum = torch.empty(q.shape[:2], device=q.device, dtype=torch.float32)
    lse = torch.empty_like(maximum)
    # V-only splitting retains the original QK/online-softmax sequence. It
    # needs no intermediate logits allocation or inter-CTA rendezvous.
    check(
        library("mla").glm53_sparse_mla(
            q.data_ptr(),
            kv.data_ptr(),
            indices.data_ptr(),
            out.data_ptr(),
            maximum.data_ptr(),
            lse.data_ptr(),
            None,
            q.shape[0],
            kv.shape[0],
            indices.shape[-1],
            q.stride(0),
            q.stride(1),
            kv.stride(0),
            kv.stride(1),
            indices.stride(0),
            indices.stride(1),
            scale,
            torch.cuda.current_stream().cuda_stream,
        )
    )
    return out, maximum, lse
