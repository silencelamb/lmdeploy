"""Read-only progress for specific owned process handles and immutable results."""
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
JOBS={2586948:'run_short_after.py',2670246:'run_profile_after.py',2829756:'run_norm_profile_after.py'}
LABELS=['agents-norm-short-r0','agents-historical-profile-r0','agents-norm-profile-r0']
out={'processes':{},'matrices':{},'errors':[]}
for pid,name in JOBS.items():
    p=Path(f'/proc/{pid}')
    try:
        stat=(p/'stat').read_text().split();command=(p/'cmdline').read_bytes().decode()
        out['processes'][str(pid)]={'live':stat[2]!='Z' and str(ROOT/'scripts'/name) in command,'state':stat[2]}
    except FileNotFoundError:out['processes'][str(pid)]={'live':False,'state':'missing'}
for label in LABELS:
    p=ROOT/'results'/f'{label}-progress.json'
    try:
        d=json.loads(p.read_text())
        out['matrices'][label]={'complete':d['complete'],'pairs':len(d['blocks']),'planned':d['planned_pairs']}
        out['errors'] += [{'label':s['label'],'returncode':s['returncode']} for s in d['sessions'] if s['returncode']]
    except (FileNotFoundError,json.JSONDecodeError):out['matrices'][label]={'complete':False,'pairs':0,'planned':8 if label==LABELS[0] else 2}
for name in ['profile-queue-r0.json','norm-profile-queue-r0.json','short-queue-r0.json']:
    try:
        rows=json.loads((ROOT/'results'/name).read_text())
        out['errors'] += [{'queue':name,'step':r} for r in rows if r.get('returncode',0)]
    except (FileNotFoundError,json.JSONDecodeError):pass
for pid,label in zip(JOBS,LABELS):
    if not out['processes'][str(pid)]['live'] and not out['matrices'][label]['complete']:
        out['errors'].append({'label':label,'error':'Owned process is terminal or missing without a complete matrix; inspect retained logs'})
out['terminal']=not any(x['live'] for x in out['processes'].values())
print(json.dumps(out))
