"""Follow historical HTTP diagnosis with independent norm timing diagnosis."""
import argparse
import datetime
import json
import math
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[1]


def main():
    p=argparse.ArgumentParser();p.add_argument('--wait-pid',type=int,required=True);a=p.parse_args()
    proc=Path(f'/proc/{a.wait_pid}/stat');identity=proc.read_text().split()[21] if proc.exists() else None
    while proc.exists():
        fields=proc.read_text().split()
        if fields[21]!=identity or fields[2]=='Z':break
        time.sleep(5)
    steps=[]
    def run(label,args):
        command=[sys.executable,*map(str,args)];row={'label':label,'command':command,
            'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
        steps.append(row);print('START',label,flush=True)
        with (ROOT/'logs'/f'{label}-controller.log').open('x') as f:
            rc=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT).returncode
        row.update(returncode=rc,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        (ROOT/'results/norm-short-profile-queue-r1.json').write_text(json.dumps(steps,indent=2)+'\n')
        print('DONE',label,rc,flush=True);assert rc==0,rc
    label='agents-norm-short-profile-pilot-before-r1'
    run(label,[ROOT/'scripts/run_case.py','--arm','norm-before','--compiler','legacy','--label',label,
        '--timeout','2400','--',ROOT/'scripts/pipeline_profile_case.py','--label',label,
        '--model','/afs-weights/Agents-A1','--tokens','64','--pilot','--c1-repeats','2','--c4-repeats','2'])
    d=json.loads((ROOT/'results'/f'{label}.json').read_text())
    assert d['complete'] and d['warmup_qualified'] and d['measurement_qualified']
    assert len(d['profile_workers'])==2 and len(d['profile_drivers'])==1
    for w in d['profile_workers']:
        values=[r['device_enqueue_interval_ms'] for r in w['records'] if r['device_sampled']]
        assert w['teardown_phase']==255 and len(values)>10 and all(math.isfinite(v) and v>=0 for v in values)
    run('agents-norm-short-profile-r1-matrix',[ROOT/'scripts/run_profile_matrix.py','--comparison','agents-norm-short',
        '--blocks','2','--label','agents-norm-short-profile-r1'])
    run('agents-norm-short-profile-r1-analysis',[ROOT/'scripts/analyze_profile.py','--label','agents-norm-short-profile-r1',
        '--output',ROOT/'results/agents-norm-short-profile-r1-diagnosis.json'])


if __name__=='__main__':main()
