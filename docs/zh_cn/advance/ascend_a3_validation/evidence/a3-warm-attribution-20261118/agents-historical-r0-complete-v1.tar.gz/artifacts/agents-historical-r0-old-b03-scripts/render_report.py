"""Render observed performance only; pending/invalid work is never shown as passed."""
import argparse
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
CASES={
    'agents-historical-r0': ('Agents 历史迁移 HTTP，128 token', 'fb5de87a+3b909634 → 6421cefe', 'legacy'),
    'agents-current-r0': ('Agents 当前 PR HTTP，128 token', 'fb5de87a+3b909634 → 2ccf38a4', 'stack91'),
    'sage-current-r0': ('Sage 当前 PR HTTP MTP3，128 token', 'fb5de87a+3b909634 → 2ccf38a4', 'stack91'),
    'agents-norm-short-r0': ('Agents norm pipeline，64 token', '342db85e → 5f1b1b3c', 'legacy'),
    'agents-norm-r0': ('Agents norm pipeline，256 token', '342db85e → 5f1b1b3c', 'legacy'),
    'sage-norm-r0': ('Sage norm pipeline，64 token', '342db85e → 5f1b1b3c', 'legacy'),
}
NAMES={'throughput':'总吞吐 ↑','stream_tps_p50':'流式速度 p50 ↑','ttft_p50':'TTFT p50 ↓',
       'ttft_p95':'TTFT p95 ↓','tpot_p50':'TPOT p50 ↓'}
STATUS={'equivalent':'通过：等效','improved':'通过：改善','regression':'回退','inconclusive':'不确定'}


def main():
    p=argparse.ArgumentParser();p.add_argument('--output',required=True);a=p.parse_args()
    lines=['# A3充分预热性能复核（2026-11-18）','',
        '当前结论只取自本页的新配对测试；尚未完成、工作量不一致和区间过宽的项都不计为通过。',
        '保留默认CPU亲和性（包括CPU18）、原Ray await顺序、GC和全部慢样本。旧测量叙述另行归档，原始证据不改。','',
        '## 最新状态','',
        '| 比较 | 固定源码 | 依赖 | 状态 |','| --- | --- | --- | --- |']
    blocks=[]
    for label,(title,source,profile) in CASES.items():
        stat_path=ROOT/'results'/f'{label}-statistics.json'
        work_path=ROOT/'results'/f'{label}-work-audit.json'
        progress_path=ROOT/'results'/f'{label}-progress.json'
        progress=json.loads(progress_path.read_text()) if progress_path.exists() else None
        stats=json.loads(stat_path.read_text()) if stat_path.exists() else None
        work=json.loads(work_path.read_text()) if work_path.exists() else None
        if stats and work and work['qualified']:
            counts={s:sum(row['status']==s for group in stats['metrics'].values() for row in group.values()) for s in STATUS}
            state='；'.join(f'{STATUS[s]} {n}项' for s,n in counts.items() if n)
        elif progress and progress['complete']:
            state='已运行，等待统计/工作量审计'
        elif progress:
            state=f'尚未完成：{len(progress["blocks"])}/{progress["planned_pairs"]}配对；不计通过'
        else:state='待运行；不计通过'
        lines.append(f'| {title} | `{source}` | `{profile}` | {state} |')
        if not stats:continue
        section=['',f'## {title}','',f'Label：`{label}`；8个全新进程配对，AB/BA各4。',
            f'工作量审计：{"通过" if work and work["qualified"] else "尚未通过，下面时延仅作诊断"}。','',
            '| 并发 | 指标 | 配对变化中位数 | 配对95%区间 | 两侧block中位数之比变化 | 结论 |',
            '| --- | --- | ---: | --- | ---: | --- |']
        quantile_notes=[]
        for c,metrics in stats['metrics'].items():
            for key,row in metrics.items():
                lo,hi=row['paired_ci95_pct']
                decision=STATUS[row['status']] if work and work['qualified'] else '资格待确认'
                section.append(f'| C{c} | {NAMES[key]} | {row["paired_median_pct"]:+.2f}% | '
                    f'[{lo:+.2f}%, {hi:+.2f}%] | {row["ratio_of_block_medians_pct"]:+.2f}% | {decision} |')
            q=metrics['ttft_p95'];lo,hi=q['global_p95_ratio_ci95_pct']
            quantile_notes.extend(['',f'C{c}总体TTFT p95：{q["global_old_p95"]*1000:.2f} → '
                f'{q["global_new_p95"]*1000:.2f} ms；保持配对block的总体分位数变化95%区间 '
                f'[{lo:+.2f}%, {hi:+.2f}%]。该项与上表的逐block p95同时参与验收。',''])
        section.extend(quantile_notes)
        section.append(f'[逐对值及统计输入哈希](evidence/a3-warm-perf-20261118/{label}-statistics.json)；'
                       f'[工作量、缓存、预热和自重复审计](evidence/a3-warm-perf-20261118/{label}-work-audit.json)。')
        blocks.extend(section)
    lines.extend(['','## 比较与判据','',
        '- 历史Agents直接复用旧依赖，单独检验原dlinfer→native HTTP信号；当前交付两侧共同采用固定CANN9.1安装栈。',
        '- `legacy`：Triton-Ascend3.2.2 / NPUIR1.2；`stack91`：Triton-Ascend3.2.2.post2 / NPUIR2.0、NumPy1.26.4、Pandas2.2.3、Arrow25。两侧均Torch2.10.0、torch_npu2.10.0.post4、Ray2.48.0、Python3.12.13、CANN9.1.0。',
        '- Sage历史旧编译器有状态写回错误；本轮两侧共同采用正确编译器，不把错误输出的旧速度作为性能等效认证，也不将差别全归因于预热。',
        '- HTTP：同NPU0/1、TP2/BF16、graph、prefix ON、171输入/128输出token、greedy、thinking OFF、session262144、prefill8192、cache0.95、batch16。',
        '- norm：完整pipeline、prefix OFF、session8192、prefill256、cache0.5、batch8、thinking默认、分别64/256输出token；不能用此替代HTTP对照。',
        '- 每个新进程至少5个C1/2/3/4预热sweep，最后连续2个无新forward形状、graph capture、Triton compile调用或autotune bench；未直接观测厂商内部全部缓存。',
        '- 每侧每block测25次C1和8次C4，另有5个固定资格响应。输入/输出token、cache miss、跨进程自重复和无dlinfer的原生环境均需审计通过。',
        '- 以独立进程配对block为统计单位，10000次配对bootstrap、seed20261118；95%区间全部在±5%内才称等效，完全有利可判改善。不是“没有显著回退就算通过”。',
        '- HTTP流式速度保留历史定义`(输出token数−1)/(末次−首次非空SSE时间)`；norm沿原pipeline定义扣除首chunk token数，不能跨两层直接混合绝对值。',
        '- 全部失败、慢样本、启动及预热时长保留；pilot不计正式验收。',
        '', '[预先判据](evidence/a3-warm-perf-20261118/ACCEPTANCE.md)与原始运行脚本、环境、命令及日志随证据归档。'])
    lines.extend(blocks)
    output=Path(a.output);assert not output.exists();output.write_text('\n'.join(lines)+'\n')


if __name__=='__main__':main()
