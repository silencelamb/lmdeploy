"""Process-local instrumentation of the frozen GDN prefill path and sequence metadata."""
import ast
from collections import defaultdict
import hashlib
from importlib import import_module
import inspect
import time
from norm_crossover_worker import NormCrossoverWorker


class NormGdnWorker(NormCrossoverWorker):
    def norm_perf_setup(self):
        setup = super().norm_perf_setup()
        base = 'triton_ascend_kernels.attention.fla.'
        chunk = import_module(base+'chunk')
        utils = import_module(base+'utils')
        kkt = import_module(base+'chunk_scaled_dot_kkt')
        self._gdn_stats = defaultdict(lambda: [0,0,0])
        def record(label, fn, *args, **kwargs):
            if not self._record_norm_cost:
                return fn(*args, **kwargs)
            wall,cpu=time.perf_counter_ns(),time.thread_time_ns()
            result=fn(*args,**kwargs)
            d=self._gdn_stats[label]
            d[0]+=1
            d[1]+=time.perf_counter_ns()-wall
            d[2]+=time.thread_time_ns()-cpu
            return result
        def wrapped(fn, label):
            def run(*args, **kwargs):
                return record(label,fn,*args,**kwargs)
            return run
        sources={}
        def with_method_timers(fn, methods):
            source=inspect.getsource(fn)
            sources[fn.__qualname__]=hashlib.sha256(source.encode()).hexdigest()
            tree=ast.parse(source)
            class InstrumentCalls(ast.NodeTransformer):
                def visit_If(self, node):
                    self.generic_visit(node)
                    source_test = ast.unparse(node.test)
                    if fn.__name__=='causal_conv1d_fn' and source_test in ('cache_indices[i] == PAD_SLOT_ID','has_initial_state[i]'):
                        node.test=ast.copy_location(ast.Call(func=ast.Name(id='_timed_bool',ctx=ast.Load()),
                            args=[ast.Constant(source_test),node.test],keywords=[]),node.test)
                    return node
                def visit_Call(self, node):
                    self.generic_visit(node)
                    if isinstance(node.func,ast.Attribute) and node.func.attr in methods:
                        method=node.func.attr
                        return ast.copy_location(ast.Call(func=ast.Name(id='_timed_method',ctx=ast.Load()),
                            args=[ast.Constant(method),node.func,*node.args],keywords=node.keywords),node)
                    return node
            def timed_method(name, bound, *args, **kwargs):
                # Reading tensor.device does not enqueue work or copy metadata.
                return record('method.'+fn.__name__+'.'+name+'.'+bound.__self__.device.type,bound,*args,**kwargs)
            ns=dict(fn.__globals__,_timed_method=timed_method,
                    _timed_bool=lambda name,val:record('truth.'+name+'.'+val.device.type,bool,val))
            exec(compile(ast.fix_missing_locations(InstrumentCalls().visit(tree)),
                         inspect.getfile(fn),'exec'),ns)
            return ns[fn.__name__]
        indices=with_method_timers(utils.prepare_chunk_indices,{'tolist'})
        indices=wrapped(indices,'metadata.prepare_chunk_indices')
        kkt_fn=with_method_timers(kkt.chunk_scaled_dot_kkt_fwd,{'cpu','npu'})
        # Instrument its private globals as well as the other stages' imported aliases.
        kkt_fn.__globals__['prepare_chunk_indices']=indices
        chunk.chunk_scaled_dot_kkt_fwd=kkt_fn
        for name in ('cumsum','solve_tril','wy_fast','chunk_delta_h'):
            mod=import_module(base+name)
            assert mod.prepare_chunk_indices is utils.prepare_chunk_indices
            mod.prepare_chunk_indices=indices
        for name in ('chunk_local_cumsum','chunk_scaled_dot_kkt_fwd','solve_tril','recompute_w_u_fwd','chunk_gated_delta_rule_fwd_h','chunk_fwd_o'):
            setattr(chunk,name,wrapped(getattr(chunk,name),'stage.'+name))
        conv=import_module('lmdeploy.pytorch.kernels.ascend.triton_ops.causal_conv1d')
        conv_fn=with_method_timers(conv.causal_conv1d_fn,{'tolist'})
        conv_fn.__globals__['causal_conv1d_ref']=wrapped(conv.causal_conv1d_ref,'conv.reference')
        count=0
        for name,mod in self._norm_runner.model.named_modules():
            if name.endswith('.linear_attn'):
                impl=mod.conv1d.causal_conv1d_func.impl
                assert impl.causal_conv1d_fn is conv.causal_conv1d_fn
                impl.causal_conv1d_fn=wrapped(conv_fn,'conv.function')
                gdn=mod.gated_delta.impl
                gdn.forward=wrapped(gdn.forward,'gdn.forward')
                gdn.chunk_func=wrapped(gdn.chunk_func,'gdn.chunk')
                count+=1
        assert count==30
        setup['instrumented_source_sha256']=sources
        return setup

    def norm_perf_mode(self, mode, diagnostic=False):
        self._gdn_stats.clear()
        return super().norm_perf_mode(mode,diagnostic)

    def norm_perf_collect(self):
        result=super().norm_perf_collect()
        result['gdn_stats']=dict(self._gdn_stats)
        return result
