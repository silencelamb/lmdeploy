"""Diagnostic prefill crossover with a shared captured decode graph."""
import resource
import time

from norm_isolation_worker import NormIsolationWorker


class NormCrossoverWorker(NormIsolationWorker):
    def norm_perf_setup(self):
        setup = super().norm_perf_setup()
        runner = self._norm_runner
        self._norm_modes['old'] = self._norm_modes['new']
        self._detail_calls = []

        def instrument(fn, name):
            def timed(*args, **kwargs):
                if not self._record_norm_cost or runner.ctx_mgr.current_context().global_is_decoding():
                    return fn(*args, **kwargs)
                wall = time.perf_counter_ns()
                cpu = time.thread_time_ns()
                result = fn(*args, **kwargs)
                self._detail_calls.append((name, time.perf_counter_ns()-wall, time.thread_time_ns()-cpu))
                return result
            return timed

        for name, module in runner.model.named_modules():
            if '.linear_attn.' in name and name.rsplit('.', 1)[1] in (
                    'in_proj_qkv', 'in_proj_z', 'in_proj_ba', 'conv1d', 'gated_delta', 'out_proj'):
                module.forward = instrument(module.forward, name)
        base = runner.__class__
        worker = self

        class ScheduledRunner(base):
            def __call__(inner, **kwargs):
                if not inner._perf_enabled or inner.ctx_mgr.current_context().global_is_decoding():
                    return super().__call__(**kwargs)
                with open('/proc/thread-self/schedstat') as stat:
                    before = [int(v) for v in stat.read().split()]
                    switches = resource.getrusage(resource.RUSAGE_THREAD)
                    cpu = time.thread_time_ns()
                    wall = time.perf_counter_ns()
                    result = super().__call__(**kwargs)
                    elapsed = time.perf_counter_ns() - wall
                    active = time.thread_time_ns() - cpu
                    switch_end = resource.getrusage(resource.RUSAGE_THREAD)
                    stat.seek(0)
                    after = [int(v) for v in stat.read().split()]
                worker._schedule.append(dict(wall_ns=elapsed, cpu_ns=active,
                    voluntary=switch_end.ru_nvcsw-switches.ru_nvcsw,
                    involuntary=switch_end.ru_nivcsw-switches.ru_nivcsw,
                    runqueue_ns=after[1]-before[1], timeslices=after[2]-before[2]))
                return result
        runner.__class__ = ScheduledRunner
        return setup

    def norm_perf_mode(self, mode, diagnostic=False):
        self._detail_calls = []
        self._schedule = []
        return super().norm_perf_mode(mode, diagnostic)

    def norm_perf_collect(self):
        record = super().norm_perf_collect()
        record.update(linear_detail=self._detail_calls, schedule=self._schedule)
        return record
