"""Append a diagnostic bullet after the existing A3 performance paragraph."""
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
label, commit, sentence = sys.argv[1:4]
endpoint = 'repos/InternLM/lmdeploy/pulls/5134'
def fetch():
    return json.loads(subprocess.check_output(['gh','api',endpoint,'-H','Cache-Control: no-cache']))
pr = fetch()
assert pr['head']['sha']=='2ccf38a43f0fdc7415ce4ce9f177852bdacc9966'
body = pr['body']
marker = '- **Ray/host latency:**'
assert body.count(marker)==1 and sentence not in body
link=f'https://github.com/silencelamb/lmdeploy/tree/{commit}/docs/zh_cn/advance/ascend_a3_validation/evidence/a3-warm-attribution-20261118'
new = body.replace(marker, f'- **A3 attribution:** {sentence} [Paired measurements, manifests and analysis]({link}).\n'+marker,1)
out = root/'artifacts'/label
out.mkdir(exist_ok=True)
(out/'pr-before-edit.md').write_text(body)
(out/'pr-after-edit.md').write_text(new)
payload=out/'pr-body.json'
payload.write_text(json.dumps({'body':new}))
assert fetch()['body']==body
subprocess.run(['gh','api',endpoint,'--method','PATCH','--input',str(payload),'--silent'],check=True)
verified = fetch()
assert verified['body']==new and verified['head']['sha']==pr['head']['sha']
(out/'pr-verified.json').write_text(json.dumps({'updated_at':verified['updated_at'],'head':pr['head']['sha'],'url':verified['html_url']},indent=2))
