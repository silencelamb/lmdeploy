"""Descriptive timing decomposition; never turn diagnostic runs into acceptance."""
import argparse
import collections
import json
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parents[1]


def summarize(rows,key):
    values=[r[key] for r in rows if key in r]
    if not values:return {'n':0}
    return {'n':len(values),'p50':float(np.median(values)),
            'p95':float(np.quantile(values,.95)),'max':max(values)}


def main():
    p=argparse.ArgumentParser();p.add_argument('--label',required=True);p.add_argument('--output',required=True)
    a=p.parse_args();progress=json.loads((ROOT/'results'/f'{a.label}-progress.json').read_text())
    assert progress['complete'] and progress['diagnostic_only']
    result={'scope':'Instrumented diagnosis only; not the primary performance acceptance',
            'device_scope':'NPU event interval around model enqueue includes host gaps; not pure kernel time',
            'cpu_scope':'Thread CPU activity across async await is not exclusive work of that function',
            'sessions':[]}
    for session in progress['sessions']:
        d=json.loads((ROOT/'results'/f'{session["label"]}.json').read_text())
        assert d['complete'] and d['measurement_qualified'] and len(d['profile_workers'])==2
        item={'label':session['label'],'block':session['block'],'side':session['side'],
              'workers':[],'driver':[]}
        for w in d['profile_workers']:
            groups=collections.defaultdict(list);slow=[];cross=0
            for row in w['records']:
                phase=d['phases'].get(str(row['phase']))
                if not phase or phase['kind']!='measure':continue
                if row['phase']!=row['end_phase']:cross+=1
                key=(phase['batch'],row['decoding'],row['input_tokens'])
                groups[key].append(row)
                if row['host_ms']>50 or row.get('device_enqueue_interval_ms',0)>50:
                    slow.append(row)
            summaries=[]
            for (bs,decode,tokens),rows in sorted(groups.items()):
                summaries.append({'phase_batch':bs,'decoding':decode,'input_tokens':tokens,
                    'records':len(rows),'host_ms':summarize(rows,'host_ms'),
                    'thread_cpu_activity_ms':summarize(rows,'thread_cpu_activity_ms'),
                    'device_enqueue_interval_ms':summarize(rows,'device_enqueue_interval_ms')})
            item['workers'].append({'rank':w['rank'],'pid':w['pid'],'teardown_phase':w['teardown_phase'],
                'cross_phase_records':cross,'groups':summaries,'slow_records':slow})
        for driver in d['profile_drivers']:
            groups=collections.defaultdict(list);slow=[]
            for row in driver['records']:
                phase=d['phases'].get(str(row['phase']))
                if not phase or phase['kind']!='measure':continue
                groups[(phase['batch'],row['name'],row['phase']==row['end_phase'])].append(row)
                if row['host_ms']>50:slow.append(row)
            item['driver'].append({'pid':driver['pid'],'groups':[
                {'phase_batch':bs,'name':name,'same_phase':same,
                 'host_ms':summarize(rows,'host_ms'),'thread_cpu_activity_ms':summarize(rows,'thread_cpu_activity_ms')}
                for (bs,name,same),rows in sorted(groups.items())], 'slow_records':slow})
        result['sessions'].append(item)
    path=Path(a.output);assert not path.exists();path.write_text(json.dumps(result,indent=2)+'\n')
    for session in result['sessions']:
        print(session['label'],'worker>50ms',sum(len(w['slow_records']) for w in session['workers']),
              'driver>50ms',sum(len(d['slow_records']) for d in session['driver']))


if __name__=='__main__':main()
