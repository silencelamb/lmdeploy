"""Run one owned process with fixed source/env, full affinity, and immutable labels."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]
REPOS = {
    'baseline': '/root/workspace/a3-validation-20261112/sources/lmdeploy-baseline',
    'native-history': '/root/workspace/a3-validation-20261112/sources/lmdeploy-native',
    'norm-before': str(ROOT / 'sources/norm-before'),
    'norm-after': str(ROOT / 'sources/norm-after'),
    'current': str(ROOT / 'sources/current'),
}


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--arm', choices=REPOS, required=True)
    p.add_argument('--compiler', choices=['legacy', 'ir2', 'stack91'], default='legacy')
    p.add_argument('--label', required=True)
    p.add_argument('--devices', default='0,1')
    p.add_argument('--timeout', type=int, default=2400)
    p.add_argument('args', nargs=argparse.REMAINDER)
    a = p.parse_args()
    role = 'baseline' if a.arm == 'baseline' else 'native'
    venv = ROOT / 'envs' / f'{role}-{a.compiler}'
    repo = REPOS[a.arm]
    env = os.environ.copy()
    env.pop('RAY_ADDRESS', None)
    cache = ROOT / 'artifacts' / f'triton-{a.arm}-{a.compiler}'
    observation = ROOT / 'artifacts' / f'{a.label}-observer'
    observation.mkdir()
    control = ROOT / 'artifacts' / f'{a.label}-phase.bin'
    assert not control.exists()
    control.write_bytes(b'\0')
    env.update(PYTHONPATH=f'{ROOT}/guard:{ROOT}/scripts:{repo}:/usr/local/Ascend/cann-9.1.0/python/site-packages:/usr/local/Ascend/cann-9.1.0/opp/built-in/op_impl/ai_core/tbe',
               PATH=str(venv / 'bin') + ':' + env['PATH'], VIRTUAL_ENV=str(venv),
               PYTHONNOUSERSITE='1', PYTHONDONTWRITEBYTECODE='1', TORCH_DEVICE_BACKEND_AUTOLOAD='0',
               PYTHONHASHSEED='42', VALIDATION_ENV=role, VALIDATION_ROOT=str(ROOT),
               WARM_ROLE=role, WARM_OBSERVER_DIR=str(observation), WARM_CONTROL_PATH=str(control),
               ASCEND_RT_VISIBLE_DEVICES=a.devices, OMP_NUM_THREADS='1', OMP_PROC_BIND='false',
               HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', TOKENIZERS_PARALLELISM='false',
               PYTHONUNBUFFERED='1', TASK_QUEUE_ENABLE='1', HCCL_CONNECT_TIMEOUT='180',
               HCCL_OP_EXPANSION_MODE='AIV', HCCL_BUFFSIZE='512',
               PYTORCH_NPU_ALLOC_CONF='expandable_segments:True', LMDEPLOY_TARGET_DEVICE='ascend',
               DEVICE='ascend', DLINFER_BUILD_DICP='OFF', RAY_OBJECT_STORE_ALLOW_SLOW_STORAGE='1',
               TRITON_CACHE_DIR=str(cache), RAY_TMPDIR='/tmp/w12-' + hashlib.sha256(a.label.encode()).hexdigest()[:10])
    args = a.args[1:] if a.args and a.args[0] == '--' else a.args
    command = [str(venv / 'bin/python'), *args]
    out = ROOT / 'logs' / f'{a.label}.log'
    meta = ROOT / 'logs' / f'{a.label}.json'
    assert not out.exists() and not meta.exists()
    record = {'command': command, 'cwd': repo, 'arm': a.arm, 'role': role,
              'compiler_profile': a.compiler, 'source_head': subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
              'source_diff_sha256': hashlib.sha256(subprocess.check_output(['git','diff','HEAD'],cwd=repo)).hexdigest(),
              'cpu_affinity': sorted(os.sched_getaffinity(0)), 'venv': str(venv),
              'start_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'environment': {k: v for k, v in env.items() if k in ['LD_PRELOAD','LD_LIBRARY_PATH'] or
                              k.startswith(('WARM_', 'ASCEND_', 'HCCL_', 'OMP_', 'PYTHON', 'TORCH_', 'TRITON_', 'RAY_', 'VALIDATION_'))},
              'scripts': {f.name: hashlib.sha256(f.read_bytes()).hexdigest() for f in (ROOT/'scripts').glob('*.py')}}
    meta.write_text(json.dumps(record, indent=2) + '\n')
    snapshot = ROOT / 'artifacts' / f'{a.label}-scripts'
    snapshot.mkdir()
    for source in (ROOT / 'scripts').glob('*.py'):
        shutil.copy2(source, snapshot / source.name)
    shutil.copytree(ROOT / 'guard', snapshot / 'guard')
    start = time.monotonic()
    with out.open('x') as log:
        child = subprocess.Popen(command, cwd=repo, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        record['pid'] = child.pid
        meta.write_text(json.dumps(record, indent=2) + '\n')
        try:
            rc = child.wait(timeout=a.timeout)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGTERM)
            try:
                child.wait(timeout=20)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
            rc = 124
    record.update(returncode=rc, elapsed_seconds=time.monotonic()-start,
                  end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    meta.write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'label': a.label, 'returncode': rc, 'seconds': record['elapsed_seconds']}))
    raise SystemExit(rc)


if __name__ == '__main__':
    main()
