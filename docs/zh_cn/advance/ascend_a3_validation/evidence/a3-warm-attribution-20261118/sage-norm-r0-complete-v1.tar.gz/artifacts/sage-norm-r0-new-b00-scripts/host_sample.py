"""Read-only host counters every2s; diagnostic coverage begins at collector start."""
import argparse
import json
import os
from pathlib import Path
import time


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--pids',type=int,nargs='+',required=True)
    p.add_argument('--wait-pid',type=int)
    p.add_argument('--output',required=True)
    a=p.parse_args()
    if a.wait_pid:
        process=Path(f'/proc/{a.wait_pid}/stat')
        initial=process.read_text().split()[21] if process.exists() else None
        while process.exists():
            fields=process.read_text().split()
            if fields[21]!=initial or fields[2]=='Z':break
            time.sleep(5)
    identities={pid:Path(f'/proc/{pid}/stat').read_text().split()[21] for pid in a.pids
                if Path(f'/proc/{pid}/stat').exists()}
    def alive(pid,identity):
        try:return Path(f'/proc/{pid}/stat').read_text().split()[21]==identity
        except FileNotFoundError:return False
    with open(a.output,'x') as f:
        f.write(json.dumps({'kind':'collector','pid':os.getpid(),'watch':identities,
            'clock_ticks':os.sysconf('SC_CLK_TCK'),'interval_seconds':2,
            'wall_time_ns':time.time_ns(),'monotonic_ns':time.monotonic_ns()})+'\n')
        while any(alive(pid,start) for pid,start in identities.items()):
            row={'kind':'sample','wall_time_ns':time.time_ns(),'monotonic_ns':time.monotonic_ns(),
                 'stat':Path('/proc/stat').read_text(),'softirqs':Path('/proc/softirqs').read_text(),
                 'loadavg':Path('/proc/loadavg').read_text()}
            f.write(json.dumps(row)+'\n');f.flush();time.sleep(2)


if __name__=='__main__':main()
