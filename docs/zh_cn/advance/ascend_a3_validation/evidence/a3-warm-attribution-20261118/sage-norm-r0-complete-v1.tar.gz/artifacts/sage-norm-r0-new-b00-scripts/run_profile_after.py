"""Run a pilot and two diagnostic process pairs after all primary matrices."""
import argparse
import datetime
import json
import math
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[1]


def main():
    p=argparse.ArgumentParser();p.add_argument('--wait-pid',type=int,required=True);a=p.parse_args()
    proc=Path(f'/proc/{a.wait_pid}/stat');identity=proc.read_text().split()[21] if proc.exists() else None
    while proc.exists():
        fields=proc.read_text().split()
        if fields[21]!=identity or fields[2]=='Z':break
        time.sleep(5)
    steps=[]
    def run(name,args):
        command=[sys.executable,*map(str,args)];print('START',name,flush=True)
        row={'label':name,'command':command,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
        steps.append(row)
        with (ROOT/'logs'/f'{name}-controller.log').open('x') as log:
            rc=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT).returncode
        row.update(returncode=rc,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        (ROOT/'results/profile-queue-r0.json').write_text(json.dumps(steps,indent=2)+'\n')
        print('DONE',name,rc,flush=True);assert rc==0,rc
    label='agents-profile-pilot-baseline-r0'
    run(label,[ROOT/'scripts/run_case.py','--arm','baseline','--compiler','legacy','--label',label,
        '--timeout','2400','--',ROOT/'scripts/http_profile_case.py','--label',label,
        '--model','/afs-weights/Agents-A1','--tokens','128','--mtp','0','--pilot',
        '--c1-repeats','2','--c4-repeats','2'])
    d=json.loads((ROOT/'results'/f'{label}.json').read_text())
    assert d['complete'] and d['measurement_qualified'] and d['warmup_qualified']
    assert len(d['profile_workers'])==2 and len(d['profile_drivers'])==1
    for w in d['profile_workers']:
        values=[x['device_enqueue_interval_ms'] for x in w['records'] if x['device_sampled']]
        assert w['teardown_phase']==255 and len(values)>=10 and all(math.isfinite(v) and v>=0 for v in values)
    run('agents-historical-profile-r0-matrix',[ROOT/'scripts/run_profile_matrix.py',
        '--comparison','agents-historical','--blocks','2','--label','agents-historical-profile-r0'])


if __name__=='__main__':main()
