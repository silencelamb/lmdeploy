"""Archive immutable run results/metadata/snapshots; retain full log hashes locally."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import tarfile

ROOT=Path(__file__).resolve().parents[1]


def digest(path):
    data=path.read_bytes()
    return {'path':str(path.relative_to(ROOT)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--matrix')
    p.add_argument('--cases',nargs='*',default=[])
    p.add_argument('--output',required=True)
    p.add_argument('--manifest',required=True)
    a=p.parse_args();labels=list(a.cases);paths=set()
    if a.matrix:
        progress=ROOT/'results'/f'{a.matrix}-progress.json'
        d=json.loads(progress.read_text());assert d['complete']
        labels += [s['label'] for s in d['sessions']]
        paths.add(progress)
        for suffix in ['statistics','work-audit','diagnosis']:
            path=ROOT/'results'/f'{a.matrix}-{suffix}.json'
            if path.exists():paths.add(path)
    assert labels
    manifest={'matrix':a.matrix,'cases':labels,'members':[],
              'full_service_logs':'Retained unchanged on A3; hashes below, not included in this public archive',
              'local_full_logs':[]}
    for label in labels:
        result=ROOT/'results'/f'{label}.json';meta=ROOT/'logs'/f'{label}.json'
        assert result.exists() and meta.exists(),label
        command_meta=json.loads(meta.read_text());assert 'returncode' in command_meta,'Run still active: '+label
        # Secrets must not be present in the recorded environment exported publicly.
        suspect=[k for k in command_meta.get('environment',{}) if any(w in k.upper() for w in ['PASSWORD','SECRET','AUTH_TOKEN','API_KEY'])]
        assert not suspect,(label,suspect)
        paths.update([result,meta])
        snapshot=ROOT/'artifacts'/f'{label}-scripts'
        paths.update(p for p in snapshot.rglob('*') if p.is_file() and p.suffix in ['.py','.md','.json'])
        observation=ROOT/'artifacts'/f'{label}-observer'
        paths.update(p for p in observation.glob('*') if p.is_file() and p.suffix in ['.json','.jsonl'])
        for log in (ROOT/'logs').glob(label+'*.log'):
            manifest['local_full_logs'].append(digest(log))
    output=Path(a.output);out_manifest=Path(a.manifest)
    assert not output.exists() and not out_manifest.exists()
    output.parent.mkdir(parents=True,exist_ok=True)
    with output.open('xb') as raw, gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=6) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as tar:
            for path in sorted(paths):
                entry=digest(path);manifest['members'].append(entry)
                info=tar.gettarinfo(str(path),arcname=entry['path'])
                info.mtime=0;info.uid=0;info.gid=0;info.uname='';info.gname=''
                with path.open('rb') as stream:tar.addfile(info,stream)
    data=output.read_bytes();manifest['archive']={'name':output.name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
    # Re-read every stored member to verify the public archive against source hashes.
    expected={m['path']:m for m in manifest['members']}
    with tarfile.open(output,'r:gz') as tar:
        for member in tar.getmembers():
            data=tar.extractfile(member).read();entry=expected.pop(member.name)
            assert len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256']
    assert not expected
    manifest['member_bytes_verified']=True
    out_manifest.write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps({'archive':manifest['archive'],'members':len(manifest['members']),'verified':True}))


if __name__=='__main__':main()
