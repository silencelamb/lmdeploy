"""Queue the short norm comparison after the existing owned serial suite."""
import argparse
import datetime
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[1]


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--wait-pid',type=int,required=True)
    a=p.parse_args()
    proc=Path(f'/proc/{a.wait_pid}/stat')
    identity=proc.read_text().split()[21] if proc.exists() else None
    while proc.exists() and proc.read_text().split()[21]==identity:
        time.sleep(5)
    pilot=json.loads((ROOT/'results/agents-norm-pilot-before-r0.json').read_text())
    assert pilot.get('complete') and pilot.get('warmup_qualified'), 'Norm pilot not ready'
    commands=[
        [sys.executable,str(ROOT/'scripts/run_norm_short.py'),'--comparison','agents-norm-short',
         '--blocks','8','--label','agents-norm-short-r0'],
        [sys.executable,str(ROOT/'scripts/analyze_pairs.py'),'--label','agents-norm-short-r0',
         '--output',str(ROOT/'results/agents-norm-short-r0-statistics.json')],
        [sys.executable,str(ROOT/'scripts/audit_work.py'),'--label','agents-norm-short-r0',
         '--output',str(ROOT/'results/agents-norm-short-r0-work-audit.json')],
    ]
    history=[]
    for command in commands:
        print('START',command,flush=True)
        start=datetime.datetime.now(datetime.timezone.utc).isoformat()
        rc=subprocess.run(command).returncode
        history.append({'command':command,'start_utc':start,'returncode':rc,
                        'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
        (ROOT/'results/short-queue-r0.json').write_text(json.dumps(history,indent=2)+'\n')
        assert rc==0,rc


if __name__=='__main__':main()
