"""Separate diagnostic: host timers and sparsely sampled NPU enqueue intervals.

No synchronize, polling wait, or changed Ray await order in the request path.
Device events are collected only at release, outside measured requests. Their
interval includes host enqueue gaps; it must not be called pure kernel time.
"""
import collections
import ctypes
import functools
import json
import os
from pathlib import Path
import threading
import time

from warm_observer import WarmWorker, phase

LIBC=ctypes.CDLL('libc.so.6')
LIBC.sched_getcpu.restype=ctypes.c_int
DRIVER=[]


def stamp():
    return time.monotonic_ns(),time.thread_time_ns(),LIBC.sched_getcpu()


def finish(name,before,pn):
    now=stamp()
    return {'name':name,'phase':pn,'end_phase':phase(),'begin_ns':before[0],'end_ns':now[0],
            'host_ms':(now[0]-before[0])/1e6,'thread_cpu_activity_ms':(now[1]-before[1])/1e6,
            'begin_cpu':before[2],'end_cpu':now[2],'tid':threading.get_native_id()}


def driver_profile():
    from lmdeploy.pytorch.engine.executor.ray_executor import RayExecutor
    for name in ['forward_async','get_output_async']:
        original=getattr(RayExecutor,name)
        def make(fn,label):
            @functools.wraps(fn)
            async def call(self,*args,**kwargs):
                pn=phase();before=stamp()
                try:return await fn(self,*args,**kwargs)
                finally:DRIVER.append(finish(label,before,pn))
            return call
        setattr(RayExecutor,name,make(original,name))
    original=RayExecutor.release
    @functools.wraps(original)
    def release(self,*args,**kwargs):
        out=Path(os.environ['WARM_OBSERVER_DIR'])/f'profile-driver-{os.getpid()}.json'
        out.write_text(json.dumps({'pid':os.getpid(),'records':DRIVER,
            'cpu_time_scope':'Thread activity across await, not exclusive time of the awaited call'},indent=2)+'\n')
        return original(self,*args,**kwargs)
    RayExecutor.release=release


class ProfileWorker(WarmWorker):
    def build_graph_runner(self):
        result=super().build_graph_runner()
        import torch
        runner=self.model_agent.patched_model
        assert hasattr(runner,'ctx_mgr') and hasattr(runner,'_runner_map'),type(runner)
        original_type=type(runner);owner=self
        self._profile_records=[];self._profile_events=[]
        self._profile_phase_counts=collections.Counter();self._profile_dumped=False
        class TimedRunner(original_type):
            def __call__(inner,**kwargs):
                pn=phase()
                if pn in [0,255]:return super().__call__(**kwargs)
                context=inner.ctx_mgr.current_context()
                decoding=context.global_is_decoding()
                key=(pn,decoding);owner._profile_phase_counts[key]+=1
                index=owner._profile_phase_counts[key]
                # Fixed sampling, never selected by observed speed. Bound event
                # lifetime/resources without adding mid-request synchronization.
                sampled=(decoding and index%64==0) or (not decoding and index<=2)
                if sampled:
                    start,end=(torch.npu.Event(enable_timing=True) for _ in range(2))
                    start.record()
                before=stamp()
                value=super().__call__(**kwargs)
                row=finish('model_enqueue',before,pn)
                if sampled:
                    end.record()
                    owner._profile_events.append((start,end,row))
                row.update(decoding=decoding,input_tokens=kwargs['input_ids'].numel(),
                           device_sampled=sampled,phase_call=index)
                owner._profile_records.append(row)
                return value
        runner.__class__=TimedRunner
        return result

    def _profile_collect(self):
        if getattr(self,'_profile_dumped',True):return
        import torch
        # Only invoked by teardown after the client sets phase255.
        ending_phase=phase()
        with self.model_agent.all_context():
            torch.npu.synchronize()
            for start,end,row in self._profile_events:
                row['device_enqueue_interval_ms']=start.elapsed_time(end)
        self._profile_events.clear();self._profile_dumped=True
        out=Path(os.environ['WARM_OBSERVER_DIR'])/f'profile-worker-{os.getpid()}.json'
        out.write_text(json.dumps({'pid':os.getpid(),'rank':self.rank,'teardown_phase':ending_phase,
            'device_sampling':'Every64th decode forward; first2prefill forwards per phase',
            'device_time_scope':'Enqueue interval including host gaps, not pure kernel execution',
            'records':self._profile_records},indent=2)+'\n')

    def release(self):
        self._profile_collect()
        return super().release()

    def exit(self):
        self._profile_collect()
        return super().exit()
