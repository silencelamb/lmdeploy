"""Validation-only counters: no tensor copies, synchronization, or sampling changes."""
import collections
import functools
import importlib
import importlib.metadata
import json
import mmap
import os
from pathlib import Path
import random
import sys
import time

from lmdeploy.pytorch.engine.executor.ray_executor import RayWorkerWrapper

CONTROL = None
COUNTS = collections.Counter()
SEEN = set()
EVENTS = []
OUTPUT_COUNTS = collections.Counter()


def phase():
    global CONTROL
    if CONTROL is None:
        descriptor = os.open(os.environ['WARM_CONTROL_PATH'], os.O_RDONLY)
        CONTROL = mmap.mmap(descriptor, 1, access=mmap.ACCESS_READ)
        os.close(descriptor)
    return CONTROL[0]


def event(kind, **details):
    row = dict(kind=kind, phase=phase(), pid=os.getpid(), ns=time.monotonic_ns(), **details)
    EVENTS.append(row)
    with (Path(os.environ['WARM_OBSERVER_DIR']) / f'events-{os.getpid()}.jsonl').open('a') as f:
        f.write(json.dumps(row, default=str) + '\n')


def wrap_event(obj, name, kind):
    old = getattr(obj, name)
    if getattr(old, '_warm_observed', False):
        return

    @functools.wraps(old)
    def wrapped(*args, **kwargs):
        event(kind, function=name, target=type(args[0]).__name__ if args else '')
        return old(*args, **kwargs)
    wrapped._warm_observed = True
    setattr(obj, name, wrapped)


def install():
    import numpy as np
    import torch
    import torch_npu  # noqa: F401
    random.seed(42)
    np.random.seed(42)
    torch.manual_seed(42)
    torch.npu.manual_seed(42)
    compiler = importlib.import_module('triton.compiler.compiler')
    wrap_event(compiler, 'compile', 'triton_compile')
    # JITFunction.create_binder imports the package alias, not the module name.
    importlib.import_module('triton.compiler').compile = compiler.compile
    autotuner = importlib.import_module('triton.runtime.autotuner')
    wrap_event(autotuner.Autotuner, '_bench', 'autotune_bench')
    agent = importlib.import_module('lmdeploy.pytorch.engine.model_agent.agent')
    original = agent.model_forward

    @functools.wraps(original)
    def forward(*args, **kwargs):
        model = kwargs.get('model', args[0] if args else None)
        inputs = kwargs.get('inputs', args[1] if len(args) > 1 else None)
        if inputs is not None:
            signature = (type(getattr(model, 'model', model)).__name__, bool(inputs.is_decoding),
                         inputs.input_ids.numel(), inputs.seq_length.numel())
            p = phase()
            COUNTS[(p, signature)] += 1
            if signature not in SEEN:
                SEEN.add(signature)
                event('new_forward_shape', signature=signature)
        return original(*args, **kwargs)
    agent.model_forward = forward
    module = ('dlinfer.framework.lmdeploy_ext.cudagraph.ascend_cudagraph'
              if os.environ['WARM_ROLE'] == 'baseline'
              else 'lmdeploy.pytorch.backends.ascend.graph_runner')
    graph = importlib.import_module(module)
    wrap_event(graph.AscendSingleGraphRunner, 'capture', 'graph_capture')


def install_driver():
    """Observe already-host-visible results; preserve the original await/yield order."""
    from lmdeploy.pytorch.engine.executor.ray_executor import RayExecutor
    from lmdeploy.serve.core.async_engine import AsyncEngine
    original_output = RayExecutor.get_output_async
    original_release = RayExecutor.release
    original_generate = AsyncEngine.generate

    @functools.wraps(original_output)
    async def output(self, *args, **kwargs):
        result = await original_output(self, *args, **kwargs)
        ids = result.next_token_ids
        if ids is not None:
            assert ids.device.type == 'cpu', 'Observer must not add a device-to-host copy'
            values = ids.tolist()
            if ids.ndim == 1:
                values = [[v] for v in values]
            OUTPUT_COUNTS[(phase(), tuple(sum(t >= 0 for t in row) for row in values))] += 1
        return result

    @functools.wraps(original_generate)
    async def generate(self, request, *args, **kwargs):
        pn = phase()
        row = {'phase': pn, 'session_id': request.session.session_id,
               'input_ids': list(request.inputs['input_ids']), 'token_ids': [], 'chunks': [],
               'finished': False}
        try:
            async for result in original_generate(self, request, *args, **kwargs):
                ids = result.token_ids or []
                if ids:
                    row['token_ids'].extend(ids)
                    row['chunks'].append([time.monotonic_ns(), len(ids)])
                row['finish_reason'] = result.finish_reason
                for field in ['input_token_len', 'history_token_len', 'num_token', 'cached_tokens']:
                    if hasattr(result, field):
                        row[field] = getattr(result, field)
                yield result
            row['finished'] = True
        finally:
            with (Path(os.environ['WARM_OBSERVER_DIR']) / f'tokens-{os.getpid()}.jsonl').open('a') as f:
                f.write(json.dumps(row, default=str) + '\n')

    @functools.wraps(original_release)
    def release(self, *args, **kwargs):
        out = Path(os.environ['WARM_OBSERVER_DIR']) / f'driver-{os.getpid()}.json'
        out.write_text(json.dumps({'pid': os.getpid(), 'output_step_histogram': [
            {'phase': p, 'valid_slots_per_row': counts, 'steps': n}
            for (p, counts), n in OUTPUT_COUNTS.items()]}, indent=2) + '\n')
        return original_release(self, *args, **kwargs)

    RayExecutor.get_output_async = output
    RayExecutor.release = release
    AsyncEngine.generate = generate


def dump(rank=None):
    row = dict(pid=os.getpid(), rank=rank, events=EVENTS,
               counts=[{'phase': p, 'signature': s, 'count': n} for (p, s), n in COUNTS.items()],
               dlinfer_modules=[n for n in sys.modules if n.split('.')[0] == 'dlinfer'],
               affinity=sorted(os.sched_getaffinity(0)),
               versions={n: importlib.metadata.version(n) for n in
                         ['torch', 'torch-npu', 'triton-ascend', 'ray', 'numpy', 'transformers']})
    if os.environ['WARM_ROLE'] == 'native':
        assert not row['dlinfer_modules']
    out = Path(os.environ['WARM_OBSERVER_DIR']) / f'summary-{os.getpid()}.json'
    out.write_text(json.dumps(row, indent=2) + '\n')
    return row


class WarmWorker(RayWorkerWrapper):
    def build_model(self):
        install()
        result = super().build_model()
        event('model_loaded', rank=self.rank)
        return result

    def perf_snapshot(self):
        return dump(self.rank)

    def release(self):
        dump(self.rank)
        return super().release()

    def exit(self):
        dump(self.rank)
        return super().exit()
