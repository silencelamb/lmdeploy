"""Native processes reject dlinfer; baseline processes retain its fixed installation."""
import importlib.abc
import importlib.machinery
import os
import random
import sys

random.seed(int(os.environ.get('PYTHONHASHSEED', '42')))
if os.environ.get('WARM_ROLE') == 'native':
    if importlib.machinery.PathFinder.find_spec('dlinfer') is not None:
        os.write(2, b'FATAL: dlinfer discoverable in native performance environment\n')
        os._exit(96)

    class NoDlinfer(importlib.abc.MetaPathFinder):
        def find_spec(self, fullname, path=None, target=None):
            if fullname.split('.')[0] == 'dlinfer':
                raise RuntimeError('Forbidden native dlinfer import: ' + fullname)

    sys.meta_path.insert(0, NoDlinfer())
