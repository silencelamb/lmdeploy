"""Unmodified-source full-pipeline norm comparison with the same warmup contract."""
import argparse
import dataclasses
import json
import mmap
import os
from pathlib import Path
import time

ROOT = Path(__file__).resolve().parents[1]


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--model', required=True)
    p.add_argument('--label', required=True)
    p.add_argument('--tokens', type=int, default=256)
    p.add_argument('--min-warm-sweeps', type=int, default=5)
    p.add_argument('--max-warm-sweeps', type=int, default=10)
    p.add_argument('--c1-repeats', type=int, default=25)
    p.add_argument('--c4-repeats', type=int, default=8)
    p.add_argument('--block', type=int, default=0)
    p.add_argument('--pilot', action='store_true')
    a = p.parse_args()
    from lmdeploy import pipeline, GenerationConfig, PytorchEngineConfig
    from lmdeploy.pytorch.engine.executor import ray_executor
    from warm_observer import WarmWorker, install_driver
    ray_executor.RayWorkerWrapper = WarmWorker
    install_driver()
    cfg = PytorchEngineConfig(device_type='ascend', dtype='bfloat16', tp=2,
        eager_mode=False, enable_prefix_caching=False, max_batch_size=8, session_len=8192,
        prefix_cache_state_budget=0, prefill_save_alignment=128, prefill_save_last_only=True,
        block_size=128, max_prefill_token_num=256, cache_max_entry_count=.5,
        language_model_only=True, logprobs_mode='raw_logprobs')
    out = ROOT / 'results' / f'{a.label}.json'
    assert not out.exists()
    data = {'options': vars(a), 'engine_config': dataclasses.asdict(cfg), 'phases': {},
            'events': [], 'complete': False, 'warmup_qualified': False, 'pilot': a.pilot}
    with open(os.environ['WARM_CONTROL_PATH'], 'r+b') as f:
        phase = mmap.mmap(f.fileno(), 1)
    def save():
        out.write_text(json.dumps(data, ensure_ascii=False, indent=2, default=str) + '\n')
    def cold_events(pn):
        return [x for p in Path(os.environ['WARM_OBSERVER_DIR']).glob('events-*.jsonl')
                for line in p.read_text().splitlines() if (x := json.loads(line))['phase']==pn
                and x['kind'] in ['new_forward_shape','triton_compile','autotune_bench','graph_capture']]
    save()
    began = time.monotonic()
    with pipeline(a.model, backend_config=cfg, trust_remote_code=True, log_level='INFO') as pipe:
        data['startup_seconds'] = time.monotonic()-began
        def batch(bs, rep, kind):
            pn = len(data['phases'])+1
            assert pn < 255
            phase[0] = pn
            data['phases'][str(pn)] = {'kind': kind, 'batch': bs, 'rep': rep}
            first = rep*bs if kind=='warmup' else 96 if kind=='qualify' else 40+rep*bs
            assert first+bs <= 100
            prompts = [f'Trial {(first+i)//10} item {(first+i)%10}. Explain how a computer stores and retrieves information. '
                       + 'Include examples of memory, disks, indexes, and cache. '*12 for i in range(bs)]
            rows = [{'token_ids': [], 'times': [], 'text': ''} for _ in prompts]
            gen = GenerationConfig(max_new_tokens=a.tokens, do_sample=False, top_k=1,
                                   temperature=1., ignore_eos=True, random_seed=42)
            start = time.monotonic()
            for result in pipe.stream_infer(prompts, gen_config=gen):
                row = rows[result.index]
                if result.token_ids:
                    row['times'].append([time.monotonic()-start,len(result.token_ids)])
                    row['token_ids'].extend(result.token_ids)
                row['text'] += result.text
                row['input_token_len'] = result.input_token_len
                row['cached_tokens'] = result.cached_tokens
                row['finish_reason'] = result.finish_reason
            elapsed = time.monotonic()-start
            for row in rows:
                assert len(row['token_ids']) == a.tokens
                assert row['finish_reason'] not in ['error','abort']
                row['ttft'] = row['times'][0][0]
                row['output_tps'] = (a.tokens-row['times'][0][1])/(row['times'][-1][0]-row['ttft'])
                row['tpot'] = 1/row['output_tps']
            cold = cold_events(pn)
            e = {'kind': kind, 'batch': bs, 'rep': rep, 'phase': pn, 'prompts': prompts,
                 'responses': rows, 'elapsed': elapsed, 'throughput': bs*a.tokens/elapsed,
                 'cold_events': cold, 'qualified': not cold}
            data['events'].append(e)
            save()
            print('BATCH',kind,bs,rep,'tps',round(e['throughput'],3),'cold',len(cold),flush=True)
            return e
        quiet = 0
        for sweep in range(a.max_warm_sweeps):
            events = [batch(bs,sweep,'warmup') for bs in [1,2,3,4]]
            quiet = quiet+1 if all(x['qualified'] for x in events) else 0
            if sweep+1 >= a.min_warm_sweeps and quiet >= 2:
                data['warmup_qualified'] = True
                break
        save()
        assert data['warmup_qualified'], 'Warmup did not converge within the fixed limit'
        for bs in [1,4]:
            batch(bs,0,'qualify')
        for rep in range(max(a.c1_repeats,a.c4_repeats)):
            for bs in ([1,4] if rep%2==0 else [4,1]):
                if rep < (a.c1_repeats if bs==1 else a.c4_repeats):
                    batch(bs,rep,'measure')
        data['measurement_qualified'] = all(x['qualified'] for x in data['events'] if x['kind']=='measure')
        data['complete'] = True
        phase[0] = 255
    data['worker_summaries'] = [json.loads(p.read_text()) for p in Path(os.environ['WARM_OBSERVER_DIR']).glob('summary-*.json')]
    data['driver_summaries'] = [json.loads(p.read_text()) for p in Path(os.environ['WARM_OBSERVER_DIR']).glob('driver-*.json')]
    data['token_traces'] = [json.loads(line) for p in Path(os.environ['WARM_OBSERVER_DIR']).glob('tokens-*.jsonl') for line in p.read_text().splitlines()]
    save()
    phase.close()


if __name__ == '__main__':
    main()
