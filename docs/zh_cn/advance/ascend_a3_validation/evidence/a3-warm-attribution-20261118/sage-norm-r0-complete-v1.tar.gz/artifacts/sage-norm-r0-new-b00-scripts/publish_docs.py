"""Publish reviewed files on the latest fork docs tree, preserving concurrent work."""
import argparse
import base64
import datetime
import hashlib
import json
from pathlib import Path
import subprocess


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--config',required=True)
    p.add_argument('--record',required=True)
    a=p.parse_args()
    config=json.loads(Path(a.config).read_text())
    record_path=Path(a.record);assert not record_path.exists()
    repo=config['repository'];branch=config['branch']
    assert repo=='silencelamb/lmdeploy' and branch=='docs/ascend-a3-validation-20261114'
    record={'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'config':config,'uploaded':[],'published':False}
    def save():record_path.write_text(json.dumps(record,indent=2)+'\n')
    def api(path,payload=None,method=None,allow404=False):
        command=['gh','api',f'repos/{repo}/{path}','-H','Cache-Control: no-cache']
        if payload is not None:command+=['--method',method or 'POST','--input','-']
        response=subprocess.run(command,input=json.dumps(payload) if payload is not None else None,
            capture_output=True,text=True,timeout=120)
        if response.returncode:
            if allow404 and 'HTTP404' in response.stderr.replace(' ',''):return None
            raise RuntimeError(f'{path}: {response.stderr}')
        return json.loads(response.stdout) if response.stdout.strip() else {}
    def verify_sources(parent):
        for name,sha in config['expected_source_blobs'].items():
            current=api(f'contents/{name}?ref={parent}',allow404=True)
            actual=current['sha'] if current else None
            assert actual==sha, f'Concurrent change at {name}: expected{sha}, actual{actual}'
    save()
    ref='git/ref/heads/'+branch
    verify_sources(api(ref)['object']['sha'])
    elements=[]
    for file in config['files']:
        data=Path(file['file']).read_bytes()
        sha=hashlib.sha1(f'blob {len(data)}\0'.encode()+data).hexdigest()
        assert sha==file['git_blob_sha']
        blob=api('git/blobs',{'encoding':'base64','content':base64.b64encode(data).decode()})
        assert blob['sha']==sha
        entry={'path':file['path'],'mode':'100644','type':'blob','sha':sha}
        elements.append(entry);record['uploaded'].append(entry);save()
        print('UPLOADED',file['path'],flush=True)
    parent=api(ref)['object']['sha'];verify_sources(parent)
    base_tree=api('git/commits/'+parent)['tree']['sha']
    tree=api('git/trees',{'base_tree':base_tree,'tree':elements})
    commit=api('git/commits',{'message':config['message'],'parents':[parent],'tree':tree['sha']})
    record.update(parent=parent,commit=commit['sha'],tree=tree['sha']);save()
    assert api(ref)['object']['sha']==parent, 'Docs head moved; reconcile and rebuild, never force'
    api('git/refs/heads/'+branch,{'sha':commit['sha'],'force':False},method='PATCH')
    record['published']=True;save()
    assert api(ref)['object']['sha']==commit['sha']
    diff=api(f'compare/{parent}...{commit["sha"]}')
    expected={f['path']:f['git_blob_sha'] for f in config['files']}
    assert len(expected)<300, 'Use explicit tree verification for a larger publication'
    for file in diff['files']:
        assert file['filename'] in expected and file['sha']==expected[file['filename']]
    record.update(verified=True,changed_paths=[f['filename'] for f in diff['files']],
                  end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    save();print(json.dumps({k:record[k] for k in ['parent','commit','published','verified']}),flush=True)


if __name__=='__main__':main()
