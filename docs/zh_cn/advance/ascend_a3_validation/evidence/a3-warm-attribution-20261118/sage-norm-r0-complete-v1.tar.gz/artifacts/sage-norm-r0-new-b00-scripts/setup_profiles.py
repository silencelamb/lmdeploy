"""Create private Python namespaces over fixed read-only dependency snapshots."""
from pathlib import Path
import json
import subprocess

ROOT = Path(__file__).resolve().parents[1]
OLD = Path('/root/workspace/a3-validation-20261112/envs')
NEW = Path('/root/workspace/a3-mtp-ray-investigation-20261116/envs/upgrade5-full322p2')


def main():
    profiles = {}
    for role in ['baseline', 'native']:
        for compiler in ['legacy', 'ir2']:
            name = role + '-' + compiler
            env = ROOT / 'envs' / name
            assert not env.exists()
            subprocess.run(['/usr/local/python3.12.13/bin/python3.12', '-m', 'venv', '--copies',
                            '--without-pip', str(env)], check=True)
            source = OLD / role / 'lib/python3.12/site-packages'
            dest = env / 'lib/python3.12/site-packages'
            records = []
            for item in sorted(source.iterdir()):
                if item.name in ['__pycache__', 'sitecustomize.py']:
                    continue
                if item.name.startswith('__editable__') and 'lmdeploy' in item.name:
                    continue
                if role == 'native' and 'dlinfer' in item.name.lower():
                    raise RuntimeError(str(item))
                if compiler == 'ir2' and (item.name == 'triton' or item.name.startswith('triton_ascend-')):
                    continue
                target = dest / item.name
                if target.exists():
                    continue
                target.symlink_to(item.resolve(), target_is_directory=item.is_dir())
                records.append({'name': item.name, 'source': str(item.resolve())})
            if compiler == 'ir2':
                for item in (NEW / 'lib/python3.12/site-packages').iterdir():
                    if item.name == 'triton' or item.name.startswith('triton_ascend-'):
                        (dest / item.name).symlink_to(item.resolve(), target_is_directory=item.is_dir())
                        records.append({'name': item.name, 'source': str(item.resolve())})
            profiles[name] = {'path': str(env), 'role': role, 'compiler': compiler,
                              'entries': records, 'no_pip_mutations': True}
    (ROOT / 'inventory/profiles.json').write_text(json.dumps(profiles, indent=2) + '\n')


if __name__ == '__main__':
    main()
