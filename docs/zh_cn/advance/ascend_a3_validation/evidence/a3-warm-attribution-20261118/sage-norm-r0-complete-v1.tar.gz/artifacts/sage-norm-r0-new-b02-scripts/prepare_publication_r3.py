"""Publish current conclusions prominently; archive old A3 performance prose."""
from pathlib import Path
import hashlib
import json
import re
import shutil

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'artifacts/remote-r3'
STAGE=ROOT/'artifacts/publication-r3'
BASE='docs/zh_cn/advance/ascend_a3_validation'
DOCS=STAGE/BASE
EVIDENCE=DOCS/'evidence/a3-warm-perf-20261118'
OLD=DOCS/'old'
LATEST='a3_warm_performance_20261118.md'

SUMMARY='''当前PR `2ccf38a4` 的真实HTTP C1已有明确通过项：Sage MTP3的总吞吐、流式速度p50和TPOT，以及Agents的总吞吐和TPOT，配对95%区间均在±5%内。两组各8个全新进程配对、496条对应响应逐token一致；Sage的直接draft形状观测也已补核通过。

**仍未整体验收为全部持平。** HTTP C4、TTFT和Agents256-token norm仍有统计不确定项；后者C1 TTFT配对变化+5.40%，95%区间[−2.63%,+7.91%]。Sage/Agents64-token norm继续复测。历史Agents旧依赖HTTP的8配对也未证明±5%等效。当前没有统计确认超过5%的持续回退，不代表所有项已通过。

完整版本、逐项区间、补核和原始证据以[最新A3性能结果](a3_warm_performance_20261118.md)为准。旧性能叙述已移至`old/`，当前未验收项仍列在最新主表；不能用norm或CPU18亲和性控制替代HTTP验收。
'''


def old_links(text):
    # Only simple inline repository links are present in these source reports.
    return re.sub(r'\]\(([^)]+)\)',lambda m:m.group(0) if m.group(1).startswith(
        ('https://','http://','#','/','mailto:')) else '](../'+m.group(1)+')',text)


def archive(name,body):
    path=OLD/name
    path.write_text('# 历史性能记录（已归档）\n\n以[最新A3性能结果](../'+LATEST+')为当前结论；以下保留原测量事实，不代表当前验收状态。相对引用已调整，原始数据未改。\n\n'+old_links(body))


def replace_range(text,start,end,replacement):
    assert text.count(start)==1,(start,text.count(start))
    i=text.index(start);j=text.index(end,i)
    return text[:i]+replacement+text[j:]


def main():
    EVIDENCE.mkdir(parents=True);OLD.mkdir()
    originals={p.name:p.read_text() for p in SOURCE.glob('*.md')}
    archive('performance_review_before_warm_20261118.md',originals['performance_review_20261117.md'])
    archive('migration_validation_before_warm_20261118.md',originals['migration_validation.md'])
    archive('gated_norm_performance_20261116.md',originals['gated_norm_performance_20261116.md'])
    refactor=originals['gated_norm_refactor_20261115.md']
    i=refactor.index('### 性能观察');j=refactor.index('## 明确未覆盖与共有阻塞',i)
    archive('gated_norm_initial_performance_20261115.md',refactor[i:j])
    report=(ROOT/'artifacts/report-verified-passes-r3.md').read_text()
    report=report.replace('## 最新状态','## 已确认的通过项\n\n'+SUMMARY+'\n## 最新状态',1)
    report+='''
## Sage直接draft覆盖补核

补核已通过。两侧各一个全新服务，执行与正式测试相同的5轮预热及完整C1/C4请求序列；62条请求配对也匹配各侧原b00输出。每侧每个worker测量中记录到5019次draft forward；16种实际target/draft测量形状全部已在预热中出现，没有测量期新编译、graph捕获或新形状。原生没有dlinfer导入，全部请求cache miss。[直接覆盖审计](evidence/a3-warm-perf-20261118/sage-draft-coverage-audit-r0.json)

补核计时未并入原8配对统计。原target入口的形状计数与全局编译/graph记录保留；draft走独立函数的观测缺口及修正过程也保留。按阶段统计的输出槽数可能包含上一批迟到结果，因此未把它当作逐请求接受率。[源码与执行计数范围](evidence/a3-warm-perf-20261118/sage-current-r0-execution-counts.json)

## 尚未完成的定位

仍需完成两组64-token norm及独立主机/设备计时。主机约半秒停顿的具体softirq/tasklet回调和永久修复仍开放；本轮没有避开CPU18、关闭GC或修改Ray await顺序。旧依赖Agents的15个Triton缓存变体中14个npubin完全相同，一个prefill变体的规范化IR相同但机器码不同；尚未量化其影响，不能将它认定为回退根因。

完整请求、命令、工具快照和服务日志持续保存在`/root/workspace/a3-perf-warm-20261118`。当前已发布[历史Agents完整请求归档](evidence/a3-warm-perf-20261118/agents-historical-r0-raw.tar.gz)；其他完整包将在主计时结束后补传，避免大批归档传输干扰计时。目前先提供逐对统计、审计及[所有已完成正式运行的本机原始文件哈希](evidence/a3-warm-perf-20261118/completed-raw-manifest-r3.json)。

历史数字及旧分析见[归档入口](old/performance_review_before_warm_20261118.md)，当前主表中的不确定和未完成项仍然开放。
'''
    (DOCS/LATEST).write_text(report)
    review=originals['performance_review_20261117.md']
    review=replace_range(review,'## A3\n','## 11月17日历史复核方法与证据','## A3\n\n'+SUMMARY+'\n')
    review=review[:review.index('## 11月17日历史复核方法与证据')]+'''## 证据与历史追溯

新A3实验的判据、固定版本、逐对数据与复现工具见[最新报告](a3_warm_performance_20261118.md)。H200部分保留其独立固定版本与原判据，不用A3结果代替。

旧A3表格、11月17日的CPU数据复核及其原始数字见[历史归档](old/performance_review_before_warm_20261118.md)。原始证据未删除，当前未关闭项在新主表中明确显示。
'''
    review=review.replace('A3 的受控 norm/target 测量没有显示一致方向的变慢；历史 dlinfer→native HTTP 对照仍有重复的流式速度下降信号，后来的 native-only norm 对照和主机绑核控制没有关闭它们。','A3的当前HTTP C1已有通过项；C4、部分TTFT与norm仍未完成等效验收，最新状态见A3节。')
    review=review.replace('HTTP 的部分重复下降仍未完成归因；不能整体判通过，也未证明是当前 HEAD 的代码回归','旧依赖Agents8配对仍未证明等效；当前PR的C1已有通过项，C4/TTFT继续定位')
    review=review.replace('部分初测下降未稳定复现；不能替代上一行的旧 dlinfer 对照','256-token Agents新复核仍有不确定项，64-token场景继续；不替代HTTP验收')
    (DOCS/'performance_review_20261117.md').write_text(review)
    summary=originals['a3_validation_summary_20261117.md']
    summary=replace_range(summary,'**性能没有整体验收为全部对齐。**','约半秒主机停顿是独立问题',SUMMARY+'\n')
    summary=summary.replace('更新日期：2026-11-17，Asia/Shanghai。本文是PR正文A3总表的统一详情入口；整理已有实测，不将历史数据改标为新HEAD上的新运行。','更新日期：2026-11-18，Asia/Shanghai。本文是PR正文A3总表的统一详情入口；精度保留各自固定快照，性能补充本轮独立新实测。')
    (DOCS/'a3_validation_summary_20261117.md').write_text(summary)
    readme=originals['README.md']
    readme=re.sub(r'^最新复查：.*$', '最新性能结果：[充分预热后的A3复核](a3_warm_performance_20261118.md)。当前Sage/Agents C1的已确认通过项、C4与norm未验收项分别列明，旧性能叙述移至old/，原始数据保留。',readme,flags=re.M)
    readme=re.sub(r'^\| 重构后性能观察.*$', '| norm性能复核 | Agents256-token C1 TTFT +5.40%，95%区间[−2.63%,+7.91%]，尚未证明等效；两组64-token继续 | [最新结果](a3_warm_performance_20261118.md)，不以norm代替HTTP |',readme,flags=re.M)
    readme=re.sub(r'^\| Agents C1 TTFT p95.*$', '| 当前PR HTTP C1 | Sage MTP3总吞吐/流速/TPOT，Agents总吞吐/TPOT的95%区间均在±5%内 | 这些指标通过；TTFT及C4仍未整体验收，见[最新结果](a3_warm_performance_20261118.md) |',readme,flags=re.M)
    readme=readme.replace('- [2026-11-16：Agents gated norm 性能定位](gated_norm_performance_20261116.md)。包括编译二进制核对、同 worker 交替测量、GC 排查、阶段计时、失败实验与覆盖限制。','- [2026-11-18：充分预热后的A3性能复核](a3_warm_performance_20261118.md)。分列最新通过与未验收项；旧诊断可由文末归档入口追溯。')
    (DOCS/'README.md').write_text(readme)
    migration=originals['migration_validation.md']
    migration=migration.replace('两模型HTTP C4流式输出速度均出现可重复下降，固定批次Agents引擎对照未复现该下降，性能归因仍未完成。','当前性能状态请看[最新复核](a3_warm_performance_20261118.md)；第一阶段性能叙述已移至old/，未验收项仍在新主表中保留。')
    migration=replace_range(migration,'Sage-A1.5 HTTP 性能：','## 仍未验证或不能外推的范围','''Sage的最新真实HTTP结论：在两侧匹配的正确编译器上，当前PR的C1总吞吐、流式速度和TPOT通过±5%等效判据；C4和TTFT仍有不确定项。[完整新结果](a3_warm_performance_20261118.md)。旧错误编译器下的数字及SLO测量见[历史归档](old/migration_validation_before_warm_20261118.md)，不把它们改写为只靠预热修复。

''')
    migration=replace_range(migration,'Agents HTTP 首组','## 第一阶段 Mooncake 失败配置','''Agents的当前PR HTTP C1总吞吐和TPOT已通过等效判据；C4、TTFT和旧依赖历史对照仍有不确定项，继续定位。[完整新结果](a3_warm_performance_20261118.md)。旧HTTP表格和固定批次pipeline数据见[历史归档](old/migration_validation_before_warm_20261118.md)。

''')
    (DOCS/'migration_validation.md').write_text(migration)
    norm_status='''最新完整模型对照见[2026-11-18性能复核](a3_warm_performance_20261118.md)。Agents256-token的8个独立进程配对已完成：C1 TTFT +5.40%，95%区间[−2.63%,+7.91%]；C4吞吐+1.03%，区间[−1.85%,+10.52%]。仍未证明严格±5%等效，不能整体标通过。Sage与Agents64-token场景继续运行。
'''
    refactor=replace_range(refactor,'### 性能观察','## 明确未覆盖与共有阻塞','### 性能观察\n\n'+norm_status+'\n原初测和微算子表格已移至[历史性能归档](old/gated_norm_initial_performance_20261115.md)，原始样本保持不变。\n\n')
    (DOCS/'gated_norm_refactor_20261115.md').write_text(refactor)
    norm='# gated norm性能复核：当前状态\n\n更新：2026-11-18，Asia/Shanghai。\n\n'+norm_status+'''\n## 比较范围

本项为已原生迁移的342db85e→5f1b1b3c，两个版本均不使用dlinfer。它不能代替旧dlinfer→native的HTTP验收；通过和未验收项以[最新主表](a3_warm_performance_20261118.md)为准。

## PR 与 CI 记录

PR #5134当前代码2ccf38a4，既有14/14门禁通过；CI结果不替代性能验收。[CI完整记录](ci_docker_recovery_20261116.md)。

## 历史诊断

旧同worker替换、NPU二进制、设备计时、GC及主机等待定位已整体移入[old归档](old/gated_norm_performance_20261116.md)。原始失败和日志均保留；CPU18具体回调及永久修复仍见[独立主机报告](ray_host_latency_20261117.md)。
'''
    (DOCS/'gated_norm_performance_20261116.md').write_text(norm)
    completed=['agents-historical-r0','sage-current-r0','agents-current-r0','agents-norm-r0']
    raw_manifest={'scope':'Immutable completed runs; full raw files retained locally pending final bulk upload','files':[]}
    for label in completed:
        progress=json.loads((ROOT/'results'/f'{label}-progress.json').read_text())
        for suffix in ['statistics','work-audit','progress']:
            src=ROOT/'results'/f'{label}-{suffix}.json';shutil.copy2(src,EVIDENCE/src.name)
        for s in progress['sessions']:
            for path in [ROOT/'results'/f'{s["label"]}.json',ROOT/'logs'/f'{s["label"]}.json',ROOT/'logs'/f'{s["label"]}.log',ROOT/'logs'/f'{s["label"]}-server.log']:
                if path.exists():
                    data=path.read_bytes();raw_manifest['files'].append({'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
    for name in ['sage-draft-coverage-audit-r0.json','draft-boundary-r0.json','sage-current-r0-execution-counts.json']:
        shutil.copy2(ROOT/'results'/name,EVIDENCE/name)
    (EVIDENCE/'completed-raw-manifest-r3.json').write_text(json.dumps(raw_manifest,indent=2)+'\n')
    for script in ['draft_shape_observer.py','draft_shape_serve.py','http_draft_shape_case.py','draft_probe_boundary.py']:
        (EVIDENCE/(script+'.md')).write_text('```python\n'+(ROOT/'scripts'/script).read_text()+'```\n')
    files=[]
    for path in sorted(STAGE.rglob('*')):
        if path.is_file():
            data=path.read_bytes();files.append({'file':str(path),'path':str(path.relative_to(STAGE)),
                'git_blob_sha':hashlib.sha1(f'blob {len(data)}\0'.encode()+data).hexdigest()})
    blobs=json.loads((SOURCE/'blobs.json').read_text())
    # Existing evidence must also be checked against its exact currently published bytes.
    expected={f['path']:None for f in files}
    for name,sha in blobs.items():expected[BASE+'/'+name]=sha
    config={'repository':'silencelamb/lmdeploy','branch':'docs/ascend-a3-validation-20261114',
        'message':'docs: publish verified A3 C1 performance passes and archive superseded observations',
        'files':files,'expected_source_blobs':expected}
    (ROOT/'artifacts/publish-config-r3.json').write_text(json.dumps(config,indent=2)+'\n')
    print('Prepared',len(files),'files; fill existing evidence blob expectations before publishing')


if __name__=='__main__':main()
