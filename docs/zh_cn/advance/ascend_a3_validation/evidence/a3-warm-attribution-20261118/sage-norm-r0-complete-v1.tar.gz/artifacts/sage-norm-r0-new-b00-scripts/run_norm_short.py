"""Also retain the initial64-token Agents norm workload, distinct from256-token control."""
import run_matrix

run_matrix.COMPARISONS['agents-norm-short'] = dict(
    kind='pipeline', model='Agents-A1', mtp=0, tokens=64, compiler='legacy',
    old='norm-before', new='norm-after')

if __name__=='__main__':
    run_matrix.main()
