"""Diagnostic API entry; production source and await ordering remain unchanged."""
from lmdeploy.pytorch.engine.executor import ray_executor
from warm_observer import install_driver
from profile_observer import ProfileWorker,driver_profile

ray_executor.RayWorkerWrapper=ProfileWorker
install_driver()
driver_profile()

if __name__=='__main__':
    from lmdeploy.cli import run
    run()
