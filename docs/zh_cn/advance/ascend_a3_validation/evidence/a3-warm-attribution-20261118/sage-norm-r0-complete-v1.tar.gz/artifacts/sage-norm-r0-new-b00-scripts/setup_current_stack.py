"""Match the tested CANN9.1 application dependency profile for both comparison arms."""
from pathlib import Path
import json
import subprocess

ROOT = Path(__file__).resolve().parents[1]
SOURCE = Path('/root/workspace/a3-mtp-ray-investigation-20261116/envs/ci8-clean/lib/python3.12/site-packages')
LEGACY = Path('/root/workspace/a3-validation-20261112/envs/baseline/lib/python3.12/site-packages')


def main():
    records = {}
    for role in ['baseline','native']:
        env = ROOT / 'envs' / f'{role}-stack91'
        assert not env.exists()
        subprocess.run(['/usr/local/python3.12.13/bin/python3.12','-m','venv','--copies','--without-pip',str(env)],check=True)
        site = env / 'lib/python3.12/site-packages'
        entries = []
        for p in SOURCE.iterdir():
            if p.name in ['__pycache__','sitecustomize.py'] or 'lmdeploy' in p.name.lower() or p.name.startswith('__editable__'):
                continue
            assert 'dlinfer' not in p.name.lower()
            if not (site/p.name).exists():
                (site/p.name).symlink_to(p.resolve(),target_is_directory=p.is_dir())
                entries.append({'name':p.name,'source':str(p.resolve())})
        if role=='baseline':
            for p in LEGACY.iterdir():
                if 'dlinfer' in p.name.lower() or 'triton_ascend_kernels' in p.name:
                    assert not (site/p.name).exists()
                    (site/p.name).symlink_to(p.resolve(),target_is_directory=p.is_dir())
                    entries.append({'name':p.name,'source':str(p.resolve()),'baseline_only':True})
        records[role]={'path':str(env),'entries':entries,'profile':'ci8-clean fixed application dependencies',
                       'no_pip_mutations':True,'baseline_extra_dependencies':'fixed dlinfer3b909 + frozen external kernel slice' if role=='baseline' else None}
    (ROOT/'inventory/current-stack-profiles.json').write_text(json.dumps(records,indent=2)+'\n')


if __name__=='__main__':main()
