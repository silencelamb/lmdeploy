"""Audit complete primary matrices and render snapshots without touching their data."""
import argparse
import datetime
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
LABELS=['agents-historical-r0','sage-current-r0','agents-current-r0',
        'agents-norm-r0','sage-norm-r0','agents-norm-short-r0']


def main():
    p=argparse.ArgumentParser();p.add_argument('--pids',type=int,nargs='+',required=True);a=p.parse_args()
    identities={pid:Path(f'/proc/{pid}/stat').read_text().split()[21] for pid in a.pids}
    rendered=set();events=[]
    def alive(pid,start):
        try:
            f=Path(f'/proc/{pid}/stat').read_text().split()
            return f[21]==start and f[2]!='Z'
        except FileNotFoundError:return False
    def run(command):
        before=datetime.datetime.now(datetime.timezone.utc).isoformat()
        result=subprocess.run(command,capture_output=True,text=True)
        events.append({'command':command,'start_utc':before,'returncode':result.returncode,
                       'stdout':result.stdout,'stderr':result.stderr})
        (ROOT/'results/audit-watcher-r0.json').write_text(json.dumps(events,indent=2)+'\n')
        print('AUDIT_STEP',command[-1],result.returncode,flush=True)
        return result.returncode==0
    while True:
        still_running=any(alive(pid,start) for pid,start in identities.items())
        for label in LABELS:
            progress=ROOT/'results'/f'{label}-progress.json'
            if not progress.exists():continue
            try:data=json.loads(progress.read_text())
            except json.JSONDecodeError:continue
            if not data.get('complete'):continue
            work=ROOT/'results'/f'{label}-work-audit.json'
            if not work.exists():
                run([sys.executable,str(ROOT/'scripts/audit_work.py'),'--label',label,'--output',str(work)])
            stats=ROOT/'results'/f'{label}-statistics.json'
            if stats.exists() and work.exists() and label not in rendered:
                target=ROOT/'artifacts'/f'report-ready-after-{label}.md'
                if target.exists() or run([sys.executable,str(ROOT/'scripts/render_report.py'),'--output',str(target)]):
                    rendered.add(label)
                    audit=json.loads(work.read_text());summary=json.loads(stats.read_text())
                    print('READY',label,'work',audit['qualified'],
                          'all_metrics_accepted',summary['all_metrics_accepted'],flush=True)
        if not still_running:break
        time.sleep(5)
    print('WATCHER_DONE',sorted(rendered),flush=True)


if __name__=='__main__':main()
