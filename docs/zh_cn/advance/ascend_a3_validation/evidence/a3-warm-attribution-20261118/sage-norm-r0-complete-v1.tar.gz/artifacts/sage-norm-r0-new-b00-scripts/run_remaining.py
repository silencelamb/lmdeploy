"""Serial continuation on NPU0/1; keep failed comparisons and continue independent ones."""
import argparse
import datetime
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--wait-pid', type=int, required=True)
    p.add_argument('--label', required=True)
    a = p.parse_args()
    state_path = ROOT / 'results' / f'{a.label}-suite.json'
    assert not state_path.exists()
    state = {'start_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
             'wait_pid': a.wait_pid, 'steps': [], 'complete': False}
    def save():
        state_path.write_text(json.dumps(state, indent=2) + '\n')
    save()
    process = Path(f'/proc/{a.wait_pid}/stat')
    identity = process.read_text().split()[21] if process.exists() else None
    while process.exists() and process.read_text().split()[21] == identity:
        time.sleep(5)
    def run(name, args):
        command = [sys.executable, *map(str, args)]
        step = {'name': name, 'command': command,
                'start_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
        state['steps'].append(step); save()
        print('START', name, flush=True)
        with (ROOT / 'logs' / f'{name}-supervisor.log').open('x') as log:
            rc = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT).returncode
        step.update(returncode=rc, end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        save(); print('DONE', name, rc, flush=True)
        return rc == 0
    def pilot(label, arm, profile, kind, model, tokens, mtp=0):
        return run(label, [ROOT/'scripts/run_case_current.py', '--arm', arm, '--compiler', profile,
            '--label', label, '--timeout', '2400', '--', ROOT/f'scripts/{kind}_warm_case.py',
            '--label', label, '--model', f'/afs-weights/{model}', '--tokens', tokens, '--pilot',
            '--c1-repeats', 2, '--c4-repeats', 2,
            *(['--mtp', mtp] if kind=='http' else [])])
    def matrix(comparison, current=False):
        label = comparison + '-r0'
        runner = 'run_matrix_current.py' if current else 'run_matrix.py'
        ok = run(label+'-matrix', [ROOT/'scripts'/runner, '--comparison', comparison,
                                 '--blocks', 8, '--label', label])
        if ok:
            run(label+'-statistics', [ROOT/'scripts/analyze_pairs.py', '--label', label,
                '--output', ROOT/'results'/f'{label}-statistics.json'])
        return ok
    norm_ready = pilot('agents-norm-pilot-before-r0', 'norm-before', 'legacy',
                       'pipeline', 'Agents-A1', 256)
    sage_old_ready = pilot('sage-current-pilot-baseline-r0', 'baseline', 'stack91',
                           'http', 'Sage-A1.5', 128, 3)
    sage_new_ready = pilot('sage-current-pilot-current-r0', 'current', 'stack91',
                           'http', 'Sage-A1.5', 128, 3)
    if sage_old_ready and sage_new_ready:
        matrix('sage-current', True)
    matrix('agents-current', True)
    if norm_ready:
        matrix('agents-norm')
        matrix('sage-norm')
    state.update(complete=True, end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    save()


if __name__ == '__main__':
    main()
