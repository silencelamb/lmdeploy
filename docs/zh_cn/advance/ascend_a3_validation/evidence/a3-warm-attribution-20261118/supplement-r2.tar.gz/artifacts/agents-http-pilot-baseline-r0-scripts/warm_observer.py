"""Validation-only counters: no tensor copies, synchronization, or sampling changes."""
import collections
import functools
import importlib
import importlib.metadata
import json
import mmap
import os
from pathlib import Path
import random
import sys
import time

from lmdeploy.pytorch.engine.executor.ray_executor import RayWorkerWrapper

CONTROL = None
COUNTS = collections.Counter()
SEEN = set()
EVENTS = []


def phase():
    global CONTROL
    if CONTROL is None:
        descriptor = os.open(os.environ['WARM_CONTROL_PATH'], os.O_RDONLY)
        CONTROL = mmap.mmap(descriptor, 1, access=mmap.ACCESS_READ)
        os.close(descriptor)
    return CONTROL[0]


def event(kind, **details):
    row = dict(kind=kind, phase=phase(), pid=os.getpid(), ns=time.monotonic_ns(), **details)
    EVENTS.append(row)
    with (Path(os.environ['WARM_OBSERVER_DIR']) / f'events-{os.getpid()}.jsonl').open('a') as f:
        f.write(json.dumps(row, default=str) + '\n')


def wrap_event(obj, name, kind):
    old = getattr(obj, name)
    if getattr(old, '_warm_observed', False):
        return

    @functools.wraps(old)
    def wrapped(*args, **kwargs):
        event(kind, function=name, target=type(args[0]).__name__ if args else '')
        return old(*args, **kwargs)
    wrapped._warm_observed = True
    setattr(obj, name, wrapped)


def install():
    import numpy as np
    import torch
    import torch_npu  # noqa: F401
    random.seed(42)
    np.random.seed(42)
    torch.manual_seed(42)
    torch.npu.manual_seed(42)
    compiler = importlib.import_module('triton.compiler.compiler')
    wrap_event(compiler, 'compile', 'triton_compile')
    autotuner = importlib.import_module('triton.runtime.autotuner')
    wrap_event(autotuner.Autotuner, '_bench', 'autotune_bench')
    agent = importlib.import_module('lmdeploy.pytorch.engine.model_agent.agent')
    original = agent.model_forward

    @functools.wraps(original)
    def forward(*args, **kwargs):
        model = kwargs.get('model', args[0] if args else None)
        inputs = kwargs.get('inputs', args[1] if len(args) > 1 else None)
        if inputs is not None:
            signature = (type(getattr(model, 'model', model)).__name__, bool(inputs.is_decoding),
                         inputs.input_ids.numel(), inputs.seq_length.numel())
            p = phase()
            COUNTS[(p, signature)] += 1
            if signature not in SEEN:
                SEEN.add(signature)
                event('new_forward_shape', signature=signature)
        return original(*args, **kwargs)
    agent.model_forward = forward
    module = ('dlinfer.framework.lmdeploy_ext.cudagraph.ascend_cudagraph'
              if os.environ['WARM_ROLE'] == 'baseline'
              else 'lmdeploy.pytorch.backends.ascend.graph_runner')
    graph = importlib.import_module(module)
    wrap_event(graph.AscendSingleGraphRunner, 'capture', 'graph_capture')


def dump(rank=None):
    row = dict(pid=os.getpid(), rank=rank, events=EVENTS,
               counts=[{'phase': p, 'signature': s, 'count': n} for (p, s), n in COUNTS.items()],
               dlinfer_modules=[n for n in sys.modules if n.split('.')[0] == 'dlinfer'],
               affinity=sorted(os.sched_getaffinity(0)),
               versions={n: importlib.metadata.version(n) for n in
                         ['torch', 'torch-npu', 'triton-ascend', 'ray', 'numpy', 'transformers']})
    if os.environ['WARM_ROLE'] == 'native':
        assert not row['dlinfer_modules']
    out = Path(os.environ['WARM_OBSERVER_DIR']) / f'summary-{os.getpid()}.json'
    out.write_text(json.dumps(row, indent=2) + '\n')
    return row


class WarmWorker(RayWorkerWrapper):
    def build_model(self):
        install()
        result = super().build_model()
        event('model_loaded', rank=self.rank)
        return result

    def perf_snapshot(self):
        return dump(self.rank)

    def release(self):
        dump(self.rank)
        return super().release()

    def exit(self):
        dump(self.rank)
        return super().exit()
