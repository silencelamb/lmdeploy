"""Same-worker norm attribution only; never replace fresh-process acceptance."""
import argparse
import dataclasses
import hashlib
import json
import os
from pathlib import Path
import shutil
import time

ROOT=Path(__file__).resolve().parents[1]


def main():
    p=argparse.ArgumentParser();p.add_argument('--label',required=True);a=p.parse_args()
    out=ROOT/'results'/f'{a.label}.json';assert not out.exists()
    original=ROOT/'artifacts/triton-norm-after-legacy';cache=ROOT/'artifacts'/f'{a.label}-shared-cache'
    shutil.copytree(original,cache)
    for path in cache.rglob('__grp__*.json'):
        path.write_text(path.read_text().replace(str(original),str(cache)))
    os.environ['TRITON_CACHE_DIR']=str(cache)
    from lmdeploy import pipeline,GenerationConfig,PytorchEngineConfig
    from lmdeploy.pytorch.engine.executor import ray_executor
    from norm_isolation_worker import NormIsolationWorker
    ray_executor.RayWorkerWrapper=NormIsolationWorker
    cfg=PytorchEngineConfig(device_type='ascend',dtype='bfloat16',tp=2,eager_mode=False,
        enable_prefix_caching=False,prefix_cache_state_budget=0,prefill_save_alignment=128,
        prefill_save_last_only=True,max_batch_size=8,session_len=8192,block_size=128,
        max_prefill_token_num=256,cache_max_entry_count=.5,language_model_only=True,logprobs_mode='raw_logprobs')
    data={'label':a.label,'scope':'Same weights/workers/cache norm attribution; synchronization at mode switch/collection, not primary acceptance',
          'config':dataclasses.asdict(cfg),'effective_cache':str(cache),'events':[],'complete':False,
          'old_kernel_source':str(ROOT/'sources/norm-before/lmdeploy/pytorch/kernels/ascend/triton_ops/rms_norm_gated.py')}
    def save():out.write_text(json.dumps(data,indent=2,default=str)+'\n')
    save()
    with pipeline('/afs-weights/Agents-A1',backend_config=cfg,trust_remote_code=True,log_level='WARNING') as pipe:
        executor=pipe.async_engine.engine.executor
        data['workers']=executor.collective_rpc('norm_perf_setup');save()
        def run(bs,rep,mode,kind):
            executor.collective_rpc('norm_perf_mode',(mode,kind=='diagnosis'))
            first=rep*bs if kind=='warmup' else 40+rep*bs
            prompts=[f'Trial {(first+i)//10} item {(first+i)%10}. Explain how a computer stores and retrieves information. '
                +'Include examples of memory, disks, indexes, and cache. '*12 for i in range(bs)]
            rows=[{'ids':[],'times':[]} for _ in prompts]
            gen=GenerationConfig(max_new_tokens=64,do_sample=False,top_k=1,temperature=1.,ignore_eos=True,random_seed=42)
            start=time.monotonic()
            for response in pipe.stream_infer(prompts,gen_config=gen):
                row=rows[response.index]
                if response.token_ids:row['ids'].extend(response.token_ids);row['times'].append([time.monotonic()-start,len(response.token_ids)])
                row['input_token_len']=response.input_token_len;row['cached_tokens']=response.cached_tokens
            elapsed=time.monotonic()-start
            if not all(len(x['ids'])==64 and x['input_token_len']==170 and x['cached_tokens']==0 for x in rows):
                data['failed_batch']={'kind':kind,'batch':bs,'rep':rep,'mode':mode,'responses':rows}
                save()
                raise AssertionError('See failed_batch and retained worker log')
            detail=executor.collective_rpc('norm_perf_collect')
            event={'kind':kind,'batch':bs,'rep':rep,'mode':mode,'elapsed':elapsed,'throughput':64*bs/elapsed,
                   'responses':rows,'workers':detail}
            data['events'].append(event);save();print('ISOLATION',kind,bs,rep,mode,flush=True)
            return event
        for sweep in range(5):
            for mode in (['old','new'] if sweep%2==0 else ['new','old']):
                # The second, diagnostic graph pool starts empty. Capture the
                # power-of-two C4 graph before replaying paddedC3, just as the
                # production engine's startup warmup establishes graph sizes.
                for bs in [1,2,4,3]:run(bs,sweep,mode,'warmup')
        for bs in [1,4]:
            for rep in range(12):
                pair={}
                for mode in (['old','new'] if rep%2==0 else ['new','old']):pair[mode]=run(bs,rep,mode,'diagnosis')
                assert [x['ids'] for x in pair['old']['responses']]==[x['ids'] for x in pair['new']['responses']]
        data['complete']=True;save()


if __name__=='__main__':main()
