"""Start the unmodified HTTP API with observational worker counters."""
from lmdeploy.pytorch.engine.executor import ray_executor
from warm_observer import WarmWorker

ray_executor.RayWorkerWrapper = WarmWorker

if __name__ == '__main__':
    from lmdeploy.cli import run
    run()
