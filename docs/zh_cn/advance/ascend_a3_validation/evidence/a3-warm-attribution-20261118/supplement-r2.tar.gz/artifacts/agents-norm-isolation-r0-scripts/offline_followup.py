"""Detached local follow-up for client disconnects; no automatic pass/goal claim."""
import argparse
import datetime
import json
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[1]


def alive(pid,identity):
    try:
        fields=Path(f'/proc/{pid}/stat').read_text().split()
        return fields[21]==identity and fields[2]!='Z'
    except FileNotFoundError:return False


def main():
    p=argparse.ArgumentParser();p.add_argument('--wait-pid',type=int,required=True);a=p.parse_args()
    path=Path(f'/proc/{a.wait_pid}/stat');identity=path.read_text().split()[21] if path.exists() else None
    record={'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'waiting_pid':a.wait_pid,'steps':[],'complete':False,'goal_complete':False}
    state=ROOT/'results/offline-followup-r0.json'
    assert not state.exists()
    def save():state.write_text(json.dumps(record,indent=2)+'\n')
    def run(label,args):
        command=[sys.executable,*map(str,args)];entry={'label':label,'command':command,
            'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
        record['steps'].append(entry);save();print('START',label,flush=True)
        with (ROOT/'logs'/f'{label}-offline.log').open('x') as log:
            rc=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT).returncode
        entry.update(returncode=rc,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
        print('DONE',label,rc,flush=True);return rc
    save()
    while identity is not None and alive(a.wait_pid,identity):time.sleep(5)
    # Refuse overlapping NPU work, including orphaned or unrelated processes.
    idle=False
    for attempt in range(24):
        info=subprocess.run(['npu-smi','info'],capture_output=True,text=True,timeout=30)
        (ROOT/'inventory/offline-npu-before-r0.txt').write_text(info.stdout+info.stderr)
        process_table=info.stdout.split('Process id',1)[-1]
        occupied=re.findall(r'^\|\s*0\s+[01]\s*\|\s*(\d+)\s*\|',process_table,re.M)
        if info.returncode==0 and not occupied:idle=True;break
        time.sleep(5)
    record['npu_idle_before_operator_probe']=idle;save()
    for label in ['agents-historical-profile-r0','agents-norm-short-profile-r1']:
        progress=ROOT/'results'/f'{label}-progress.json';output=ROOT/'results'/f'{label}-diagnosis.json'
        if progress.exists() and json.loads(progress.read_text()).get('complete') and not output.exists():
            run(label+'-offline-analysis',[ROOT/'scripts/analyze_profile.py','--label',label,'--output',output])
    if idle:
        label='chunk-o-binary-pair-r0'
        run(label,[ROOT/'scripts/run_case.py','--arm','norm-before','--compiler','legacy','--devices','0',
            '--label',label,'--timeout','900','--',ROOT/'scripts/kernel_binary_pair.py','--label',label])
    for label in ['agents-historical-r0','sage-current-r0','agents-current-r0','agents-norm-r0',
                  'sage-norm-r0','agents-norm-short-r0','agents-historical-profile-r0','agents-norm-short-profile-r1']:
        progress=ROOT/'results'/f'{label}-progress.json'
        if progress.exists() and json.loads(progress.read_text()).get('complete'):
            run(label+'-bundle-r0',[ROOT/'scripts/archive_runs.py','--matrix',label,
                '--output',ROOT/'artifacts/final-bundles-r0'/f'{label}-complete-v1.tar.gz',
                '--manifest',ROOT/'artifacts/final-bundles-r0'/f'{label}-complete-v1-manifest.json'])
    run('offline-report-r0',[ROOT/'scripts/render_report.py','--output',ROOT/'artifacts/report-after-offline-r0.md'])
    record.update(complete=True,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
    (ROOT/'OFFLINE_STATUS.md').write_text('# 后台接续结果\n\n后台步骤已结束，不等于全部性能通过或根因已解决。\n\n'
        +f'开始UTC：{record["start_utc"]}；结束UTC：{record["end_utc"]}。\n\n'
        +'读取results/offline-followup-r0.json查看每步退出码、命令与失败记录；读取results/*-diagnosis.json和chunk-o-binary-pair-r0.json分析具体耗时。\n\n'
        +'完整新归档在artifacts/final-bundles-r0，尚需审查后上传GitHub并更新最终报告/PR。主结果和所有旧证据未删除。\n')
    print('OFFLINE_STEPS_FINISHED_REVIEW_REQUIRED',flush=True)


if __name__=='__main__':main()
