"""Research worker audit; computation differs only by the committed selector flag."""
import ast
import hashlib
import inspect
import json
import os
from pathlib import Path

from validation_worker import SeededWorker as OriginalSeededWorker
from validation_worker import audit_worker, seed_all


class SeededWorker(OriginalSeededWorker):
    def build_model(self):
        from lmdeploy.pytorch.backends.cuda import nsa
        source_path = Path(inspect.getsourcefile(nsa.TritonNSAIndexFP8Impl)).resolve()
        target = Path(os.environ['VALIDATION_WORKTREE']).resolve()
        assert source_path.is_relative_to(target)
        source = source_path.read_text()
        calls = [node for node in ast.walk(ast.parse(source))
                 if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                 and node.func.attr == '_sparse_index_topk']
        assert len(calls) == 1
        assert any(kw.arg == 'deterministic' and isinstance(kw.value, ast.Constant)
                   and kw.value.value is True for kw in calls[0].keywords)
        selector = nsa._get_sparse_index_topk(2048)
        assert selector is not None, 'GLM must use the intended stable TileLang selector'
        selector_path = Path(inspect.getsourcefile(selector)).resolve()
        assert selector_path.is_relative_to(target)
        record = dict(pid=os.getpid(), source=str(source_path),
                      source_sha256=hashlib.sha256(source.encode()).hexdigest(),
                      selector=str(selector_path),
                      selector_sha256=hashlib.sha256(selector_path.read_bytes()).hexdigest(),
                      deterministic=True, topk=2048, imported_worktree=str(target))
        out = Path(os.environ['VALIDATION_AUDIT'])
        out.mkdir(parents=True, exist_ok=True)
        (out / f'stable-selector-{os.getpid()}.json').write_text(json.dumps(record, indent=2))
        # The original worker resets all seeds immediately before the unchanged build.
        return super().build_model()
