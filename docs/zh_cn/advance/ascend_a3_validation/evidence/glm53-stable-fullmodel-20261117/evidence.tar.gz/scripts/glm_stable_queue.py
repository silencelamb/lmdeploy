"""Full-checkpoint TP8 stable-selector controls, preserving the original workloads."""
import datetime
import json
import os
from pathlib import Path
import subprocess
import sys

from compare import compare

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'glm-stable-full-20261117'
OUT.mkdir(exist_ok=True)
MODEL = '/mnt/shared-storage-user/gpfs2-shared-public/huggingface/hub/models--zai-org--GLM-5.3/snapshots/e0b07fd2751b42d5efa199cc02c2b271deadc516'
STATE = OUT / 'progress.json'
assert not STATE.exists(), 'Use a new output directory/label; do not overwrite an existing campaign'
state = dict(started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             scope='Full GLM-5.3 TP8 checkpoint; corrected base and corrected f64; only stable selector flag changed',
             configurations=[], current=None, complete=False)


def save():
    STATE.write_text(json.dumps(state, indent=2))


save()
for mtp in (0, 3):
    for eager, prefix in ((False, False), (False, True), (True, False), (True, True)):
        key = f'glm-det-full-20261117-{("eager" if eager else "graph")}-p{int(prefix)}-m{mtp}'
        files = {}
        runs = []
        cfg = dict(key=key, mtp=mtp, eager=eager, prefix=prefix, runs=runs)
        state['configurations'].append(cfg)
        for role, rep in [('base', 0), ('pr', 0), ('pr', 1), ('base', 1)]:
            label = f'{key}-{role}-r{rep}'
            output = OUT / (label + '.json')
            assert not output.exists()
            files[(role, rep)] = output
            state['current'] = label
            save()
            env = os.environ.copy()
            env['VALIDATION_PROFILE'] = 'matched-f64-glm-stable-full-20261117'
            env['VALIDATION_GPU_BLOCKS'] = str(4276 if mtp == 0 else 4097)
            cmd = [sys.executable, str(ROOT / 'scripts/run_stable.py'),
                   '--role', 'glm-det-' + role, '--label', label,
                   '--gpus', '0,1,2,3,4,5,6,7', '--', 'python',
                   str(ROOT / 'scripts/model_case_stable.py'), '--model', MODEL,
                   '--tp', '8', '--mtp', str(mtp), '--method', 'deepseek_mtp',
                   '--output', str(output)]
            if eager:
                cmd.append('--eager')
            if prefix:
                cmd.append('--prefix')
            print('START', label, flush=True)
            result = subprocess.run(cmd, env=env)
            record = dict(label=label, exit_code=result.returncode, output=str(output))
            runs.append(record)
            save()
            if result.returncode != 0:
                state['stopped_reason'] = 'run failed; inspect before continuing'
                save()
                sys.exit(result.returncode or 1)
            data = json.loads(output.read_text())
            assert data['complete']
            assert data['effective_config']['num_gpu_blocks'] == int(env['VALIDATION_GPU_BLOCKS'])
            print('DONE', label, flush=True)
        comparisons = []
        for kind, left, right in [('baseline_self', ('base', 0), ('base', 1)),
                                  ('pr_self', ('pr', 0), ('pr', 1)),
                                  ('cross_r0', ('base', 0), ('pr', 0)),
                                  ('cross_r1', ('base', 1), ('pr', 1))]:
            comparisons.append(dict(kind=kind, **compare(files[left], files[right])))
        cfg['comparisons'] = comparisons
        (OUT / (key + '-comparison.json')).write_text(json.dumps(cfg, indent=2))
        save()
        print('COMPARE', key, [(c['kind'], c['equal']) for c in comparisons], flush=True)
        if not all(c['equal'] for c in comparisons):
            state['stopped_reason'] = 'first full-model comparison difference; preserve and localize'
            save()
            sys.exit(2)
state['current'] = None
state['complete'] = True
state['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
save()
print('ALL_COMPLETE', flush=True)
