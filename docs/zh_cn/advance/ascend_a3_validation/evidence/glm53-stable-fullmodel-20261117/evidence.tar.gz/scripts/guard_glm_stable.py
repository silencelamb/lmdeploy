"""Detached GPU-host guardian: observe the existing controller, resume only interruptions."""
import datetime
import fcntl
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'glm-stable-full-20261117'


def read(path):
    try:
        return json.loads(path.read_text())
    except (FileNotFoundError, json.JSONDecodeError):
        return None


def alive(info):
    try:
        fields = Path(f'/proc/{info["pid"]}/stat').read_text().rsplit(')', 1)[1].split()
        return fields[0] != 'Z' and fields[19] == info['start_ticks']
    except FileNotFoundError:
        return False


def main():
    lock = (ROOT / 'cache/locks/glm-stable-guardian.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    original = read(OUT / 'original-controller.json')
    assert original
    print('GUARD_READY', os.getpid(), 'session', os.getsid(0), 'observing', original, flush=True)
    while True:
        state = read(OUT / 'progress.json') or {}
        status = dict(time_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                      guardian_pid=os.getpid(), session_id=os.getsid(0), parent_pid=os.getppid(),
                      original_controller_alive=alive(original), current=state.get('current'),
                      completed_runs=sum(len(c.get('runs', [])) for c in state.get('configurations', [])),
                      complete=state.get('complete', False), stopped_reason=state.get('stopped_reason'))
        temp = OUT / 'guardian-status.tmp'
        temp.write_text(json.dumps(status, indent=2));temp.replace(OUT / 'guardian-status.json')
        if state.get('complete') or state.get('stopped_reason'):
            subprocess.run([sys.executable, str(ROOT / 'scripts/audit_glm_stable.py')], check=True)
            print('GUARD_FINISHED', status, flush=True)
            return
        if not status['original_controller_alive']:
            print('CONTROLLER_INTERRUPTED; preserving existing artifacts and resuming', flush=True)
            result = subprocess.run([sys.executable, str(ROOT / 'scripts/resume_glm_stable.py')], cwd=ROOT)
            subprocess.run([sys.executable, str(ROOT / 'scripts/audit_glm_stable.py')], check=False)
            end = read(OUT / 'progress.json') or {}
            status.update(resume_exit_code=result.returncode, complete=end.get('complete', False),
                          stopped_reason=end.get('stopped_reason'),
                          completed_runs=sum(len(c.get('runs', [])) for c in end.get('configurations', [])))
            (OUT / 'guardian-status.json').write_text(json.dumps(status, indent=2))
            print('GUARD_RESUME_FINISHED', status, flush=True)
            return
        time.sleep(10)


if __name__ == '__main__':
    main()
