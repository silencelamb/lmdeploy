"""Read-only full-model result audit; preserves cache-state distinctions."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'glm-stable-full-20261117'


def first_difference(a, b):
    for i, (ta, tb) in enumerate(zip(a['token_ids'], b['token_ids'])):
        if ta != tb:
            return dict(token_index=i, kind='token', left=ta, right=tb,
                        identical_token_history=a['token_ids'][:i])
        if a['score_bits'][i] != b['score_bits'][i]:
            return dict(token_index=i, kind='topk_set_or_score_bits',
                        left=a['score_bits'][i], right=b['score_bits'][i],
                        identical_token_history=a['token_ids'][:i])
    if len(a['token_ids']) != len(b['token_ids']):
        return dict(kind='output_length')
    return None


def main():
    progress = json.loads((OUT / 'progress.json').read_text())
    records = []
    replays = []
    for cfg in progress['configurations']:
        for run in cfg['runs']:
            if run['exit_code'] != 0:
                continue
            path = Path(run['output'])
            raw = path.read_bytes()
            data = json.loads(raw)
            assert data['complete']
            events = {e['label']: e for e in data['events']}
            rows = [r for e in data['events'] for r in e['responses']]
            counts = dict(responses=len(rows), tokens=sum(len(r['token_ids']) for r in rows),
                          scores=sum(len(v) for r in rows for v in r['score_bits']))
            assert counts == dict(responses=23, tokens=1408, scores=7040), counts
            records.append(dict(label=run['label'], path=str(path),
                                sha256=hashlib.sha256(raw).hexdigest(), **counts,
                                effective_config=data['effective_config'], versions=data['versions'],
                                load_seconds=data['load_seconds']))
            for left, right in [('single-before', 'single-after'),
                                ('batch-eight', 'batch-eight-repeat'),
                                ('long-context', 'long-context-replay')]:
                assert events[left]['prompts'] == events[right]['prompts']
                for i, (a, b) in enumerate(zip(events[left]['responses'], events[right]['responses'])):
                    diff = first_difference(a, b)
                    replays.append(dict(label=run['label'], left_event=left, right_event=right,
                                        response=i, tokens_equal=a['token_ids'] == b['token_ids'],
                                        score_bits_equal=a['score_bits'] == b['score_bits'],
                                        left_cached_tokens=a['cached_tokens'], right_cached_tokens=b['cached_tokens'],
                                        same_cache_hit_count=a['cached_tokens'] == b['cached_tokens'],
                                        first_difference=diff))
    result = dict(full_runs=len(records), configurations_started=len(progress['configurations']),
                  configurations_complete=sum('comparisons' in c for c in progress['configurations']),
                  primary_comparisons=[{'key': c['key'], 'comparisons': c['comparisons']}
                                       for c in progress['configurations'] if 'comparisons' in c],
                  runs=records, replay_audits=replays,
                  replay_summary=dict(total=len(replays),
                                      tokens_equal=sum(x['tokens_equal'] for x in replays),
                                      score_bits_equal=sum(x['score_bits_equal'] for x in replays),
                                      same_hit_condition_failures=sum(not (x['tokens_equal'] and x['score_bits_equal'])
                                                                     for x in replays if x['same_cache_hit_count']),
                                      different_hit_condition_failures=sum(not (x['tokens_equal'] and x['score_bits_equal'])
                                                                          for x in replays if not x['same_cache_hit_count'])),
                  complete=progress['complete'])
    (OUT / 'result-audit.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ['runs', 'replay_audits', 'primary_comparisons']},
                     ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
