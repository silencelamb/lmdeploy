"""Identical seed and import provenance for Ray model workers."""
import json
import os
from pathlib import Path
import random
import numpy as np
import torch
import lmdeploy
from lmdeploy.pytorch.engine.executor.ray_executor import RayWorkerWrapper

def seed_all():
    random.seed(42); np.random.seed(42); torch.manual_seed(42); torch.cuda.manual_seed_all(42)

def audit_worker(kind):
    target=Path(os.environ['VALIDATION_WORKTREE']).resolve()
    actual=Path(lmdeploy.__file__).resolve()
    assert actual.is_relative_to(target),(actual,target)
    import sys
    assert not any(x.split('.')[0] in {'torch_npu','dlinfer','triton_ascend'} for x in sys.modules)
    p=Path(os.environ['VALIDATION_AUDIT']);p.mkdir(parents=True,exist_ok=True)
    data=dict(pid=os.getpid(),actual=str(actual),target=str(target),ok=True,kind=kind,seed=42,
              torch=torch.__version__,cuda=torch.version.cuda,visible_devices=os.environ.get('CUDA_VISIBLE_DEVICES'))
    if torch.cuda.is_initialized():
        data['cuda_current_device']=torch.cuda.current_device()
        data['peak_allocated']=torch.cuda.max_memory_allocated()
        data['peak_reserved']=torch.cuda.max_memory_reserved()
    (p/f'worker-{os.getpid()}-{kind}.json').write_text(json.dumps(data,indent=2))

class SeededWorker(RayWorkerWrapper):
    def build_model(self):
        seed_all();audit_worker('before-build')
        if os.environ.get('VALIDATION_GLM_TRACE'):
            from trace_glm_long import install
            install()
        if os.environ.get('VALIDATION_DECODE_TRACE'):
            from trace_decode_graph import install
            install()
        if os.environ.get('VALIDATION_HTTP_FREEZE')=='1':
            from trace_first import install
            install()
        result=super().build_model()
        audit_worker('after-build')
        return result

    def stop(self):
        audit_worker('stop')
        return super().stop()
