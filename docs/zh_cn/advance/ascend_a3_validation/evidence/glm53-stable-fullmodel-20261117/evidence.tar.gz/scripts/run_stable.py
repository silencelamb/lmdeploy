"""Research-only launcher: original GPU locks/import guard plus isolated stable-selector worktrees."""
import argparse
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
p = argparse.ArgumentParser()
p.add_argument('--role', choices=['base','pr','pr-f64','glm-det-base','glm-det-pr'], required=True)
p.add_argument('--label', required=True)
p.add_argument('--gpus', default='0')
p.add_argument('command', nargs=argparse.REMAINDER)
a = p.parse_args()
lock_dir=ROOT/'cache/locks';lock_dir.mkdir(parents=True,exist_ok=True)
label_lock=(lock_dir/(a.label+'.lock')).open('a')
fcntl.flock(label_lock,fcntl.LOCK_EX)
prior=ROOT/'logs'/(a.label+'.command.json')
if prior.exists():
    old=json.loads(prior.read_text())
    if 'exit_code' in old:
        print(json.dumps(dict(label=a.label,reused_existing_run=True,exit_code=old['exit_code'])),flush=True)
        sys.exit(old['exit_code'])
    raise RuntimeError('Run label already exists without completion; preserve it and use a new label: '+a.label)
gpu_locks=[]
gpu_ids=sorted(int(x) for x in a.gpus.split(',') if x)
for gpu in gpu_ids:
    handle=(lock_dir/f'gpu-{gpu}.lock').open('a');fcntl.flock(handle,fcntl.LOCK_EX);gpu_locks.append(handle)
def gpu_snapshot():
    if not gpu_ids:return []
    raw=subprocess.check_output(['nvidia-smi','--id='+a.gpus,'--query-gpu=index,memory.used,utilization.gpu','--format=csv,noheader,nounits'],text=True)
    return [dict(index=int(v[0]),memory_mib=int(v[1]),util=int(v[2])) for line in raw.strip().splitlines() if (v:=line.split(','))]
wait_start=time.monotonic()
while True:
    gpu_before=gpu_snapshot()
    if all(x['memory_mib']<=(180 if x['index']==0 else 68) for x in gpu_before):break
    (ROOT/'logs'/(a.label+'.waiting.json')).write_text(json.dumps(dict(waiting_for_idle_gpus=gpu_before,seconds=time.monotonic()-wait_start),indent=2))
    time.sleep(1)
tree = ROOT/'worktrees'/a.role
env = os.environ.copy()
env.update(PYTHONPATH=str(ROOT/'scripts')+':'+str(tree), PYTHONNOUSERSITE='1', PYTHONHASHSEED='42',
    CUDA_VISIBLE_DEVICES=a.gpus, VALIDATION_WORKTREE=str(tree),
    VALIDATION_AUDIT=str(ROOT/'evidence'/'imports'/a.label),
    TRITON_CACHE_DIR=str(ROOT/'cache'/a.role/'triton'), TORCHINDUCTOR_CACHE_DIR=str(ROOT/'cache'/a.role/'inductor'),
    HF_HOME=str(ROOT/'cache'/'hf'), HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1',
    XDG_CACHE_HOME=str(ROOT/'cache'/a.role), TMPDIR=str(ROOT/'cache'/'tmp'),
    LMDEPLOY_TARGET_DEVICE='cuda', TOKENIZERS_PARALLELISM='false')
Path(env['TMPDIR']).mkdir(parents=True,exist_ok=True)
ray_store=ROOT/'cache'/'ray'/a.role
ray_store.mkdir(parents=True,exist_ok=True)
ray_alias=Path('/tmp')/('r5134-'+a.role)
if not ray_alias.exists():ray_alias.symlink_to(ray_store,target_is_directory=True)
assert ray_alias.resolve()==ray_store.resolve()
env['RAY_TMPDIR']=str(ray_alias)
if os.environ.get('VALIDATION_CACHE_ROLE'):
    cache_role=os.environ['VALIDATION_CACHE_ROLE']
    assert cache_role in ['base','pr']
    env['TRITON_CACHE_DIR']=str(ROOT/'cache'/cache_role/'triton')
if os.environ.get('VALIDATION_PROFILE','').startswith('matched-f64'):
    env['TRITON_CACHE_DIR']=str(ROOT/'cache/matched/triton')
cmd=a.command[1:] if a.command[:1]==['--'] else a.command
if cmd[0]=='python': cmd[0]=str(ROOT/'envs'/('base' if a.role in ['base','glm-det-base'] else 'pr')/'bin'/'python')
record=dict(label=a.label, role=a.role, command=cmd, cwd=str(tree), start=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    gpu_before=gpu_before,gpu_lock_wait_seconds=time.monotonic()-wait_start,
    sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=tree,text=True).strip(),
    diff=subprocess.check_output(['git','diff'],cwd=tree,text=True), env={k:env[k] for k in ['PYTHONPATH','CUDA_VISIBLE_DEVICES','PYTHONHASHSEED','VALIDATION_WORKTREE','TRITON_CACHE_DIR','HF_HOME','LMDEPLOY_TARGET_DEVICE']},
    scripts={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in (ROOT/'scripts').glob('*.py')})
record['validation_environment']={k:v for k,v in env.items() if k.startswith('VALIDATION_')}
path=ROOT/'logs'/a.label
snapshots=ROOT/'evidence/script-snapshots'
for filename,sha in record['scripts'].items():
    target=snapshots/sha/filename
    target.parent.mkdir(parents=True,exist_ok=True)
    if not target.exists():target.write_bytes((ROOT/'scripts'/filename).read_bytes())
path.with_suffix('.command.json').write_text(json.dumps(record,indent=2))
start=time.monotonic()
with path.with_suffix('.log').open('w') as log:
    proc=subprocess.Popen(cmd,cwd=tree,env=env,stdout=log,stderr=subprocess.STDOUT,pass_fds=tuple(x.fileno() for x in gpu_locks))
    record['pid']=proc.pid
    path.with_suffix('.command.json').write_text(json.dumps(record,indent=2))
    record['exit_code']=proc.wait()
record['elapsed_s']=time.monotonic()-start
record['gpu_after']=gpu_snapshot()
record['runtime_environment']={k:v for k,v in env.items() if k.startswith(('LMDEPLOY_','CUDA_','TORCH_','PYTORCH_','NCCL_','FLA_','TRITON_')) and not any(s in k.upper() for s in ['TOKEN','KEY','SECRET','PASSWORD'])}
path.with_suffix('.command.json').write_text(json.dumps(record,indent=2))
print(json.dumps({k:record[k] for k in ('label','exit_code','elapsed_s')}),flush=True)
sys.exit(record['exit_code'])
