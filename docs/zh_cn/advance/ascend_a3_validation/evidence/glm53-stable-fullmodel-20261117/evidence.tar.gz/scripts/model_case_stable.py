"""Same full-model workload with the isolated stable-selector source control."""
import argparse
import dataclasses
import importlib.metadata as metadata
import json
import math
import os
from pathlib import Path
import struct
import time

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--model',required=True);p.add_argument('--tp',type=int,required=True)
    p.add_argument('--eager',action='store_true');p.add_argument('--prefix',action='store_true')
    p.add_argument('--mtp',type=int,default=0);p.add_argument('--method',default='qwen3_5_mtp')
    p.add_argument('--output',required=True);p.add_argument('--suite',default='correctness',choices=['correctness','bench','diagnostic'])
    p.add_argument('--long',type=int,default=32768);p.add_argument('--new-tokens',type=int,default=64)
    a=p.parse_args()
    from validation_worker_stable import SeededWorker,seed_all,audit_worker
    from lmdeploy.pytorch.engine.executor import ray_executor
    ray_executor.RayWorkerWrapper=SeededWorker
    seed_all();audit_worker('parent-start')
    if os.environ.get('VALIDATION_TRACE_DIR'):
        from trace_first import install
        install()
    from lmdeploy import pipeline,GenerationConfig,PytorchEngineConfig
    from lmdeploy.messages import SpeculativeConfig
    cfg=PytorchEngineConfig(device_type='cuda',dtype='bfloat16',tp=a.tp,dp=1,ep=1,
        eager_mode=a.eager,enable_prefix_caching=a.prefix,
        prefix_cache_state_budget=16 if a.prefix else 0,prefill_save_alignment=128,
        prefill_save_last_only=True,max_batch_size=8,session_len=65536,
        block_size=64 if 'models--zai-org--GLM-5.3/' in a.model else 128,
        max_prefill_token_num=2048,cache_max_entry_count=.5,language_model_only=True,
        logprobs_mode='raw_logprobs')
    if os.environ.get('VALIDATION_GPU_BLOCKS'):cfg.num_gpu_blocks=int(os.environ['VALIDATION_GPU_BLOCKS'])
    spec=SpeculativeConfig(method=a.method,num_speculative_tokens=a.mtp) if a.mtp else None
    out=Path(a.output);out.parent.mkdir(parents=True,exist_ok=True)
    data=dict(options=vars(a),config=dataclasses.asdict(cfg),spec=dataclasses.asdict(spec) if spec else None,
        versions={n:metadata.version(n) for n in ['torch','triton','flash-linear-attention','fla-core','transformers','numpy','ray']},events=[],complete=False)
    def save():out.write_text(json.dumps(data,ensure_ascii=False,indent=2,default=str))
    save()
    def gen(n=None,lp=5):return GenerationConfig(max_new_tokens=n or a.new_tokens,do_sample=False,top_k=1,temperature=1.,ignore_eos=True,random_seed=42,logprobs=lp)
    prompts=['Compute 17 * 23. Give the result and a brief explanation.',
        '请用一句话解释为什么天空是蓝色的。',
        'Write a Python function that returns the sum of even numbers in a list.',
        'Translate to English: 高效推理需要谨慎管理内存。',
        'A train travels 120 km in 2 hours. What is its average speed?',
        'List the first ten prime numbers in increasing order.',
        'Explain the difference between a stack and a queue with one example.',
        'The secret access code is MAPLE-7391. Repeat only the secret access code.']
    t=time.monotonic()
    with pipeline(a.model,backend_config=cfg,speculative_config=spec,trust_remote_code=True,log_level='INFO') as pipe:
        data['effective_config']=dataclasses.asdict(pipe.backend_config)
        data['load_seconds']=time.monotonic()-t
        def infer(label,batch,n=None):
            t=time.monotonic();rs=pipe(batch,gen_config=gen(n))
            rows=[]
            for r in rs:
                row=dict(token_ids=r.token_ids,text=r.text,logprobs=r.logprobs,
                    input_token_len=r.input_token_len,generate_token_len=r.generate_token_len,
                    cached_tokens=r.cached_tokens,finish_reason=r.finish_reason)
                row['score_bits']=[{str(k):dict(fp32=struct.pack('!f',v).hex(),fp64=struct.pack('!d',v).hex()) for k,v in d.items()} for d in (r.logprobs or [])]
                rows.append(row)
            data['events'].append(dict(label=label,prompts=batch,responses=rows,elapsed=time.monotonic()-t));save()
            for row in rows:
                assert row['finish_reason'] not in ('error','abort'),row
                assert len(row['token_ids'])==(n or a.new_tokens),row
                assert len(row['score_bits'])==len(row['token_ids']),row
                assert all(len(d)>=5 for d in row['score_bits']),row
                assert all(math.isfinite(v) for d in row['logprobs'] for v in d.values()),row
            print('CASE',label,'OK',flush=True)
        if a.suite=='correctness':
            infer('single-before',prompts[:1]);infer('batch-eight',prompts)
            tail='Read the following notes carefully. '+'One two three four five. '*180
            infer('mixed-long-short',[tail+' Summarize in one sentence.',prompts[1],'Hi.'])
            infer('single-after',prompts[:1]);infer('batch-eight-repeat',prompts)
            filler='The archive contains ordinary records of weather and travel. '
            tok=pipe.async_engine.tokenizer
            per=len(tok.encode(filler*101,add_bos=False))-len(tok.encode(filler*100,add_bos=False))
            text=filler*max(1,(a.long-200)//per);mid=len(text)//2
            text=text[:mid]+'\nThe unique verification code for this archive is ORCHID-8246.\n'+text[mid:]+'\nWhat is the unique verification code? Reply with only the code.'
            infer('long-context',[text],32)
            infer('long-context-replay',[text],32)
        elif a.suite=='diagnostic':
            infer('single-before',prompts[:1])
        else:
            for bs in [1,4]:
                batch=[f'Workload C{bs} Q{i}. Explain how computers store information. '+'Discuss memory, disk, files, and cache with examples. '*12 for i in range(bs)]
                for rep in [-1,0]:
                    rows=[dict(token_ids=[],times=[],text='') for _ in batch];start_unix_ns=time.time_ns();t=time.monotonic()
                    for r in pipe.stream_infer(batch,gen_config=gen(lp=None)):
                        row=rows[r.index];now=time.monotonic()-t
                        if r.token_ids: row['times'].append([now,len(r.token_ids)]);row['token_ids'].extend(r.token_ids)
                        row.update(input_token_len=r.input_token_len,cached_tokens=r.cached_tokens,finish_reason=r.finish_reason)
                        row['text']+=r.text
                    elapsed=time.monotonic()-t
                    for row in rows:
                        assert len(row['token_ids'])==a.new_tokens,row
                        row['ttft']=row['times'][0][0]
                        count=len(row['token_ids'])-row['times'][0][1]
                        row['tpot']=(row['times'][-1][0]-row['ttft'])/max(1,count)
                    data['events'].append(dict(label=f'bench-c{bs}-r{rep}',warmup=rep<0,batch=bs,prompts=batch,responses=rows,elapsed=elapsed,throughput=bs*a.new_tokens/elapsed,start_unix_ns=start_unix_ns,end_unix_ns=time.time_ns()));save()
        data['complete']=True;save();audit_worker('parent-finish')
    print('SAVED',out,flush=True)

if __name__=='__main__':main()
