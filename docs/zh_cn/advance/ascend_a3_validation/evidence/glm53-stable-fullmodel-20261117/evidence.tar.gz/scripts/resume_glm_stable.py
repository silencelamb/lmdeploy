"""Resume an interrupted controller without overwriting or masking failed runs."""
import datetime
import json
import os
from pathlib import Path
import subprocess
import sys
import time

from compare import compare

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'glm-stable-full-20261117'
MODEL = '/mnt/shared-storage-user/gpfs2-shared-public/huggingface/hub/models--zai-org--GLM-5.3/snapshots/e0b07fd2751b42d5efa199cc02c2b271deadc516'
STATE = OUT / 'progress.json'


def read(path):
    try:
        return json.loads(path.read_text())
    except (FileNotFoundError, json.JSONDecodeError):
        return None


def main():
    previous = read(STATE) or {}
    if previous.get('complete'):
        return
    if previous.get('stopped_reason'):
        raise RuntimeError('Existing failure requires review; do not automatically retry it')
    manifest = read(OUT / 'manifest.json')
    for role, info in manifest['revisions'].items():
        tree = ROOT / 'worktrees' / role
        assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=tree, text=True).strip() == info['sha']
        assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=tree, text=True)
    state = dict(started_at=previous.get('started_at'), resumed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                 scope=manifest['source_change'], configurations=[], current=None, complete=False)

    def save():
        temp = OUT / 'progress-resume.tmp'
        temp.write_text(json.dumps(state, indent=2))
        temp.replace(STATE)

    def existing_run(logical):
        records = sorted((ROOT / 'logs').glob(logical + '*.command.json'))
        for record_path in records:
            record = read(record_path)
            if record is None:
                continue
            if record.get('exit_code') not in (None, 0):
                raise RuntimeError('Existing run failed; preserve and review: ' + str(record_path))
            label = record['label']
            output = OUT / (label + '.json')
            data = read(output)
            if record.get('exit_code') == 0 and data and data.get('complete'):
                return dict(label=label, logical_label=logical, output=str(output), exit_code=0, adopted_completed_run=True)
        return None

    for mtp in (0, 3):
        for eager, prefix in ((False, False), (False, True), (True, False), (True, True)):
            key = f'glm-det-full-20261117-{("eager" if eager else "graph")}-p{int(prefix)}-m{mtp}'
            cfg = dict(key=key, mtp=mtp, eager=eager, prefix=prefix, runs=[])
            state['configurations'].append(cfg)
            files = {}
            for role, rep in [('base', 0), ('pr', 0), ('pr', 1), ('base', 1)]:
                logical = f'{key}-{role}-r{rep}'
                record = existing_run(logical)
                if record is None:
                    label = logical
                    retry = 0
                    while (ROOT / 'logs' / (label + '.command.json')).exists() or (OUT / (label + '.json')).exists():
                        retry += 1
                        label = logical + f'-resume{retry}'
                    output = OUT / (label + '.json')
                    state['current'] = label
                    save()
                    env = os.environ.copy()
                    env.update(VALIDATION_PROFILE='matched-f64-glm-stable-full-20261117',
                               VALIDATION_GPU_BLOCKS=str(4276 if mtp == 0 else 4097))
                    cmd = [sys.executable, str(ROOT / 'scripts/run_stable.py'), '--role', 'glm-det-' + role,
                           '--label', label, '--gpus', '0,1,2,3,4,5,6,7', '--', 'python',
                           str(ROOT / 'scripts/model_case_stable.py'), '--model', MODEL, '--tp', '8',
                           '--mtp', str(mtp), '--method', 'deepseek_mtp', '--output', str(output)]
                    if eager:
                        cmd.append('--eager')
                    if prefix:
                        cmd.append('--prefix')
                    print('RESUME_START', label, flush=True)
                    result = subprocess.run(cmd, env=env)
                    record = dict(label=label, logical_label=logical, output=str(output), exit_code=result.returncode)
                    if result.returncode:
                        cfg['runs'].append(record)
                        state['stopped_reason'] = 'resumed run failed; preserve and inspect'
                        save()
                        raise RuntimeError(state['stopped_reason'])
                data = read(Path(record['output']))
                assert data and data['complete']
                assert data['effective_config']['num_gpu_blocks'] == (4276 if mtp == 0 else 4097)
                cfg['runs'].append(record)
                files[(role, rep)] = Path(record['output'])
                save()
            cfg['comparisons'] = [dict(kind=kind, **compare(files[left], files[right])) for kind, left, right in
                                  [('baseline_self', ('base', 0), ('base', 1)),
                                   ('pr_self', ('pr', 0), ('pr', 1)),
                                   ('cross_r0', ('base', 0), ('pr', 0)),
                                   ('cross_r1', ('base', 1), ('pr', 1))]]
            (OUT / (key + '-comparison.json')).write_text(json.dumps(cfg, indent=2))
            save()
            if not all(c['equal'] for c in cfg['comparisons']):
                state['stopped_reason'] = 'first comparison difference; preserve and localize'
                save()
                raise RuntimeError(state['stopped_reason'])
        subprocess.run([sys.executable, str(ROOT / 'scripts/audit_glm_stable.py')], check=True)
    state.update(current=None, complete=True, finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    save()


if __name__ == '__main__':
    main()
