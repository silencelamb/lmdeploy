"""Zero tolerance output comparison; stop at first unequal history/score."""
import json
from pathlib import Path
import sys

def compare(left,right):
    a=json.loads(Path(left).read_text());b=json.loads(Path(right).read_text())
    result=dict(left=str(left),right=str(right),equal=False,tokens_checked=0,scores_checked=0)
    if not a.get('complete') or not b.get('complete'):
        return result|dict(reason='incomplete')
    if a['config']!=b['config'] or a['spec']!=b['spec']:
        return result|dict(reason='configuration mismatch')
    if 'effective_config' in a and 'effective_config' in b and a['effective_config']!=b['effective_config']:
        return result|dict(reason='effective configuration mismatch')
    if len(a['events'])!=len(b['events']):return result|dict(reason='event count')
    for ae,be in zip(a['events'],b['events']):
        if ae['label']!=be['label'] or ae['prompts']!=be['prompts']:
            return result|dict(reason='workload mismatch')
        if len(ae['responses'])!=len(be['responses']):return result|dict(reason='response count')
        for ri,(ar,br) in enumerate(zip(ae['responses'],be['responses'])):
            common=dict(event=ae['label'],response=ri,prompt=ae['prompts'][ri])
            for key in ['input_token_len','generate_token_len','cached_tokens','finish_reason']:
                if ar[key]!=br[key]:return result|common|dict(reason=key,left_value=ar[key],right_value=br[key])
            for i,(at,bt) in enumerate(zip(ar['token_ids'],br['token_ids'])):
                common.update(token_index=i,identical_token_history=ar['token_ids'][:i])
                if at!=bt:return result|common|dict(reason='generated token',left_value=at,right_value=bt)
                result['tokens_checked']+=1
                av=ar['score_bits'][i];bv=br['score_bits'][i]
                if av!=bv:return result|common|dict(reason='top-k set or score bits',left_value=av,right_value=bv)
                result['scores_checked']+=len(av)
    result['equal']=True
    return result

if __name__=='__main__':
    result=compare(sys.argv[1],sys.argv[2]);text=json.dumps(result,ensure_ascii=False,indent=2)
    if len(sys.argv)>3:Path(sys.argv[3]).write_text(text)
    concise={k:v for k,v in result.items() if k not in ['prompt','identical_token_history']}
    if 'identical_token_history' in result:concise['identical_history_length']=len(result['identical_token_history'])
    print(json.dumps(concise,ensure_ascii=False,indent=2));sys.exit(0 if result['equal'] else 1)
