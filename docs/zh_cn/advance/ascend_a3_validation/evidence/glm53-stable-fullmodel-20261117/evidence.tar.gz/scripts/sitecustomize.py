"""CUDA validation process guard; also inherited by spawned workers."""
import atexit
import builtins
import importlib
import json
import os
from pathlib import Path
import sys

_forbidden = {'dlinfer', 'torch_npu', 'triton_ascend', 'torch_npu_transfer'}
_original_import = builtins.__import__
_original_import_module = importlib.import_module
_path_checked = False
_freeze_http = os.environ.get('VALIDATION_HTTP_FREEZE')=='1'
_http_trace_installed = False
_http_trace_installing = False

def install_http_trace_after_agent_import():
    global _http_trace_installed, _http_trace_installing
    if not _freeze_http or _http_trace_installed or _http_trace_installing:return
    module=sys.modules.get('lmdeploy.pytorch.engine.model_agent.agent')
    if module is None or not hasattr(module,'BaseModelAgent'):return
    if getattr(getattr(module,'__spec__',None),'_initializing',False):return
    _http_trace_installing=True
    try:
        from trace_first import install
        install()
        _http_trace_installed=True
        out=os.environ.get('VALIDATION_AUDIT')
        if out:
            Path(out).mkdir(parents=True,exist_ok=True)
            (Path(out)/f'http-trace-hook-{os.getpid()}.json').write_text(json.dumps(dict(pid=os.getpid(),installed=True,target=os.environ.get('VALIDATION_WORKTREE'))))
    finally:_http_trace_installing=False

def check_source(name):
    global _path_checked
    target=os.environ.get('VALIDATION_WORKTREE')
    if _path_checked or not target or not (name=='lmdeploy' or name.startswith('lmdeploy.')):return
    mod=sys.modules.get('lmdeploy');actual=getattr(mod,'__file__',None)
    if actual:
        assert Path(actual).resolve().is_relative_to(Path(target).resolve()),(actual,target)
        _path_checked=True
        out=os.environ.get('VALIDATION_AUDIT')
        if out:
            Path(out).mkdir(parents=True,exist_ok=True)
            (Path(out)/f'import-{os.getpid()}.json').write_text(json.dumps(dict(pid=os.getpid(),target=target,actual=actual,ok=True)))

def guarded_import(name, *args, **kwargs):
    if name.split('.')[0] in _forbidden:
        raise ModuleNotFoundError('CUDA validation forbids importing ' + name, name=name)
    result=_original_import(name, *args, **kwargs)
    check_source(name)
    if _freeze_http:install_http_trace_after_agent_import()
    return result

def guarded_import_module(name, *args, **kwargs):
    if name.split('.')[0] in _forbidden:
        raise ModuleNotFoundError('CUDA validation forbids importing ' + name, name=name)
    result=_original_import_module(name, *args, **kwargs)
    check_source(name)
    if _freeze_http:install_http_trace_after_agent_import()
    return result

# Discovery via find_spec must still return None for absent optional packages.
builtins.__import__ = guarded_import
importlib.import_module = guarded_import_module

def audit():
    target = os.environ.get('VALIDATION_WORKTREE')
    out = os.environ.get('VALIDATION_AUDIT')
    mod = sys.modules.get('lmdeploy')
    actual = getattr(mod, '__file__', None)
    loaded = sorted(x for x in sys.modules if x.split('.')[0] in {'dlinfer', 'torch_npu', 'triton_ascend'})
    ok = not loaded and (actual is None or Path(actual).resolve().is_relative_to(Path(target).resolve()))
    if out:
        Path(out).mkdir(parents=True, exist_ok=True)
        (Path(out)/f'{os.getpid()}.json').write_text(json.dumps(dict(pid=os.getpid(), executable=sys.executable,
            target=target, actual=actual, forbidden=loaded, ok=ok, sys_path=sys.path), indent=2))
    if not ok:
        os.write(2, b'FATAL: CUDA validation import audit failed\n')
        os._exit(97)

atexit.register(audit)

if os.environ.get('VALIDATION_SEED_ALL')=='1':
    import random
    import numpy as np
    import torch
    random.seed(42);np.random.seed(42);torch.manual_seed(42);torch.cuda.manual_seed_all(42)

if os.environ.get('VALIDATION_TIMING_TRACE'):
    from trace_host_calls import install
    install()
