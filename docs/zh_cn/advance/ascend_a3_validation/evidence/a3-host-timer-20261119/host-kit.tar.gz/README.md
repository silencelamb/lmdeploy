# CPU18 / CPU44 到期定时器采集

工作负载可以留在工作容器。两台节点无模型时也持续复现。采集程序需要在对应宿主机上运行，或在运维已授权、能使用该宿主内核跟踪事件的诊断环境中运行。所有 CPU 编号是宿主逻辑核编号。

## Python 标准库采集器

在宿主机或获准写私有 tracefs 实例的诊断容器中解压。原机选 18，新机选 44。输出目录应为新目录。

```bash
python3 capture_timer.py --cpu 44 --check
python3 capture_timer.py --cpu 44 --seconds 60 --out timer44-run
```

原机使用 `--cpu 18 --out timer18-run`。只用 Python 标准库和已经可用的内核事件，不依赖 perf 程序或 LMDeploy。脚本建立独立的 tracefs 实例，采集一个 CPU 的 TIMER 软中断、timer 回调进入/退出、可见的嵌套硬 IRQ，以及该内核提供时的 timer_start。结束后关闭并清理自己的实例，保存 `trace.txt`、`summary.json`、`buffer-stats.txt`、`metadata.json`。现有两个工作容器上的能力检查均不能执行真正的内核事件采集。

## 如何看结果

- 先看 `loss_indicators`、`errors`、`complete_vectors` 和 `slow_vectors`。入口/出口在采集起止处可能只记录到单边。单个配对不完整的长窗不参与函数排名，存在记录丢失时不输出函数排名。
- 函数排名在 `functions_in_complete_slow_vectors`，区分单次回调最长耗时和同一向量中同函数多次调用的累计耗时。扣除记录到的嵌套硬 IRQ；仍是墙钟跨度，不等于纯指令耗时。若回调内大量时间花在等待锁或设备，区分二者还需要相同窗口的内核栈。
- 如果函数名出现 `[module]`，可读出所属模块。如果符号不可见，应保留原始记录，结合这次运行匹配的内核/模块符号解析。探针发现“上次结束后约 2 秒并按定时器轮取整”的时间特征，可重点核对 250 Hz 内核上 `timeout_ticks` 接近 500 的被重置对象。采集不按 500 过滤。timer_start 限于本 CPU；从其他核重新挂定时器的启动记录可能不在这份数据中。
- `unexplained_after_callbacks_and_known_irqs_ms` 给出长向量内扣除回调与可见硬 IRQ 后的剩余时间。如回调无法覆盖大部分长窗，需要结合内核栈检查分派、锁及其他路径。

保留好的文本可在普通工作容器内重新分析。

```bash
python3 capture_timer.py --cpu 44 --parse timer44-run/trace.txt --out timer44-reparsed.json
```

普通工作容器也可以离线分析平台已有的带 CPU、时间、事件名、timer 对象与函数字段的 perf script 文本。使用 perf 作为采集后端的备选版本是 `timer_capture.py`，适用于有系统级 perf 权限、相应 tracepoint ID 可见且装有 perf 的环境。
