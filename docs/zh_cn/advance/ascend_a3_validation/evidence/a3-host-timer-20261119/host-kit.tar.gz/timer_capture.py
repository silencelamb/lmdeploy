"""Collect CPU-local TIMER vector/callback entry and exit using an already-authorized host perf installation."""
import argparse
import json
import re
import shutil
import subprocess
from collections import Counter
from decimal import Decimal
from pathlib import Path

EVENTS=('irq:softirq_entry','irq:softirq_exit','timer:timer_expire_entry','timer:timer_expire_exit',
        'irq:irq_handler_entry','irq:irq_handler_exit')
LINE=re.compile(r'\[(\d+)\]\s+(\d+\.\d+):\s+(irq:softirq_(?:entry|exit)|timer:timer_expire_(?:entry|exit)|irq:irq_handler_(?:entry|exit)):\s*(.*)')
def attr(body,key):
    m=re.search(r'(?:^|\s)'+key+r'=([^\s,]+)',body)
    return m.group(1) if m else None

def analyze(lines,cpu):
    current=None;results=[];invalid=Counter();lost=0
    for line in lines:
        if re.search(r'PERF_RECORD_LOST|LOST [0-9]+ events?|lost events',line,re.I):lost+=1
        m=LINE.search(line)
        if not m or int(m[1])!=cpu:continue
        t=int(Decimal(m[2])*1_000_000_000);name=m[3];body=m[4]
        if name.startswith('irq:softirq_'):
            if attr(body,'vec')!='1' and '[action=TIMER]' not in body:continue
            if name.endswith('entry'):
                if current is not None:invalid['new_entry_before_exit']+=1
                current=dict(a=t,callbacks=[],pending=None,hardirq=[],irq_stack=[],valid=True)
            else:
                if current is None:invalid['orphan_vector_exit']+=1;continue
                if current['pending'] or current['irq_stack']:current['valid']=False;invalid['open_child_at_exit']+=1
                current['b']=t;current['wall_ms']=(t-current['a'])/1e6
                current['in_irq_ms']=sum((b-a)/1e6 for a,b in current['hardirq'])
                current['in_callbacks_ms']=sum(c['wall_ms'] for c in current['callbacks'])
                if current['wall_ms']>=50:results.append(current)
                current=None
            continue
        if current is None:continue
        if name=='irq:irq_handler_entry':
            current['irq_stack'].append((attr(body,'irq'),t))
        elif name=='irq:irq_handler_exit':
            if not current['irq_stack'] or current['irq_stack'][-1][0]!=attr(body,'irq'):
                invalid['irq_pairing']+=1;current['valid']=False;continue
            _,begin=current['irq_stack'].pop()
            if not current['irq_stack']:current['hardirq'].append((begin,t))
        elif name=='timer:timer_expire_entry':
            obj=attr(body,'timer');fn=attr(body,'function')
            if not obj or not fn or current['pending']:current['valid']=False;invalid['callback_entry']+=1
            current['pending']=(obj,fn,t)
        else:
            pending=current['pending']
            if not pending or pending[0]!=attr(body,'timer'):
                current['valid']=False;invalid['callback_exit']+=1;continue
            obj,fn,a=pending
            hard=sum(max(0,min(t,y)-max(a,x)) for x,y in current['hardirq'])/1e6
            current['callbacks'].append(dict(timer=obj,function=fn,begin_ns=a,end_ns=t,wall_ms=(t-a)/1e6,hardirq_overlap_ms=hard))
            current['pending']=None
    if current:invalid['trailing_partial_vector']+=1
    if lost:invalid['reported_loss']+=lost
    functions=Counter()
    for x in results:
        if x['valid'] and not lost:
            for v in x['callbacks']:functions[v['function']]+=v['wall_ms']-v['hardirq_overlap_ms']
    return dict(slow_timer_vectors=results,callback_time_excluding_nested_hardirq_ms=functions,invalid=invalid,lost_records_reported=lost)

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--cpu',type=int,default=18);ap.add_argument('--seconds',type=int,default=60)
    ap.add_argument('--out',type=Path);ap.add_argument('--parse',type=Path);ap.add_argument('--check',action='store_true');o=ap.parse_args()
    if o.parse:
        with o.parse.open() as f:result=analyze(f,o.cpu)
        text=json.dumps(result,indent=2)
        if o.out:o.out.write_text(text+'\n')
        else:print(text)
        return
    roots=[Path('/sys/kernel/tracing'),Path('/sys/kernel/debug/tracing')]
    root=next((p for p in roots if (p/'events/timer/timer_expire_entry/id').exists()),None)
    available={e:bool(root and (root/'events'/e.replace(':','/')/'id').exists()) for e in EVENTS}
    env=dict(perf=shutil.which('perf'),tracefs=str(root) if root else None,events=available)
    if o.check or not env['perf'] or not all(available.values()):
        print(json.dumps(env,indent=2));return 0 if env['perf'] and all(available.values()) else 2
    if o.out is None:ap.error('--out is required for a live trace')
    o.out.mkdir(parents=True,exist_ok=False)
    data=o.out/'timer.data';log=o.out/'record.log'
    args=[env['perf'],'record','-a','-C',str(o.cpu),'--clockid','mono','-m','1024','-o',str(data)]
    for ev in EVENTS:args+=['-e',ev]
    args+=['--','sleep',str(o.seconds)]
    (o.out/'configuration.json').write_text(json.dumps(dict(env=env,command=args),indent=2)+'\n')
    with log.open('w') as f:subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,check=True)
    raw=o.out/'events.txt'
    with raw.open('w') as f:subprocess.run([env['perf'],'script','--show-lost-events','--ns','-F','comm,tid,cpu,time,event,trace','-i',str(data)],stdout=f,check=True)
    with raw.open() as f:result=analyze(f,o.cpu)
    (o.out/'timer-summary.json').write_text(json.dumps(result,indent=2)+'\n')
    print('slow TIMER vectors',len(result['slow_timer_vectors']),'loss reports',result['lost_records_reported'])
if __name__=='__main__':raise SystemExit(main())
