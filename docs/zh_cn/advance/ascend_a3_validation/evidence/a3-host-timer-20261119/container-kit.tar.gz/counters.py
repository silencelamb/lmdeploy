"""Separate clocks for architectural timer IRQs and scheduler/CPU accounting."""
import argparse
import gzip
import json
import os
import time
from pathlib import Path

def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def read(p):
    try:return p.read_text().strip()
    except OSError:return ''
def timer_id():
    conventional=Path('/sys/kernel/irq/12')
    if read(conventional/'actions')=='arch_timer':return 12
    hits=[int(d.name) for d in Path('/sys/kernel/irq').glob('[0-9]*') if read(d/'actions')=='arch_timer']
    if len(hits)!=1:raise RuntimeError(('arch_timer',hits))
    return hits[0]
def cpu_state(cores):
    before=time.monotonic_ns()
    result={}
    for line in Path('/proc/stat').read_text().splitlines():
        w=line.split()
        if w[0].startswith('cpu') and w[0][3:].isdigit() and int(w[0][3:]) in cores:
            result[int(w[0][3:])]=list(map(int,w[1:9]))
        if w[0]=='intr':break
    split=time.monotonic_ns();sched={}
    for line in Path('/proc/schedstat').read_text().splitlines():
        a=line.split()
        if a[0].startswith('cpu') and a[0][3:].isdigit() and int(a[0][3:]) in cores:
            sched[int(a[0][3:])]=list(map(int,a[7:10]))
    return [before,split,time.monotonic_ns(),result,sched]
def main():
    p=argparse.ArgumentParser();p.add_argument('out',type=Path);p.add_argument('mode',choices=['irq','system']);p.add_argument('hot',type=int);p.add_argument('control',type=int);p.add_argument('--observer',type=int);p.add_argument('--max-seconds',type=int,default=150);a=p.parse_args()
    cpu=a.observer if a.observer is not None else (85 if a.mode=='irq' else 87); os.sched_setaffinity(0,{cpu})
    stop=a.out/'sampling.stop';cores={a.hot,a.control};src=None;fd=None
    if a.mode=='irq':
        src=timer_id();fd=os.open(f'/sys/kernel/irq/{src}/per_cpu_count',os.O_RDONLY)
    period=1_000_000 if a.mode=='irq' else 20_000_000
    due=time.monotonic_ns();deadline=due+a.max_seconds*1_000_000_000;frames=0;skipped=0
    with gzip.open(a.out/f'{a.mode}.jsonl.gz','xt',compresslevel=1) as f:
        while time.monotonic_ns()<deadline and not stop.exists():
            if fd is not None:
                l=time.monotonic_ns();vs=os.pread(fd,32000,0).split(b',',max(cores)+1)
                row=[l,time.monotonic_ns(),int(vs[a.hot]),int(vs[a.control])]
            else:row=cpu_state(cores)
            f.write(json.dumps(row,separators=(',',':'))+'\n');frames+=1
            due+=period;now=time.monotonic_ns()
            if due<=now:
                lost=(now-due)//period+1;due+=lost*period;skipped+=lost
            time.sleep(max(0,(due-time.monotonic_ns())/1e9))
    if fd is not None:os.close(fd)
    save(a.out/f'{a.mode}-quality.json',dict(cpu=cpu,hot=a.hot,control=a.control,irq=src,period_ns=period,frames=frames,
          skipped_targets=skipped,complete=stop.exists()))
if __name__=='__main__':main()
