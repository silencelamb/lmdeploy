"""Compare observed in-task scheduling, local architectural IRQ deliveries and TIMER windows."""
import argparse
import csv
import gzip
import json
from collections import Counter
from pathlib import Path
from statistics import median
import numpy as np


SWITCH=np.dtype([('ns','<u8'),('tid','<u4'),('cpu','<u2'),('away','u1'),('preempt','u1')])
def load(path):return json.loads(path.read_bytes())
def save(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def tsv(path):return list(csv.DictReader(path.open(),delimiter='\t'))
def jrows(path):
    with gzip.open(path,'rt') as f:return [json.loads(s) for s in f]
def qt(vs):
    return [float(x) for x in np.quantile(vs,[0,.5,.9,1])] if len(vs) else None

def read_vectors(p,c,file_prefix='probe-out'):
    times=[];starts=[];vec=[];labels=None
    with gzip.open(p/f'{file_prefix}-softirqs.csv.gz','rt') as f:
        for v in csv.DictReader(f):
            if labels is None:labels=[k.rsplit('_',1)[0] for k in v if k.endswith('_'+str(c))]
            times.append(int(v['end_ns']));starts.append(int(v['begin_ns']));vec.append([int(v[f'{k}_{c}']) for k in labels])
    t=np.asarray(times);d=np.diff(np.asarray(vec),axis=0);idx=np.flatnonzero(np.any(d>0,axis=1))
    return t[idx+1],[[k for j,k in enumerate(labels) if d[i,j]] for i in idx],dict(frames=len(t),read_span_p99_ms=float(np.quantile((t-np.array(starts))/1e6,.99)),frame_gap_p99_ms=float(np.quantile(np.diff(t)/1e6,.99)))

def read_gaps(p,prefix,c,*,full_prefix=False):
    a=[]
    name=prefix if full_prefix else prefix+'-out'
    for r in csv.DictReader((p/f'{name}-cpu{c}.csv').open()):
        start,deadline,end,cpu=[int(r[k]) for k in ('before_ns','deadline_ns','after_ns','thread_delta_ns')]
        if end-deadline>100_000_000:
            a.append(dict(a=start,b=end,late_ms=(end-deadline)/1e6,thread_ms=cpu/1e6))
    return a

def read_switch(p,meta):
    counts={int(v['tid']):v for v in tsv(p/'switch-counts.tsv')};opens=tsv(p/'switch-tids.tsv')
    assert all(v['fd_success']=='1' for v in opens)
    with gzip.open(p/'switch-events.bin.gz','rb') as f:r=np.frombuffer(f.read(),dtype=SWITCH)
    tasks={};quality=[]
    for kind,group in meta['roles'].items():
        for cp,tid in group.items():
            c=int(cp);x=counts[tid];v=r[r['tid']==tid]
            assert int(x['lost'])==int(x['invalid'])==0 and len(v)==int(x['records'])
            assert np.all(v['cpu']==c) and np.all(v['away']<2)
            t=v['ns'].astype(np.int64);out=v['away'].astype(bool)
            assert np.all(np.diff(t)>=0) and np.all(out[1:]!=out[:-1])
            opened=int(x['opened_ns']);end=meta['b']
            if not len(t):raise ValueError(('no switch anchor',c,tid))
            ins=np.flatnonzero(~out)
            spans=[]
            if out[0]:spans.append((opened,int(t[0])))
            for i in ins:spans.append((int(t[i]),int(t[i+1]) if i+1<len(t) else end))
            tasks[kind,c]=dict(ins=t[~out],outs=t[out],preempt_outs=t[out&v['preempt'].astype(bool)],spans=spans,opened=opened,tid=tid)
            quality.append(dict(kind=kind,cpu=c,tid=tid,records=len(v),lost=0,invalid=0,fd_open_ns=opened))
    return tasks,quality
def residency(tasks,c,l,r):
    fragments=[]
    for (kind,cpu),v in tasks.items():
        if cpu!=c:continue
        fragments.extend((max(l,x),min(r,y)) for x,y in v['spans'] if x<r and y>l)
    merge=[]
    for x,y in sorted(fragments):
        if y<=x:continue
        if merge and x<=merge[-1][1]:merge[-1][1]=max(merge[-1][1],y)
        else:merge.append([x,y])
    return sum(y-x for x,y in merge)/1e6
def interval_monitors(phase,l,r):
    # All samples used for inner intervals start and finish inside [l,r].
    t0,t1,v,ss0,ss1,ss2,cpst,sched=phase
    i=np.searchsorted(t0,l);j=np.searchsorted(t1,r,'right')-1
    s=np.searchsorted(ss0,l);e=np.searchsorted(ss2,r,'right')-1
    if not (0<=i<j<len(t0) and 0<=s<e<len(ss0)):return None
    result={}
    for col in (0,1):
        ct=v[i:j+1,col];ts=t1[i:j+1]
        changed=ts[1:][np.diff(ct)>0]
        segments=np.diff(np.r_[l,changed,r])/1e6
        result[col]=dict(irq_count=int(ct[-1]-ct[0]),irq_observed_ms=(int(ts[-1])-int(ts[0]))/1e6,
                         longest_no_observed_irq_ms=float(np.max(segments)),sched_observed_ms=(int(ss2[e])-int(ss2[s]))/1e6,
                         sched_slices=int(sched[e,col,2]-sched[s,col,2]),rq_runtime_ms=(int(sched[e,col,0])-int(sched[s,col,0]))/1e6,
                         rq_wait_ms=(int(sched[e,col,1])-int(sched[s,col,1]))/1e6)
    result['largest_irq_sample_gap_ms']=float(np.max(np.diff(t1[i:j+1]))/1e6)
    return result

def inspect(p, combine_peers=False):
    meta=load(p/'meta.json');hot,ctrl=meta['hot'],meta['control'];tasks,quality=read_switch(p,meta)
    change,kinds,q=read_vectors(p,hot);gaps=read_gaps(p,'probe',hot)
    zeros=read_gaps(p,'probe',ctrl); peers=read_gaps(p,'peer',hot) if meta['dual'] else []
    original_n=len(gaps);unmatched=0
    if combine_peers:
        combined=[];used=set()
        for g in gaps:
            matched=[(j,x) for j,x in enumerate(peers) if min(g['b'],x['b'])-max(g['a'],x['a'])>=.75*min(g['b']-g['a'],x['b']-x['a'])]
            if len(matched)!=1:unmatched+=1;continue
            j,x=matched[0];assert j not in used;used.add(j)
            l=max(g['a'],x['a']);r=min(g['b'],x['b'])
            combined.append(dict(a=l,b=r,late_ms=(r-l)/1e6,thread_ms=g['thread_ms']+x['thread_ms']))
        unmatched+=len(peers)-len(used);gaps=combined
    irq=np.array(jrows(p/'irq.jsonl.gz'),dtype=np.int64);sr=jrows(p/'system.jsonl.gz')
    s0=np.array([v[0] for v in sr]);s1=np.array([v[1] for v in sr]);s2=np.array([v[2] for v in sr]);cpus=[hot,ctrl]
    cpst=np.array([[v[3][str(c)] for c in cpus] for v in sr])
    sch=np.array([[v[4][str(c)] for c in cpus] for v in sr]);assert sch.shape[2]==3
    ing=irq[:,0],irq[:,1],irq[:,2:4],s0,s1,s2,cpst,sch
    iq=load(p/'irq-quality.json');sq=load(p/'system-quality.json');assert iq['complete'] and sq['complete']
    total=[];cal=[];excluded=Counter();opens=max(v['opened'] for v in tasks.values())
    for gap in gaps:
        a,b=gap['a'],gap['b'];i=np.searchsorted(change,(a+b)//2,'right')-1
        if not 0<=i<len(change)-1:excluded['no-both-boundaries']+=1;continue
        u,v=int(change[i]),int(change[i+1]);da=(u-a)/1e6;db=(v-b)/1e6
        entry=kinds[i]
        cal.append(dict(a=a,b=b,entry=entry,entry_skew_ms=da,exit_skew_ms=db))
        if abs(da)>10 or abs(db)>10:excluded['boundary-outside-10ms']+=1;continue
        if 'TIMER' not in entry:excluded['different-vector']+=1;continue
        lo=u+15_000_000;hi=v-15_000_000
        if lo<opens or hi<=lo:excluded['outside-switch-coverage']+=1;continue
        inside=interval_monitors(ing,lo,hi)
        # Same duration 1 s earlier, leaving a gap of ~half a second before the TIMER event.
        lo0,hi0=lo-1_000_000_000,hi-1_000_000_000
        pre=interval_monitors(ing,lo0,hi0) if lo0>opens else None
        if not inside:excluded['outside-counter-coverage']+=1;continue
        ol=max(0,np.searchsorted(s1,u,'right')-1);orr=min(len(s0)-1,np.searchsorted(s0,v,'left'))
        ds=cpst[orr,0]-cpst[ol,0];elapsed=(hi-lo)/1e6
        rr=dict(a=a,b=b,vector_begin=u,vector_end=v,entry=entry,entry_skew_ms=da,exit_skew_ms=db,interior_ms=elapsed,
                witness_cpu_ms=gap['thread_ms'],witness_gap_ms=(b-a)/1e6,hot=inside[0],ctrl=inside[1],
                longest_sampler_gap_ms=inside['largest_irq_sample_gap_ms'],
                outer_window_ms=(int(s1[orr])-int(s0[ol]))/1e6,outer_irq_ms=int(ds[5])*1000/meta.get("accounting_hz",100),outer_softirq_ms=int(ds[6])*1000/meta.get("accounting_hz",100),
                own_current_hot_ms=residency(tasks,hot,lo,hi),own_current_ctrl_ms=residency(tasks,ctrl,lo,hi),
                same_core_peer_has_gap=any(max(a,x['a'])<min(b,x['b']) and min(b,x['b'])-max(a,x['a'])>=.75*(b-a) for x in peers) if meta['dual'] else None,
                hot_switch_ins=sum(np.searchsorted(w['ins'],hi)-np.searchsorted(w['ins'],lo) for (_,cp),w in tasks.items() if cp==hot).item(),
                hot_switch_outs=sum(np.searchsorted(w['outs'],hi)-np.searchsorted(w['outs'],lo) for (_,cp),w in tasks.items() if cp==hot).item())
        if pre:
            rr['pre']=pre[0];rr['pre_ctrl']=pre[1]
            rr['pre_hot_current_ms']=residency(tasks,hot,lo0,hi0);rr['pre_ctrl_current_ms']=residency(tasks,ctrl,lo0,hi0)
        total.append(rr)
    baseline=[r for r in total if 'pre' in r]
    if not total:return dict(count=0,excluded=dict(excluded),all_gaps=len(gaps),ctrl_gaps=len(zeros),raw_boundaries=cal,finestats=q,quality=quality,events=[])
    med=lambda k:float(median(r[k] for r in total))
    sums=dict(qualified=len(total),normal_available=len(baseline),timer_only=sum(r['entry']==['TIMER'] for r in total),
              timer_plus_other=sum(r['entry']!=['TIMER'] for r in total),gap_ms=qt([r['witness_gap_ms'] for r in total]),
              own_hot_ms=qt([r['own_current_hot_ms'] for r in total]),own_ctrl_ms=qt([r['own_current_ctrl_ms'] for r in total]),
              own_runtime_ms=qt([r['witness_cpu_ms'] for r in total]),
              own_hot_under_1ms=sum(r['own_current_hot_ms']<=1 for r in total),
              own_hot_over_90pct=sum(r['own_current_hot_ms']>=.9*r['interior_ms'] for r in total),
              hot_current_pct=qt([100*r['own_current_hot_ms']/r['interior_ms'] for r in total]),
              ctrl_current_pct=qt([100*r['own_current_ctrl_ms']/r['interior_ms'] for r in total]),
              pre_hot_pct=qt([100*r['pre_hot_current_ms']/r['interior_ms'] for r in baseline]),
              inner_irq=qt([r['hot']['irq_count'] for r in total]),pre_irq=qt([r['pre']['irq_count'] for r in baseline]),
              most_irq_silence_ms=qt([r['hot']['longest_no_observed_irq_ms'] for r in total]),
              pre_irq_silence_ms=qt([r['pre']['longest_no_observed_irq_ms'] for r in baseline]),
              normal_irq_control=qt([r['ctrl']['irq_count'] for r in total]),
              scheduler_slices=qt([r['hot']['sched_slices'] for r in total]),pre_scheduler_slices=qt([r['pre']['sched_slices'] for r in baseline]),
              own_ins=qt([r['hot_switch_ins'] for r in total]),own_outs=qt([r['hot_switch_outs'] for r in total]),
              inner_with_arch_irq=sum(r['hot']['irq_count']>0 for r in total),
              inner_zero_sched_slices=sum(r['hot']['sched_slices']==0 for r in total),
              softirq_outer_ms=qt([r['outer_softirq_ms'] for r in total]),hardirq_outer_ms=qt([r['outer_irq_ms'] for r in total]),
              irq_sample_gap_p99_ms=float(np.quantile(np.diff(irq[:,1])/1e6,.99)),longest_sample_gap_ms=max(r['longest_sampler_gap_ms'] for r in total),
              peer_stalls=sum(bool(r['same_core_peer_has_gap']) for r in total) if meta['dual'] else None)
    return dict(all_gaps=len(gaps),individual_primary_gaps=original_n,group_join=combine_peers,overlap_unmatched=unmatched,ctrl_gaps=len(zeros),peer_ctrl_gaps=len(read_gaps(p,'peer',ctrl)) if meta['dual'] else None,
                excluded=dict(excluded),events=total,raw_boundaries=cal,quality=quality,finestats=q,
                irq_meta=iq,system_meta=sq,summary=sums)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory',type=Path,help='Directory produced by run_context.py')
    parser.add_argument('--out',type=Path,required=True,help='New JSON output file')
    args=parser.parse_args()
    if args.out.exists():parser.error('Select a new JSON output file')
    results={name:inspect(args.directory/name) for name in ('single','dual')}
    results['dual_intersection']=inspect(args.directory/'dual',combine_peers=True)
    save(args.out,results)
    for name,r in results.items():
        print(name,'over 100 ms:',r['all_gaps'],'aligned:',r.get('summary',{}).get('qualified',0),
              'exclusions:',r['excluded'])
if __name__=='__main__':main()
