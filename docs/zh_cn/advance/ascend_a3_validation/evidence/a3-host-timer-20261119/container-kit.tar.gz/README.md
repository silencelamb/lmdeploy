# A3 主机长停顿的容器探针

基础探针使用 Linux、Python 3 标准库、C++17 和 zlib 开发头文件。所有 CPU 号均为宿主 Linux 逻辑核。先以当前作业的允许集合选核。以下命令从解包目录执行，输出放在新的目录。

```bash
make
python3 -c 'import os; print(sorted(os.sched_getaffinity(0)))'
python3 probe.py scan --cpus allowed --groups 4 --seconds 40 --out scan-run
```

`scan-run/scan.csv` 每行给出一个核在一个窗口内的样本数、超过唤醒期限 100/300 ms 的次数、最大额外等待和软/硬中断累计时间。每个线程请求 12 ms 后唤醒。按 `over100`、`over300`、`max_late_ms` 找热点，再在独立窗口复核。要复用报告的重复对照，且 CPU18、19 均允许，可加 `--sentinels 18,19`。只测部分核可传 `--cpus 40-47`。同一核在多波次被重复测试时，比较发生率须用其实际测量秒数。

如需同时观察全部在线核的软中断用时，用 `screen`。示例为原实验的 10 个主动探针，CPU84 作独立读取器，和原先用 CPU44 的首轮相比，这样也能观察 CPU44 自身。按当前可用核调整。

```bash
python3 probe.py screen --cpus 18,19,42,58,98,138,178,218,258,298 --vector-cpu 18 --observer 84 --seconds 150 --out screen-run
```

下例假设已发现 CPU44 为热点，CPU45 是同 NUMA 节点对照、CPU84 可独立采样。CPU 热点随节点变化。每个原生程序的输出前缀使用不同名称。

```bash
mkdir run44
./fine_irq run44/sleep 100 sleep 44 45 84
python3 probe.py fine-summary --prefix run44/sleep --cpu 44 --control 45
./fine_irq run44/spin 100 spin 44 45 84
python3 probe.py fine-summary --prefix run44/spin --cpu 44 --control 45
./wakeup run44/quiet 75 18 19 44 45
python3 probe.py wake-summary --prefix run44/quiet --cpus 18,19,44,45
```

`fine_irq` 每约 1 ms 记录两个核的软中断向量累计次数，另存超出阈值 2 ms 的应用时间戳、线程 CPU 时间差以及总迭代数。`fine-summary` 针对 >100 ms 长窗，在停顿前后各 10 ms 范围核对最后进入及后续向量变化。`tight` 是能判读边界的分母，`last_vectors_in_tight_cases` 是进入长窗前最后变化的向量（一个采样格可能有多个）。没有长窗时，分母为零。无持续轮询的 `wakeup` 保存所有应醒和实醒时刻。`quiet` 仍应与细粒度采集顺序运行。

## 观察停顿期间是否真正切出了实验线程

高级采集需要 Linux 的自有任务 perf_event_open（PERF_RECORD_SWITCH）、taskset 和可读的 arch_timer 逐 CPU 中断计数。编译用 make，离线分析用 NumPy。观察核依次采软中断向量、本地硬时钟中断、自有任务调度切换及系统计数。运行程序前选择可用的独立核心，四个观察器与两个对照核互不重叠。

```bash
make context
python3 run_context.py --hot 44 --control 45 --observers 84 85 86 87 --seconds 100 --out ctx44
python3 analyze_context.py ctx44 --out ctx44-analysis.json
```

`single` 每核一条持续可运行的线程，`dual` 每核两条同等优先级的线程。`dual_intersection` 在离线分析里对齐同核两条线程共同停止进展的区间，和 `dual` 是同一次采集。检查 `quality`、`excluded` 和有效的 `events`。事件丢失、错误 TID、异常方向顺序或监测启动前的窗口均会影响判读。长窗内部首尾各剔除 15 ms，正常参考取提前一秒的等长区间。`summary` 中四个分位数依次为最小值、中位数、p90、最大值。调度上的 current 表示调度器选中了该任务，软中断可以在此期间占用该核。

包中的 C++ 源码沿用实测版本。Python 的 scan、结果摘要和可选择观察核的启动入口用于在其他节点复现同样的计时。函数级采集使用报告另附的宿主采集包。
