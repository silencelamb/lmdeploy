// Same spin witness as the earlier test, without creating a second softirq sampler.
#define main previous_fine_irq_entry
#include "fine_irq.cc"
#undef main
int main(int argc, char** argv) {
    if (argc != 5) return 2;
    std::string prefix = argv[1];
    int seconds = std::stoi(argv[2]);
    int hot = std::stoi(argv[3]);
    int control = std::stoi(argv[4]);
    I stop = clockns() + 1000000000LL * seconds;
    std::thread a(witness, hot, true, stop, std::cref(prefix));
    std::thread b(witness, control, true, stop, std::cref(prefix));
    a.join();
    b.join();
}
