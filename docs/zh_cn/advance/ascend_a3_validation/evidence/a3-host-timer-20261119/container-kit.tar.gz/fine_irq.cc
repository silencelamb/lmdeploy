// Unprivileged single-node comparison: concurrently timestamp per-CPU softirq dispatch counts and wakeup gaps.
#include <algorithm>
#include <atomic>
#include <charconv>
#include <cstdio>
#include <cstring>
#include <fcntl.h>
#include <fstream>
#include <sched.h>
#include <stdexcept>
#include <string>
#include <time.h>
#include <thread>
#include <unistd.h>
#include <vector>
#include <zlib.h>

using I=long long;
I clockns(clockid_t c=CLOCK_MONOTONIC){timespec ts{};clock_gettime(c,&ts);return 1000000000LL*ts.tv_sec+ts.tv_nsec;}
void pin(int c){cpu_set_t mask;CPU_ZERO(&mask);CPU_SET(c,&mask);if(sched_setaffinity(0,sizeof(mask),&mask))std::abort();}
void until(I t){timespec ts{t/1000000000LL,t%1000000000LL};while(clock_nanosleep(CLOCK_MONOTONIC,TIMER_ABSTIME,&ts,nullptr)==EINTR){}}
struct Gap{I before,deadline,after,thread_delta;};
void witness(int cpu,bool spin,I stop,const std::string& prefix){
    pin(cpu);std::vector<Gap> large;unsigned long long iterations=0;
    I last=clockns(),oldcpu=clockns(CLOCK_THREAD_CPUTIME_ID),nominal=spin?0:1000000LL;
    while(last<stop){
        I due=last+nominal;if(!spin)until(due);I now=clockns(),ct=clockns(CLOCK_THREAD_CPUTIME_ID);
        if(now-due>2000000)large.push_back({last,due,now,ct-oldcpu});
        oldcpu=ct;last=now;++iterations;
    }
    std::ofstream f(prefix+"-cpu"+std::to_string(cpu)+".csv");
    f<<"before_ns,deadline_ns,after_ns,thread_delta_ns\n";for(auto& g:large)f<<g.before<<","<<g.deadline<<","<<g.after<<","<<g.thread_delta<<"\n";
    std::ofstream meta(prefix+"-cpu"+std::to_string(cpu)+"-iterations.txt");meta<<iterations<<"\n";
}
int main(int argc,char**argv){
    if(argc<6||argc>7){fprintf(stderr,"usage: fine_irq prefix seconds sleep|spin cpu sibling [observerCPU]\n");return 2;}
    std::string prefix=argv[1],mode=argv[3];int seconds=atoi(argv[2]),cpu=atoi(argv[4]),control=atoi(argv[5]);
    if(mode!="sleep"&&mode!="spin")return 2;
    int limit=std::max(cpu,control);I stop=clockns()+seconds*1000000000LL;
    cpu_set_t permission;CPU_ZERO(&permission);sched_getaffinity(0,sizeof(permission),&permission);
    int observer=argc==7?atoi(argv[6]):-1;
    if(observer<0)for(int c=0;c<CPU_SETSIZE;c++)if(c!=cpu&&c!=control&&CPU_ISSET(c,&permission)){observer=c;break;}
    if(observer<0||observer==cpu||observer==control||!CPU_ISSET(cpu,&permission)||!CPU_ISSET(control,&permission)||!CPU_ISSET(observer,&permission))return 3;
    std::thread x(witness,cpu,mode=="spin",stop,std::ref(prefix)),y(witness,control,mode=="spin",stop,std::ref(prefix));
    pin(observer);int fd=open("/proc/softirqs",O_RDONLY);if(fd<0)std::abort();char data[300000],*endp;std::vector<std::string> names;
    gzFile out=gzopen((prefix+"-softirqs.csv.gz").c_str(),"wb1");if(!out)std::abort();gzbuffer(out,262144);
    std::vector<I> stamps;I due=clockns();long long frames=0,missed=0;I maxread=0;
    while(clockns()<stop){
        I start=clockns();int n=pread(fd,data,sizeof(data)-1,0);I end=clockns();
        if(n<=0||n>=(int)sizeof(data)-1)std::abort();
        data[n]=0;char* line=strchr(data,'\n')+1;stamps.clear();
        while(*line){
            char* e=strchr(line,'\n');if(!e)break;*e=0;
            char* colon=strchr(line,':');if(!colon)std::abort();*colon=0;
            char* s=colon+1;while(*line==' ')line++;
            if(frames==0)names.emplace_back(line);
            I primary=-1,comparison=-1;
            for(int i=0;i<=limit;i++){
                I val=strtoll(s,&endp,10);if(endp==s)std::abort();s=endp;
                if(i==cpu)primary=val;if(i==control)comparison=val;
            }
            stamps.push_back(primary);stamps.push_back(comparison);line=e+1;
        }
        if(frames==0){gzprintf(out,"begin_ns,end_ns");for(auto& s:names)gzprintf(out,",%s_%d,%s_%d",s.c_str(),cpu,s.c_str(),control);gzprintf(out,"\n");}
        gzprintf(out,"%lld,%lld",start,end);for(I v:stamps)gzprintf(out,",%lld",v);gzprintf(out,"\n");++frames;
        maxread=std::max(end-start,maxread);
        I now=clockns();due+=1000000;while(due<=now){++missed;due+=1000000;}until(due);
    }
    gzclose(out);close(fd);x.join();y.join();
    std::ofstream f(prefix+"-meta.txt");f<<"frames "<<frames<<" missed_target_frames "<<missed<<" max_read_ns "<<maxread<<" observer "<<observer<<" seconds "<<seconds<<" mode "<<mode<<"\n";
}
