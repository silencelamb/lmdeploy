// PERF_RECORD_SWITCH for owned, named application tasks. Only user-permitted per-task events are opened.
#include <linux/perf_event.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <unistd.h>
#include <dirent.h>
#include <fcntl.h>
#include <time.h>
#include <cerrno>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <map>
#include <set>
#include <string>
#include <vector>
#include <zlib.h>

#ifndef WATCH_CPU
#define WATCH_CPU -1
#endif
uint64_t now_ns(){timespec t{};clock_gettime(CLOCK_MONOTONIC,&t);return 1000000000ULL*t.tv_sec+t.tv_nsec;}
struct Row{uint64_t ns;uint32_t tid;uint16_t cpu;uint8_t away,preempt;};
static_assert(sizeof(Row)==16);
struct Ring{
    int fd,tid,pid;std::string name,group;perf_event_mmap_page* mem;size_t mapsize;
    unsigned long long records=0,lost=0,invalid=0;uint64_t opened=0;
};
bool helper(const std::string& n){
    const std::vector<std::string> terms={"worker.io","server.poll","client.poll","nexting_thread","grpcpp_sync","event_engine","grpc_global","default-executo"};
    for(const auto& t:terms)if(n.find(t)!=std::string::npos)return true;
    return false;
}
void copy(const char* data,size_t size,uint64_t offset,void* dest,size_t n){
    size_t start=offset%size,k=std::min(n,size-start);memcpy(dest,data+start,k);if(k<n)memcpy((char*)dest+k,data,n-k);
}
void drain(Ring& r,gzFile output){
    static std::vector<Row> batch;batch.clear();
    auto* m=r.mem;const char* data=(char*)m+m->data_offset;
    uint64_t head=__atomic_load_n(&m->data_head,__ATOMIC_ACQUIRE),tail=m->data_tail;
    while(tail<head){
        perf_event_header h;copy(data,m->data_size,tail,&h,sizeof(h));if(h.size<8||tail+h.size>head){++r.invalid;break;}
        if(h.type==PERF_RECORD_SWITCH){
            struct I{uint32_t pid,tid;uint64_t time;uint32_t cpu,reserved;};static_assert(sizeof(I)==24);
            I i{};copy(data,m->data_size,tail+h.size-sizeof(I),&i,sizeof(i));
            if((int)i.tid!=r.tid||(int)i.pid!=r.pid||i.cpu>32766)++r.invalid;
            else{Row row{i.time,i.tid,(uint16_t)i.cpu,(uint8_t)!!(h.misc&PERF_RECORD_MISC_SWITCH_OUT),(uint8_t)!!(h.misc&PERF_RECORD_MISC_SWITCH_OUT_PREEMPT)};
                 batch.push_back(row);++r.records;}
        }else if(h.type==PERF_RECORD_LOST){
            uint64_t n=0,when=0;copy(data,m->data_size,tail+16,&n,8);
            if(h.size>=48)copy(data,m->data_size,tail+h.size-16,&when,8);
            batch.push_back(Row{when,(uint32_t)r.tid,0xffff,2,0});r.lost+=n;
        }
        tail+=h.size;
    }
    __atomic_store_n(&m->data_tail,tail,__ATOMIC_RELEASE);
    if(!batch.empty())gzwrite(output,batch.data(),batch.size()*sizeof(Row));
}
int main(int argc,char** argv){
    if(argc!=4)return 2;std::string obs=argv[1],pre=argv[2],stop=argv[3];
    size_t pg=sysconf(_SC_PAGESIZE);std::map<int,Ring> rings;std::set<int> rejected;
    std::ofstream types(pre+"-tids.tsv");types<<"opened_ns\tpid\ttid\tgroup\tname\tfd_success\terrno\n";
    gzFile out=gzopen((pre+"-events.bin.gz").c_str(),"wb1");if(!out)return 3;gzbuffer(out,1048576);
    uint64_t next=0,last=now_ns(),deadline=last+1550000000000ULL;int nloops=0;
    while(access(stop.c_str(),F_OK)!=0&&now_ns()<deadline){
        uint64_t tick=now_ns();
        if(tick>=next){
            std::map<int,std::string> groups;std::set<int> primary;std::ifstream tags(obs+"/thread-roles.txt");int pid,tid;std::string role;uint64_t when;
            while(tags>>pid>>tid>>role>>when){groups[pid]=role.substr(0,role.find('_'));primary.insert(tid);}
            for(auto const& [pid,group]:groups){
                std::string root="/proc/"+std::to_string(pid)+"/task/";DIR* ds=opendir(root.c_str());if(!ds)continue;
                while(auto* en=readdir(ds)){
                    int tid=atoi(en->d_name);if(!tid||rings.count(tid)||rejected.count(tid))continue;
                    std::ifstream f(root+en->d_name+"/comm");std::string name;std::getline(f,name);
                    #ifdef BACKGROUND_ONLY
                    if(primary.count(tid)||helper(name))continue;
#else
                    if(!primary.count(tid)&&!helper(name))continue;
#endif
                    perf_event_attr a{};a.type=PERF_TYPE_SOFTWARE;a.size=sizeof(a);a.config=PERF_COUNT_SW_DUMMY;
                    a.sample_type=PERF_SAMPLE_TID|PERF_SAMPLE_TIME|PERF_SAMPLE_CPU;a.sample_id_all=1;a.exclude_kernel=1;a.exclude_hv=1;
                    a.context_switch=1;a.use_clockid=1;a.clockid=CLOCK_MONOTONIC;a.wakeup_events=1;
                    int fd=syscall(SYS_perf_event_open,&a,tid,WATCH_CPU,-1,PERF_FLAG_FD_CLOEXEC);int err=fd<0?errno:0;
                    size_t bytes=pg*(1+(primary.count(tid)?(WATCH_CPU<0?1024:256):16));
                    auto* m=fd>=0?(perf_event_mmap_page*)mmap(nullptr,bytes,PROT_READ|PROT_WRITE,MAP_SHARED,fd,0):(perf_event_mmap_page*)MAP_FAILED;
                    if(m==MAP_FAILED&&!err)err=errno;
                    types<<now_ns()<<"\t"<<pid<<"\t"<<tid<<"\t"<<group<<"\t"<<name<<"\t"<<(err==0)<<"\t"<<err<<"\n";
                    if(err){if(fd>=0)close(fd);rejected.insert(tid);continue;}
                    rings.emplace(tid,Ring{fd,tid,pid,name,group,m,bytes,0,0,0,now_ns()});
                }
                closedir(ds);
            }
            types.flush();next=tick+250000000ULL;
        }
        for(auto& [tid,ring]:rings)drain(ring,out);
        ++nloops;
        timespec delay{0,2000000};nanosleep(&delay,nullptr);last=now_ns();
    }
    std::ofstream counts(pre+"-counts.tsv");counts<<"tid\tpid\tgroup\tname\topened_ns\trecords\tlost\tinvalid\n";
    for(auto& [tid,r]:rings){
        drain(r,out);counts<<r.tid<<"\t"<<r.pid<<"\t"<<r.group<<"\t"<<r.name<<"\t"<<r.opened<<"\t"<<r.records<<"\t"<<r.lost<<"\t"<<r.invalid<<"\n";
        munmap(r.mem,r.mapsize);close(r.fd);
    }
    gzclose(out);return 0;
}
