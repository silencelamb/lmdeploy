"""Record one- and two-runnable-thread experiments on a hot Linux CPU and a control CPU."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time

BIN=Path(__file__).resolve().parent

def write(path,value):
    temp=path.with_suffix('.tmp');temp.write_text(json.dumps(value,indent=2)+'\n');temp.replace(path)

def discover(child,cores):
    found={};deadline=time.monotonic()+6
    while child.poll() is None and time.monotonic()<deadline:
        for path in Path('/proc',str(child.pid),'task').glob('[0-9]*'):
            tid=int(path.name)
            if tid==child.pid:continue
            try:cpus=os.sched_getaffinity(tid)
            except ProcessLookupError:continue
            if len(cpus)==1 and min(cpus) in cores:found[min(cpus)]=tid
        if len(found)==len(cores):return found
        time.sleep(.003)
    raise RuntimeError(f'Could not identify both pinned threads of child {child.pid}: {found}')

def stop_child(child):
    if child.poll() is None:child.terminate()
    try:child.wait(timeout=8)
    except subprocess.TimeoutExpired:child.kill();child.wait()

def phase(directory,hot,control,observers,seconds,dual):
    directory.mkdir()
    fine_cpu,irq_cpu,switch_cpu,system_cpu=observers
    log_env=dict(os.environ);log_env.pop('LD_PRELOAD',None);log_env.pop('LD_LIBRARY_PATH',None)
    monitors=[];workers=[];roles={};rc={}
    start=time.monotonic_ns()
    try:
        for mode,observer in [('irq',irq_cpu),('system',system_cpu)]:
            command=[sys.executable,str(BIN/'counters.py'),str(directory),mode,str(hot),str(control),
                     '--observer',str(observer),'--max-seconds',str(seconds+60)]
            monitors.append((mode,subprocess.Popen(command)))
        stop=directory/'sampling.stop'
        monitors.append(('switch',subprocess.Popen(['taskset','-c',str(switch_cpu),str(BIN/'switch_watch'),str(directory),
                                                   str(directory/'switch'),str(stop)],env=log_env)))
        if dual:
            workers.append(('peer',subprocess.Popen([str(BIN/'peer'),str(directory/'peer-out'),str(seconds+1),str(hot),str(control)],env=log_env)))
        workers.append(('probe',subprocess.Popen([str(BIN/'fine_irq'),str(directory/'probe-out'),str(seconds),'spin',
                                                 str(hot),str(control),str(fine_cpu)],env=log_env)))
        lines=[]
        for name,child in workers:
            registered=discover(child,{hot,control})
            roles[name]={str(c):tid for c,tid in registered.items()}
            lines.extend(f'{child.pid} {tid} {name}{c} {time.monotonic_ns()}\n' for c,tid in registered.items())
        tmp=directory/'thread-roles.tmp';tmp.write_text(''.join(lines));tmp.replace(directory/'thread-roles.txt')
        for name,child in workers:
            rc[name]=child.wait(timeout=seconds+25)
            if rc[name]:raise RuntimeError(f'{name} exited with {rc[name]}')
    finally:
        for _,child in workers:stop_child(child)
        (directory/'sampling.stop').touch()
        for name,child in monitors:
            try:rc[name]=child.wait(timeout=15)
            except subprocess.TimeoutExpired:stop_child(child);rc[name]=child.returncode
    if any(rc.values()):raise RuntimeError(f'Incomplete recorders: {rc}')
    write(directory/'meta.json',dict(accounting_hz=os.sysconf("SC_CLK_TCK"),hot=hot,control=control,dual=dual,roles=roles,a=start,b=time.monotonic_ns(),rc=rc))

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out',type=Path,required=True);p.add_argument('--hot',type=int,required=True);p.add_argument('--control',type=int,required=True)
    p.add_argument('--observers',nargs=4,type=int,required=True,metavar=('SOFTIRQ_CPU','HARDIRQ_CPU','SWITCH_CPU','SYSTEM_CPU'))
    p.add_argument('--seconds',type=int,default=100)
    args=p.parse_args();cpus=[args.hot,args.control,*args.observers]
    if len(set(cpus))!=len(cpus) or not set(cpus)<=os.sched_getaffinity(0):
        p.error('Specify six distinct CPUs in the current allowed set')
    if not 1<=args.seconds<=1500:p.error('Use 1–1500 seconds per phase (the switch trace watchdog is 1550 s)')
    out=args.out.resolve();out.mkdir(parents=True,exist_ok=False)
    state=dict(complete=False,hot=args.hot,control=args.control,observers=args.observers,seconds=args.seconds,phases=[])
    write(out/'run.json',state)
    for name in ('single','dual'):
        phase(out/name,args.hot,args.control,args.observers,args.seconds,name=='dual')
        state['phases'].append(name);write(out/'run.json',state)
        if name=='single':time.sleep(2)
    state['complete']=True;write(out/'run.json',state)
if __name__=='__main__':main()
