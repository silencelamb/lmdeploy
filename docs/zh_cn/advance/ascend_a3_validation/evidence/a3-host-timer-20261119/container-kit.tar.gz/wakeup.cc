// One unprivileged, phase-independent wakeup witness per specified CPU. Record every wake.
#include <chrono>
#include <cstdlib>
#include <fstream>
#include <sched.h>
#include <thread>
#include <time.h>
#include <unistd.h>
#include <vector>
#include <string>

long long now() { timespec t{}; clock_gettime(CLOCK_MONOTONIC,&t); return 1000000000LL*t.tv_sec+t.tv_nsec; }
int main(int argc,char** argv) {
    if(argc<4) return 1;
    std::string prefix=argv[1];int seconds=std::stoi(argv[2]);std::vector<std::thread> threads;
    for(int pos=3;pos<argc;pos++) {
        int core=std::stoi(argv[pos]);
        threads.emplace_back([=] {
            cpu_set_t cpus;CPU_ZERO(&cpus);CPU_SET(core,&cpus);
            if(sched_setaffinity(0,sizeof(cpus),&cpus)!=0) std::abort();
            std::vector<std::pair<long long,long long>> samples;
            long long stop=now()+seconds*1000000000LL; const long long gap=12000000LL;
            for(long long target=now()+gap;target<stop;) {
                timespec ts{target/1000000000LL,target%1000000000LL};
                if(clock_nanosleep(CLOCK_MONOTONIC,TIMER_ABSTIME,&ts,nullptr)!=0) continue;
                long long got=now();samples.emplace_back(target,got);target=got+gap;
            }
            std::ofstream f(prefix+"-cpu"+std::to_string(core)+".csv");
            f<<"deadline_ns,woke_ns\n";for(auto const& r:samples)f<<r.first<<","<<r.second<<"\n";
        });
    }
    for(auto& t:threads)t.join();
}
