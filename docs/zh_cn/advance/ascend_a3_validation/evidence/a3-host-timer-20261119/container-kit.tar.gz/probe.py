"""Find long CPU wakeups and align them with per-CPU softirq counters. Linux, Python standard library."""
import argparse
from bisect import bisect_right
from collections import Counter
import csv
import gzip
import json
import os
from pathlib import Path
from statistics import median
import subprocess
import time

BIN = Path(__file__).resolve().parent

def cpulist(spec):
    cpus = set()
    for word in spec.split(','):
        if word:
            bounds = [int(n) for n in word.split('-')]
            if len(bounds) > 2 or min(bounds) < 0 or bounds[-1] < bounds[0]:
                raise ValueError('Invalid CPU range: '+word)
            cpus.update(range(bounds[0],bounds[-1]+1))
    return sorted(cpus)

def select(spec):
    allowed = os.sched_getaffinity(0)
    cpus = sorted(allowed) if spec == 'allowed' else cpulist(spec)
    if not cpus or not set(cpus) <= allowed:
        raise ValueError('Select online CPUs from this process affinity: '+str(sorted(allowed)))
    return cpus

def write_csv(path, rows):
    if not rows:
        raise ValueError('No samples to write')
    with path.open('x',newline='') as f:
        writer = csv.DictWriter(f,fieldnames=rows[0]);writer.writeheader();writer.writerows(rows)

def cpu_times():
    counters = {}
    for line in Path('/proc/stat').read_text().splitlines():
        fields = line.split()
        if fields[0] == 'intr':break
        if fields[0].startswith('cpu') and fields[0][3:].isdigit():
            counters[int(fields[0][3:])] = tuple(map(int,fields[1:9]))
    return counters

def vector_counts(cpu):
    counters = {}
    for row in Path('/proc/softirqs').read_text().splitlines()[1:]:
        name,values = row.split(':',1)
        counters[name.strip()] = int(values.split()[cpu])
    return counters

def wake_data(prefix,cpu):
    late = []; starts = []
    with Path(f'{prefix}-cpu{cpu}.csv').open() as f:
        for row in csv.DictReader(f):
            due,got = int(row['deadline_ns']),int(row['woke_ns'])
            ms = (got-due)/1e6
            late.append(ms)
            if ms>100:starts.append(due)
    if not late:raise ValueError(f'No wakeups on CPU {cpu}')
    return dict(cpu=cpu,samples=len(late),over100=len(starts),over300=sum(ms>300 for ms in late),
                median_late_ms=median(late),max_late_ms=max(late),
                period_s=median((b-a)/1e9 for a,b in zip(starts,starts[1:])) if len(starts)>1 else None)

def start_wake(prefix,seconds,cores):
    env=dict(os.environ);env.pop('LD_PRELOAD',None);env.pop('LD_LIBRARY_PATH',None)
    return subprocess.Popen([str(BIN/'wakeup'),str(prefix),str(seconds),*map(str,cores)],env=env)

def pretty(x): print(json.dumps(x,indent=2))

def scan(args):
    cores=select(args.cpus);sentinels=cpulist(args.sentinels)
    if not set(sentinels)<=set(cores):raise ValueError('Sentinels must be among selected CPUs')
    if min(args.groups,args.seconds)<1:raise ValueError('Positive groups and duration required')
    args.out.mkdir(parents=True,exist_ok=False)
    hz=os.sysconf('SC_CLK_TCK');rows=[]
    for i in range(args.groups):
        members=sorted({c for c in cores if c%args.groups==i})
        if not members:continue
        members=sorted(set(members)|set(sentinels));prefix=args.out/f'wave{i}'
        before=cpu_times();p=start_wake(prefix,args.seconds,members)
        try:
            if p.wait(timeout=args.seconds+30):raise RuntimeError(f'CPU probe failed in wave {i}')
        finally:
            if p.poll() is None:p.terminate();p.wait()
        after=cpu_times()
        for c in members:
            rows.append(dict(wave=i,seconds=args.seconds,**wake_data(prefix,c),
                             softirq_s=(after[c][6]-before[c][6])/hz,hardirq_s=(after[c][5]-before[c][5])/hz))
    write_csv(args.out/'scan.csv',rows)
    pretty({'unique_cpus':len(cores),'windows':len(rows),'windows_over_100ms':[r for r in rows if r['over100']]})

def screen(args):
    cores=select(args.cpus);allowed=os.sched_getaffinity(0)
    if args.seconds<1 or args.vector_cpu not in cores or args.observer not in allowed or args.observer in cores:
        raise ValueError('Use one selected vector CPU and a separate available observer CPU')
    args.out.mkdir(parents=True,exist_ok=False);prefix=args.out/'paired';hz=os.sysconf('SC_CLK_TCK')
    p=start_wake(prefix,args.seconds,cores)
    first=last=None
    try:
        os.sched_setaffinity(0,{args.observer})
        with gzip.open(args.out/'counters.jsonl.gz','xt',compresslevel=1) as f:
            start=time.monotonic_ns()
            for frame in range(args.seconds*10+1):
                time.sleep(max(0,(start+frame*100_000_000-time.monotonic_ns())/1e9))
                begin=time.monotonic_ns();counts=cpu_times();vectors=vector_counts(args.vector_cpu);end=time.monotonic_ns()
                if first is None:first=counts
                last=counts
                f.write(json.dumps([frame,begin,end,{c:x[6] for c,x in counts.items()},vectors],separators=(',',':'))+'\n')
        if p.wait(timeout=15):raise RuntimeError('CPU probe failed')
    finally:
        os.sched_setaffinity(0,allowed)
        if p.poll() is None:p.terminate();p.wait()
    write_csv(args.out/'all-cpu-time.csv',[dict(cpu=c,softirq_s=(last[c][6]-first[c][6])/hz,
              hardirq_s=(last[c][5]-first[c][5])/hz) for c in sorted(first)])
    w=[wake_data(prefix,c) for c in cores];write_csv(args.out/'wakeup.csv',w);pretty(w)

def summarize_fine(prefix,cpu,control):
    changes=[];vectors=[];previous=None;suffix=f'_{cpu}'
    with gzip.open(str(prefix)+'-softirqs.csv.gz','rt') as f:
        for row in csv.DictReader(f):
            current={k[:-len(suffix)]:int(v) for k,v in row.items() if k.endswith(suffix)}
            if not current:raise ValueError(f'No counters for CPU {cpu}')
            if previous is not None:
                names=[k for k in current if current[k]>previous[k]]
                if names:
                    changes.append(int(row['end_ns']));vectors.append(names)
            previous=current
    types=Counter();stats={};bracketed=0
    for c in (cpu,control):
        large=[]; all_logged=[]
        with Path(f'{prefix}-cpu{c}.csv').open() as f:
            for row in csv.DictReader(f):
                start,end=int(row['before_ns']),int(row['after_ns'])
                delay=(end-int(row['deadline_ns']))/1e6;all_logged.append(delay)
                if delay<=100:continue
                large.append(delay)
                if c!=cpu:continue
                i=bisect_right(changes,(start+end)//2)-1
                if not 0<=i<len(changes)-1:continue
                bracketed+=1
                if abs(changes[i]-start)<=10_000_000 and abs(changes[i+1]-end)<=10_000_000:
                    types[','.join(vectors[i])]+=1
        stats[str(c)]=dict(over100=len(large),max_logged_ms=max(all_logged,default=None))
    return dict(by_cpu=stats,bracketed=bracketed,tight=sum(types.values()),last_vectors_in_tight_cases=dict(types))

def main():
    parser=argparse.ArgumentParser(description=__doc__);sub=parser.add_subparsers(dest='command',required=True)
    s=sub.add_parser('scan');s.add_argument('--cpus',default='allowed');s.add_argument('--sentinels',default='')
    s.add_argument('--seconds',type=int,default=40);s.add_argument('--groups',type=int,default=4);s.add_argument('--out',type=Path,required=True)
    s=sub.add_parser('screen');s.add_argument('--cpus',required=True);s.add_argument('--vector-cpu',type=int,required=True)
    s.add_argument('--observer',type=int,required=True);s.add_argument('--seconds',type=int,default=150);s.add_argument('--out',type=Path,required=True)
    s=sub.add_parser('wake-summary');s.add_argument('--prefix',type=Path,required=True);s.add_argument('--cpus',required=True)
    s=sub.add_parser('fine-summary');s.add_argument('--prefix',type=Path,required=True);s.add_argument('--cpu',type=int,required=True);s.add_argument('--control',type=int,required=True)
    a=parser.parse_args()
    if a.command=='scan':scan(a)
    elif a.command=='screen':screen(a)
    elif a.command=='wake-summary':pretty([wake_data(a.prefix,c) for c in cpulist(a.cpus)])
    else:pretty(summarize_fine(a.prefix,a.cpu,a.control))
if __name__=='__main__':main()
