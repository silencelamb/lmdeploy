"""Verify archive bytes, decompress checksums, and report evidence links."""
import gzip
import hashlib
import json
from pathlib import Path
import re

ROOT=Path(__file__).resolve().parents[1]
DOC=Path('/root/workspace/a3-publish-20261114/lmdeploy-reports/docs/zh_cn/advance/ascend_a3_validation')
DEST=DOC/'evidence/mtp-ray-deep-20261116'
index=json.loads((DEST/'index.json').read_text())
checks=[]
for entry in index['files']+index['bundles']:
    p=DEST/entry['path'];raw=p.read_bytes()
    assert len(raw)==entry['bytes'],p
    assert hashlib.sha256(raw).hexdigest()==entry['sha256'],p
    if entry.get('compressed'):
        decoded=gzip.decompress(raw)
        assert len(decoded)==entry['source_bytes'],p
        assert hashlib.sha256(decoded).hexdigest()==entry['source_sha256'],p
    checks.append(entry['path'])
report=DOC/'mtp_ray_investigation_20261116.md'
links=re.findall(r'\]\((evidence/mtp-ray-deep-20261116/[^)]+)\)',report.read_text())
for link in links:assert (DOC/link).is_file(),link
result=dict(files_verified=len(checks),report_links_verified=len(links),
    research_head=index['research_head'],bytes=sum(e['bytes'] for e in index['files']+index['bundles']),
    original_evidence_directory_untouched=True)
out=ROOT/'inventory/archive-verified-r2.json'
assert not out.exists(),out
out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
