"""Create independently owned package files before any new CANN installer runs."""
import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT=Path(__file__).resolve().parents[1]
BASE=Path('/root/workspace/a3-mooncake-pr5030-20261113/envs/native')
DEST=ROOT/'envs/cann7-native'
assert not DEST.exists()
subprocess.run(['/usr/local/python3.12.13/bin/python3.12','-m','venv','--copies','--without-pip',str(DEST)],check=True)
src=BASE/'lib/python3.12/site-packages';out=DEST/'lib/python3.12/site-packages'
rows=[]
for item in sorted(src.iterdir()):
    if 'dlinfer' in item.name.lower():raise RuntimeError(item)
    if (item.name.startswith(('__editable__','torch_npu','triton_ascend-'))
        or item.name in ('triton','triton_dist','__pycache__')):
        rows.append(dict(name=item.name,action='excluded-for-replacement-or-source-pinning'));continue
    resolved=item.resolve();target=out/item.name
    if resolved.is_dir():shutil.copytree(resolved,target,symlinks=False,ignore=shutil.ignore_patterns('__pycache__'))
    else:shutil.copy2(resolved,target)
    rows.append(dict(name=item.name,action='independent-copy',source=str(resolved)))
manifest=dict(base=str(BASE),venv=str(DEST),time_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),entries=rows)
(ROOT/'inventory/cann7-env-creation-r0.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(DEST,flush=True)
