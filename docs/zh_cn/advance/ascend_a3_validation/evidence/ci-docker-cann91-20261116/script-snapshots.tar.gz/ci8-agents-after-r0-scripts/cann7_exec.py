"""Run logged setup/runtime commands with a private writable CANN installation."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

ROOT=Path(__file__).resolve().parents[1]
REPO=ROOT/'lmdeploy-cann7'
VENV=ROOT/'envs/cann7-native'
PREFIX=ROOT/'envs/cann7-Ascend'
p=argparse.ArgumentParser()
p.add_argument('--label',required=True)
p.add_argument('--mode',choices=('setup','runtime'),default='runtime')
p.add_argument('--devices',default='0')
p.add_argument('--timeout',type=int,default=900)
p.add_argument('command',nargs=argparse.REMAINDER)
a=p.parse_args();cmd=a.command[1:] if a.command[:1]==['--'] else a.command
assert cmd
PREFIX.mkdir(exist_ok=True)
env=os.environ.copy()
removed={}
for key,value in list(env.items()):
    if (key.startswith(('ASCEND_','ATB_')) or key in ('PYTHONPATH','PATH','LD_LIBRARY_PATH','BASH_ENV','ENV')
        or '/usr/local/Ascend/' in value):
        removed[key]=value;env.pop(key)
cann=PREFIX/'cann-9.2.0'
env.update(PATH=f'{VENV}/bin:{cann}/bin:{cann}/tools/bishengir/bin:{cann}/tools/bisheng_compiler/bin:{cann}/tools/ccec_compiler/bin:/usr/local/python3.12.13/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin',
           LD_LIBRARY_PATH=f'{cann}/lib64:{cann}/lib64/plugin/opskernel:{cann}/lib64/plugin/nnengine:{cann}/opp/built-in/op_impl/ai_core/tbe/op_tiling/lib/linux/aarch64:/usr/local/Ascend/driver/lib64:/usr/local/Ascend/driver/lib64/common:/usr/local/Ascend/driver/lib64/driver:/usr/local/python3.12.13/lib:/usr/local/lib',
           PYTHONPATH=f'{ROOT}/guard:{ROOT}/scripts:{REPO}:{cann}/python/site-packages:{cann}/opp/built-in/op_impl/ai_core/tbe',
           VIRTUAL_ENV=str(VENV),PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',
           TORCH_DEVICE_BACKEND_AUTOLOAD='0',FLA_NPU_DISABLE_PTH='1',
           ASCEND_RT_VISIBLE_DEVICES=a.devices,ASCEND_HOME_PATH=str(cann),
           ASCEND_TOOLKIT_HOME=str(cann),ASCEND_AICPU_PATH=str(cann),ASCEND_OPP_PATH=str(cann/'opp'),
           TOOLCHAIN_HOME=str(cann/'toolkit'),VALIDATION_ENV='review',VALIDATION_ROOT=str(ROOT),
           OMP_NUM_THREADS='1',OMP_PROC_BIND='false',TOKENIZERS_PARALLELISM='false',PYTHONUNBUFFERED='1',
           HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',TASK_QUEUE_ENABLE='1',
           HCCL_CONNECT_TIMEOUT='180',HCCL_OP_EXPANSION_MODE='AIV',HCCL_BUFFSIZE='512',
           PYTORCH_NPU_ALLOC_CONF='expandable_segments:True',LMDEPLOY_TARGET_DEVICE='ascend',
           TRITON_CACHE_DIR=str(ROOT/'artifacts/cann7-triton-cache'),
           TRITON_DUMP_DIR=str(ROOT/'artifacts'/f'{a.label}-triton-dump'),
           TORCH_EXTENSIONS_DIR=str(ROOT/'artifacts/cann7-torch-extensions'),
           CANN7_PARENT_MOUNT_NS=os.readlink('/proc/self/ns/mnt'),PIP_NO_INPUT='1',
           PIP_DISABLE_PIP_VERSION_CHECK='1')
if a.mode=='runtime':
    atb=PREFIX/'nnal/atb/latest/atb/cxx_abi_1'
    env['ATB_HOME_PATH']=str(atb)
    env['LD_LIBRARY_PATH']=f'{atb}/lib:{atb}/examples:{atb}/tests/atbopstest:'+env['LD_LIBRARY_PATH']
    env['PATH']=f'{atb}/bin:'+env['PATH']
os.sched_setaffinity(0,os.sched_getaffinity(0)-{18})
command=['unshare','--user','--map-root-user','--mount','--propagation','private',
         'bash',str(ROOT/'scripts/cann7_namespace.sh'),*cmd]
log=ROOT/'logs'/f'{a.label}.log';assert not log.exists()
snapshot=ROOT/'artifacts'/f'{a.label}-scripts';snapshot.mkdir()
for script in (ROOT/'scripts').glob('*.py'):
    (snapshot/script.name).write_bytes(script.read_bytes())
(snapshot/'cann7_namespace.sh').write_bytes((ROOT/'scripts/cann7_namespace.sh').read_bytes())
record=dict(command=command,cwd=str(REPO),mode=a.mode,source_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),
            start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            environment={k:v for k,v in env.items() if k in ('PATH','LD_LIBRARY_PATH','PYTHONPATH','VIRTUAL_ENV','FLA_NPU_DISABLE_PTH','TRITON_CACHE_DIR','PYTHONHASHSEED','LD_PRELOAD') or k.startswith(('ASCEND_','ATB_','VALIDATION_'))},
            cpu_affinity=sorted(os.sched_getaffinity(0)))
diff=subprocess.check_output(['git','diff','HEAD','--binary'],cwd=REPO)
(ROOT/'artifacts'/f'{a.label}.patch').write_bytes(diff);record['diff_sha256']=hashlib.sha256(diff).hexdigest()
start=time.monotonic()
with log.open('x') as output:
    child=subprocess.Popen(command,cwd=REPO,env=env,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
    try:rc=child.wait(timeout=a.timeout)
    except subprocess.TimeoutExpired:
        os.killpg(child.pid,signal.SIGTERM)
        try:child.wait(timeout=15)
        except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
        rc=124
record.update(returncode=rc,elapsed_seconds=time.monotonic()-start)
(ROOT/'logs'/f'{a.label}.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(label=a.label,returncode=rc,elapsed_seconds=record['elapsed_seconds'])))
print('\n'.join(line[:350] for line in log.read_text(errors='replace').splitlines()[-15:]))
raise SystemExit(rc)
