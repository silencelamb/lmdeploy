# Triton kernel执行流程
在Ascend后端上，Triton kernel的执行流程包括两个阶段：**kernel编译** 和 **kernel执行**。
## kernel 编译阶段
编译阶段又分为几个子阶段，如下图所示：
@startuml
start
:Triton Python DSL;
-> 1. AST 处理;
:ASTSource;
-> 2. triton 前端（由 Triton 社区代码实现）;
:ttir;
-> 3. triton ascend 后端（由 triton-ascend 代码实现）;
:ttadapter ir（linalg ir）、host C++源码及二进制库;
-> 4. BiSheng 编译器;
:npuir 及 npubin;
end
@enduml

* 编译阶段可能遇到的问题

**1. AST处理阶段**：做语义过滤，检查是否符合Triton DSL，生成用于表示抽象语法树的结构类。一般不会报错。\
**2. triton前端处理**：把Python AST转成Triton自己的AST节点，根据Triton语法，生成ttir，通过Triton原生代码实现。当kernel内容违反Triton官方语法时，会报错。根据错误信息修改代码即可。\
**3. triton后端处理**：把ttir转成ttadapter ir，通过triton-ascend代码实现。常见问题：**coredump**或**error报错**。关键字“[ConvertTritonIRToLinalgIR] encounters error”。\
**4. BiSheng编译**：把ttadapter ir转化为AscendNPU IR，再编译成NPU device可执行的二进制文件。常见问题：**coredump**、**error报错**、**ub overflow**。关键字“[ConvertLinalgRToBinary] encounters error”。

## kernel 执行阶段

包括申请device资源、device二进制注册和kernel Launch执行。执行阶段报错一般为Runtime问题，需结合CANN的错误提示信息进行定位和修改。

# Triton官方调测方法
运行正常是算子开发后进行调测的前提，是后续进行性能优化的基础。

## Triton社区调测方法
Triton社区提供了一些用于维测的api，如`triton.language.static_print`(用于打印编译期变量)、`triton.language.device_print`(用于打印运行时变量)，可用于打印中间结果。具体用法请参考：[triton.language.static_print — Triton 文档](https://triton-lang.org/main/python-api/generated/triton.language.static_print.html)、[triton.language.device_print — Triton 文档](https://triton-lang.org/main/python-api/generated/triton.language.device_print.html)。

## 环境变量
全部环境变量可参考：[triton-ascend调测相关环境变量及说明](https://gitee.com/ascend/triton-ascend/blob/master/docs/ENVIRONMENT.md)。

常用调试环境变量：
- **TRITON_DEBUG**：用于dump编译过程中产生的中间ir。
- **TRITON_INTERPRET**：用于开启解释器模式。
- **TRITON_ALWAYS_COMPILE**：忽视kernel cache，每次运行时强制重新编译Triton kernel。

# 典型问题及调试方法
## ub overflow 问题
此类问题常见报错为 `error: ub overflow, requires xxx bits while xxx bits available`，比如`error: ub overflow, requires 5263360 bits while 1572864 bits available`。
华为昇腾910B NPU的ub大小为192k。由于NPU与GPU的硬件差异和编译器差异，基于GPU调好的BLOCK_SIZE可能不适用于NPU后端，具体表现为ub overflow问题，一般方法是根据ub overflow报错信息估算超出的规模，基于该倍率调整BLOCK_SIZE大小。

kernel计算所需UB大小，通常与BLOCK_SIZE规模成正比，用报错信息中的实际所需size除以UB size上限，获得UB超出倍数，取可覆盖该倍数的2的幂次方，修改该kernel的BLOCK_SIZE使其总乘积缩小该幂次倍数，通常可以解决ub overflow问题。

一些情况下，修改block_size无法解决该问题，可以尝试在kernel内进行分块，减小单次需要放入ub的数据量，从而解决ub overflow的问题

## grid > 65535 问题
此问题的常见报错为 `RuntimeError: grid should be less than 65536! You can try "export TRITON_ALL_BLOCKS_PARALLEL=1" to avoid this problem.`
此类问题是由于程序实例的数量超过了实际需要处理的数据范围。一般的修改方法是调大block size，从而增加每个线程处理的数据量。如果增大block size后出现ub overflow的问题，需要在kernel内部则增加for循环对block进行分块进行处理。

# 精度问题定位思路
## 同步问题排除
在kernel调用处实参指定`inject_barrier_all=True`参数，给每个阶段插入同步操作，以排除同步问题导致的精度异常。使用示例如下：
```python
@triton.jit
def kernel(...):
    ...

# 调用kernel
kernel[grid](
    ...
    inject_barrier_all=True,
)
```

## 解释器模式调试
### 1. 何为解释器模式

**解释器模式（Interpreter Mode）** 是Triton提供的一种非编译执行路径，用于在CPU上模拟Triton kernel的执行逻辑。在解释器模式下，可以通过print函数打印每个操作的中间结果，也可以在Triton kernel里添加pdb断点，进行单步调试。主要用于检查kernel计算逻辑是否有误。

### 2. 解释器模式使用方法

使能环境变量`export TRITON_INTERPRET=1`，之后正常执行脚本即可。

**注意事项：**

- 解释器模式是通过numpy模拟NPU行为的，numpy不支持bfloat16格式数据，因此无法通过解释器模式调试bfloat16数据场景。可以使用float16或float32进行替代。
- 解释器模式对调试环境的numpy版本有约束，要求numpy版本小于2.0。

# 自检排查方向
## 正确计算偏移地址
在Triton中，算子通常通过program_id来区分不同的并行实例。每个program对应一个逻辑上的“核”，负责处理输入数据的一部分。为了保证每个program能够正确访问其对应的数据区间，需要在kernel内部计算偏移地址。该偏移地址决定了该program在Global Memory上的起始位置。
假设数据整体长度 TOTAL_LENGTH = 8 * 2048 个元素，平均分配到 8 个 program 上运行。每个 program 处理的数据大小为 block_size = 2048。`block_size × tl.program_id(0)` 为该program的起始偏移地址， `tl.arange(0, block_size)` 为局部线程索引，`block_size × tl.program_id(0)+ tl.arange(0, block_size)`为全局偏移地址。以下为一个具体实例：
```python
@libentry()
@triton.jit
def any_kernel_1(
    inp,
    mid,
    n_elements,
    mid_size,
    BLOCK_SIZE: tl.constexpr,
)
    pid = tle.program_id(0) # 当前program的索引
    offset = pid * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE) #全局偏移索引：当前program的起始偏移地址+ 当前program内的局部范围 [0，BLOCK_SIZE]，pid * BLOCK_SIZE为起始偏移地址，tl.arange(0, BLOCK_SIZE)为当前program内的局部范围
    inp_ptrs = inp + offset #根据offset计算输入张量的指针位置
    mask = offset < n_elements #防止越界访问
    inp_val = tl.load(inp_ptrs, mask=mask, other=0.0) #从全局内存加载数据，inp_ptrs为加载地址，mask控制有效范围，other=0.0表示越界位置填充为0
    any_val = tl.reduce(inp_val != 0, axis=0, combine_fn=reduce_any) #在当前block维度上进行归约，只要有一个非零就返回True
    mid_ptr = mid + pid #计算当前program的对应输出位置
    tl.store(mid_ptr, any_val) #存储结果，表示该block内是否存在非零元素
```

## 浮点数计算
某些型号的AI处理器指令支持的数据类型有限，当发现某个API支持的数据类型不
能满足需求时，应更倾向于先将数据转换到更高的精度进行计算后，再将计算结果转换到目标精度，来防止精度损失。例如，某款AI处理器Vector计算类API不支持bfloat16的计算，需要先使用Cast接口转换成float数据类型，进行计算后再转换回bfloat16数据类型。 示例如下：

```python
# x、y、out均为bfloat16类型
x = tl.load(x_ptr + offset_x, mask=mask_x).to(tl.float32)
y = tl.load(y_ptr + offset_y, mask=mask_y).to(tl.float32)
z = tl.dot(x, y)
tl.store(out_ptr + offset_o, z.to(tl.bfloat16))
```
