# Copyright © 2025 Huawei Technologies Co., Ltd.

import torch
import torch_npu
import pytest

from triton_ascend_kernels.deterministic import mean_batch_invariant


def mean_batch_invariant_ref(
    input_x: torch.Tensor,
    dim: int,
    keepdim: bool = False,
    dtype: torch.dtype | None = None,
) -> torch.Tensor:
    return torch.mean(input_x, dim=dim, keepdim=keepdim, dtype=dtype)


@pytest.mark.parametrize("batch_size", [32, 64, 128])
@pytest.mark.parametrize("hidden_size", [32, 64, 128])
def test_accuracy_mean_batch_invariant(
    batch_size: int,
    hidden_size: int,
):
    torch.manual_seed(42)

    x = torch.randn(batch_size, hidden_size, dtype=torch.float32).npu()
    dim = torch.Tensor([1]).npu().to(torch.int64)
    res_triton = mean_batch_invariant(
        input_x=x, dim=dim, keepdim=False, dtype=torch.float32
    )
    res_ref = mean_batch_invariant_ref(
        input_x=x, dim=1, keepdim=False, dtype=torch.float32
    )
    torch.testing.assert_close(res_ref, res_triton, rtol=1e-3, atol=1e-3)
