# Copyright © 2025 Huawei Technologies Co., Ltd.
# Copyright contributors to the vLLM project
import torch
import pytest
from torch.testing import assert_close
from triton_ascend_kernels.index import pack_seq_triton, unpack_seq_triton

DEVICE = "npu"
DTYPES = [torch.bfloat16]


@pytest.mark.pack_seq_basic
@pytest.mark.parametrize("dtype", DTYPES)
def test_accuracy_pack_seq_basic_bf16(dtype):
    test_cases = [
        (6, 8, 4, 2, [3, 3]),
        (10, 4, 8, 3, [2, 4, 4]),
        (20, 16, 32, 4, [5, 5, 5, 5]),
    ]

    for N, H, D, B, lengths_list in test_cases:
        x = torch.randn(N, H, D, dtype=torch.float32, device=DEVICE) * 0.1
        x = x.to(dtype=dtype)
        lengths = torch.tensor(lengths_list, device=DEVICE)

        packed = pack_seq_triton(x, lengths)

        expected_shape = (B, max(lengths_list), H, D)
        assert packed.shape == expected_shape
        assert packed.dtype == dtype
        assert packed.device == x.device

        for b in range(B):
            start_idx = sum(lengths_list[:b])
            seq_len = lengths_list[b]

            expected_data = x[start_idx : start_idx + seq_len].to(torch.float32)
            actual_data = packed[b, :seq_len].to(torch.float32)

            assert_close(actual_data, expected_data, rtol=1e-1, atol=1e-2)


@pytest.mark.pack_seq_custom_padding
@pytest.mark.parametrize("dtype", DTYPES)
def test_accuracy_pack_seq_custom_padding_bf16(dtype):
    N, H, D, B = 20, 8, 16, 2
    lengths = torch.tensor([10, 10], device=DEVICE)

    x = torch.randn(N, H, D, dtype=torch.float32, device=DEVICE) * 0.1
    x = x.to(dtype=dtype)

    pad_values = [-100.0, -10.0, 0.0, 10.0, 100.0]
    for pad_value in pad_values:
        result = pack_seq_triton(x, lengths, pad_value=pad_value)

        for b in range(B):
            start_idx = b * 10
            expected_data = x[start_idx : start_idx + 10].to(torch.float32)
            actual_data = result[b, :10].to(torch.float32)
            assert_close(actual_data, expected_data, rtol=1e-1, atol=1e-2)

        padded_data = result[:, 10:].to(torch.float32)
        if pad_value < 0:
            assert torch.all(padded_data < -50)
        elif pad_value > 0:
            assert torch.all(padded_data > 50)
        else:
            assert torch.allclose(padded_data, torch.zeros_like(padded_data), atol=1e-2)


@pytest.mark.pack_seq_default_padding
@pytest.mark.parametrize("dtype", DTYPES)
def test_accuracy_pack_seq_default_negative_inf_padding_bf16(dtype):
    N, H, D = 20, 8, 16
    lengths = torch.tensor([10, 10], device=DEVICE)

    x = torch.randn(N, H, D, dtype=torch.float32, device=DEVICE) * 0.1
    x = x.to(dtype=dtype)
    result = pack_seq_triton(x, lengths)

    padded_data = result[:, 10:].to(torch.float32)
    assert torch.all(padded_data < -100)


@pytest.mark.pack_seq_edge_cases
@pytest.mark.parametrize("dtype", DTYPES)
def test_accuracy_pack_seq_edge_cases_bf16(dtype):
    x1 = torch.randn(10, 8, 16, dtype=torch.float32, device=DEVICE) * 0.1
    x1 = x1.to(dtype=dtype)
    lengths1 = torch.tensor([10], device=DEVICE)
    result1 = pack_seq_triton(x1, lengths1)
    assert result1.shape == (1, 10, 8, 16)

    x2 = torch.randn(20, 4, 8, dtype=torch.float32, device=DEVICE) * 0.1
    x2 = x2.to(dtype=dtype)
    lengths2 = torch.tensor([1, 1, 1], device=DEVICE)
    result2 = pack_seq_triton(x2, lengths2)
    assert result2.shape == (3, 1, 4, 8)

    x3 = torch.randn(15, 8, 16, dtype=torch.float32, device=DEVICE) * 0.1
    x3 = x3.to(dtype=dtype)
    lengths3 = torch.tensor([5, 7, 3], device=DEVICE)
    result3 = pack_seq_triton(x3, lengths3)
    assert result3.shape == (3, 7, 8, 16)


@pytest.mark.pack_seq_block_sizes
@pytest.mark.parametrize("dtype", DTYPES)
def test_accuracy_pack_seq_different_block_sizes_bf16(dtype):
    N, H, D, B = 100, 16, 32, 4
    lengths = torch.tensor([25, 25, 25, 25], device=DEVICE)

    x = torch.randn(N, H, D, dtype=torch.float32, device=DEVICE) * 0.1
    x = x.to(dtype=dtype)

    block_sizes = [(32, 32), (64, 64), (128, 128)]
    for block_t, block_d in block_sizes:
        result = pack_seq_triton(x, lengths, block_t=block_t, block_d=block_d)

        assert result.shape == (B, 25, H, D)

        for b in range(B):
            start_idx = b * 25
            expected_data = x[start_idx : start_idx + 25].to(torch.float32)
            actual_data = result[b, :25].to(torch.float32)
            assert_close(actual_data, expected_data, rtol=1e-1, atol=1e-2)


@pytest.mark.pack_seq_shape_consistency
@pytest.mark.parametrize("dtype", DTYPES)
def test_accuracy_pack_seq_shape_consistency(dtype):
    N, H, D, B = 20, 8, 16, 2
    lengths = torch.tensor([10, 10], device=DEVICE)

    x = torch.randn(N, H, D, dtype=torch.float32, device=DEVICE) * 0.1
    x = x.to(dtype=dtype)
    result = pack_seq_triton(x, lengths)

    assert result.shape[0] == B
    assert result.shape[1] == lengths.max().item()
    assert result.shape[2:] == x.shape[1:]


@pytest.mark.pack_unpack_roundtrip
@pytest.mark.parametrize("dtype", DTYPES)
def test_accuracy_pack_unpack_roundtrip_bf16(dtype):
    test_cases = [
        (6, 8, 4, 2, [3, 3]),
        (10, 4, 8, 3, [2, 4, 4]),
        (20, 16, 32, 4, [5, 5, 5, 5]),
        (15, 8, 16, 3, [7, 5, 3]),
    ]

    for N, H, D, _, lengths_list in test_cases:
        x = torch.randn(N, H, D, dtype=torch.float32, device=DEVICE) * 0.1
        x = x.to(dtype=dtype)
        lengths = torch.tensor(lengths_list, device=DEVICE)

        packed = pack_seq_triton(x, lengths)
        unpacked = unpack_seq_triton(packed, lengths)

        assert unpacked.shape == x.shape
        x_f32 = x.to(torch.float32)
        unpacked_f32 = unpacked.to(torch.float32)
        assert_close(x_f32, unpacked_f32, rtol=1e-3, atol=1e-3)

        unpacked_with_loc = unpack_seq_triton(packed, lengths)
        assert_close(x_f32, unpacked_with_loc.to(torch.float32), rtol=1e-3, atol=1e-2)


@pytest.mark.unpack_seq_edge_cases
@pytest.mark.parametrize("dtype", DTYPES)
def test_accuracy_unpack_seq_triton_edge_cases_bf16(dtype):
    x1 = torch.randn(10, 8, 16, dtype=torch.float32, device=DEVICE) * 0.1
    x1 = x1.to(dtype=dtype)
    lengths1 = torch.tensor([10], device=DEVICE)
    packed1 = pack_seq_triton(x1, lengths1)
    unpacked1 = unpack_seq_triton(packed1, lengths1)
    assert unpacked1.shape == x1.shape
    assert_close(
        x1.to(torch.float32), unpacked1.to(torch.float32), rtol=1e-1, atol=1e-2
    )

    x2 = torch.randn(20, 4, 8, dtype=torch.float32, device=DEVICE) * 0.1
    x2 = x2.to(dtype=dtype)
    lengths2 = torch.tensor([1, 1, 1], device=DEVICE)
    packed2 = pack_seq_triton(x2, lengths2)
    unpacked2 = unpack_seq_triton(packed2, lengths2)
    assert_close(
        x2[:3].to(torch.float32), unpacked2.to(torch.float32), rtol=1e-1, atol=1e-2
    )

    x3 = torch.randn(15, 8, 16, dtype=torch.float32, device=DEVICE) * 0.1
    x3 = x3.to(dtype=dtype)
    lengths3 = torch.tensor([5, 7, 3], device=DEVICE)
    packed3 = pack_seq_triton(x3, lengths3)
    unpacked3 = unpack_seq_triton(packed3, lengths3)
    assert unpacked3.shape == x3.shape
    assert_close(
        x3.to(torch.float32), unpacked3.to(torch.float32), rtol=1e-1, atol=1e-2
    )
