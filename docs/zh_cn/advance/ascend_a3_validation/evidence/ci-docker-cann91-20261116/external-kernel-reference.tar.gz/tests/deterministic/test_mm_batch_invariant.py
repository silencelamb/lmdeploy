# Copyright © 2025 Huawei Technologies Co., Ltd.

import torch
import torch_npu
import pytest

from triton_ascend_kernels.deterministic import mm_batch_invariant
from triton_ascend_kernels.deterministic import linear_batch_invariant


def mm_batch_invariant_ref(
    x: torch.Tensor,
    y: torch.Tensor,
) -> torch.Tensor:
    return torch.matmul(x, y)


def linear_batch_invariant_ref(
    x: torch.Tensor,
    y: torch.Tensor,
    bias: torch.Tensor,
) -> torch.Tensor:
    return torch.matmul(x, y.t()) + bias


@pytest.mark.parametrize(
    "shape",
    [
        (1, 1024, 151936),
        (1, 1024, 4096),
        (1, 1024, 6144),
        (1, 2048, 1024),
        (1, 3072, 1024),
        (5, 1024, 4096),
        (5, 1024, 6144),
        (5, 2048, 1024),
        (5, 3072, 1024),
    ],
)
def test_accuracy_mm_batch_invariant(
    shape,
):
    torch.manual_seed(42)

    M, K, N = shape
    x = torch.randn(M, K, device="npu", dtype=torch.float16)
    y = torch.randn(K, N, device="npu", dtype=torch.float16)

    res_triton = mm_batch_invariant(x, y)
    res_ref = mm_batch_invariant_ref(x, y)
    torch.testing.assert_close(res_ref, res_triton, rtol=1e-3, atol=1e-3)


@pytest.mark.parametrize(
    "shape",
    [
        (1, 1024, 151936),
        (1, 1024, 4096),
        (1, 1024, 6144),
        (1, 2048, 1024),
        (1, 3072, 1024),
        (5, 1024, 4096),
        (5, 1024, 6144),
        (5, 2048, 1024),
        (5, 3072, 1024),
    ],
)
def test_accuracy_linear_batch_invariant(
    shape,
):
    torch.manual_seed(42)

    M, K, N = shape
    x = torch.randn(M, K, device="npu", dtype=torch.float16)
    y = torch.randn(N, K, device="npu", dtype=torch.float16)
    bias = torch.randn(M, 1, device="npu", dtype=torch.float16)
    res_triton = linear_batch_invariant(x, y, bias)
    res_ref = linear_batch_invariant_ref(x, y, bias)
    torch.testing.assert_close(res_ref, res_triton, rtol=1e-3, atol=1e-3)
