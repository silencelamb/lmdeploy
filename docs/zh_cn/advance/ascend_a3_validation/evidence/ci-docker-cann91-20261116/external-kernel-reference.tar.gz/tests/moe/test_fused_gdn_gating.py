# Copyright © 2025 Huawei Technologies Co., Ltd.
# Copyright contributors to the vLLM project
import torch
import pytest
import torch.nn.functional as F

from triton_ascend_kernels.moe import fused_gdn_gating


def _fused_gdn_gating_reference_impl(
    A_log: torch.Tensor,
    a: torch.Tensor,
    b: torch.Tensor,
    dt_bias: torch.Tensor,
    beta: float = 1.0,
    threshold: float = 20.0,
) -> torch.Tensor:
    g = -A_log.float().exp() * F.softplus(a.float() + dt_bias)
    beta_output = b.sigmoid()

    return g.unsqueeze(0), beta_output.unsqueeze(0)


@pytest.mark.parametrize("tp_size", [1])
@pytest.mark.parametrize("num_v_heads", [8, 32, 128])
@pytest.mark.parametrize("batch", [1, 7168, 64 * 4096])
def test_accuracy_triton_fused_gdn_gating(batch, num_v_heads, tp_size):
    device = "npu"
    A_log = torch.randn(num_v_heads // tp_size, dtype=torch.float32, device=device)
    a = torch.randn((batch, num_v_heads // tp_size), dtype=torch.float32, device=device)
    b = torch.randn((batch, num_v_heads // tp_size), dtype=torch.float32, device=device)
    dt_bias = torch.ones((num_v_heads // tp_size), dtype=torch.float32, device=device)

    result = fused_gdn_gating(
        A_log,
        a,
        b,
        dt_bias,
    )

    reference_result = _fused_gdn_gating_reference_impl(
        A_log,
        a,
        b,
        dt_bias,
    )

    torch.testing.assert_close(result[0], reference_result[0], rtol=1e-5, atol=1e-5)
    torch.testing.assert_close(result[1], reference_result[1], rtol=1e-5, atol=1e-5)
