# Copyright © 2026 Huawei Technologies Co., Ltd.

import torch
import torch_npu
import torch.nn.functional as F
import pytest

from triton_ascend_kernels.deterministic import log_softmax_batch_invariant


def log_softmax_batch_invariant_ref(
    input_x: torch.Tensor, dim: int = -1
) -> torch.Tensor:
    """
    Compute log_softmax using PyTorch.

    Args:
        input_x: Input tensor
        dim: Dimension along which to compute log_softmax

    Returns:
        Tensor with log_softmax applied along the specified dimension
    """
    return F.log_softmax(input_x, dim=dim)


@pytest.mark.parametrize("batch_size", [32, 64, 128])
@pytest.mark.parametrize("hidden_size", [152064])
@pytest.mark.parametrize("dtype", [torch.bfloat16, torch.float16, torch.float32])
def test_accuracy_log_softmax_batch_invariant(
    batch_size: int,
    hidden_size: int,
    dtype,
):
    torch.manual_seed(42)

    x = torch.randn(batch_size, hidden_size, dtype=dtype).npu()
    res_triton = log_softmax_batch_invariant(input_x=x, dim=-1)
    res_ref = log_softmax_batch_invariant_ref(input_x=x, dim=-1)
    torch.testing.assert_close(res_ref, res_triton, rtol=1e-3, atol=1e-3)
