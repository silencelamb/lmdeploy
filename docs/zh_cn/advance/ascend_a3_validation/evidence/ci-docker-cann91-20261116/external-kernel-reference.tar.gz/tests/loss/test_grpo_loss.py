# Copyright © 2025 Huawei Technologies Co., Ltd.
# Copyright (c) 2025, DeepLink.
import torch
import pytest
from triton_ascend_kernels.loss import GRPOLoss


def torch_grpo_loss(
    _logprobs,
    _old_logprobs,
    _advantages,
    _ref_logprobs,
    kl_type=1,
    kl_coef=1.0,
    _loss_factor=1.0,
    clip=0.2,
):
    kl_type_map = {"kl": 0, "unbias": 1, "mse": 2}
    kl_type = kl_type_map.get(kl_type, None)
    if kl_type is None:
        raise ValueError(f"Unsupported KL type: {kl_type}")

    logprobs_diff = _logprobs - _old_logprobs
    ratio = torch.exp(logprobs_diff)
    pg_losses = -_advantages.unsqueeze(1) * ratio
    pg_losses2 = -_advantages.unsqueeze(1) * torch.clamp(ratio, 1.0 - clip, 1.0 + clip)
    pg_loss_max = torch.max(pg_losses, pg_losses2)
    pg_loss = pg_loss_max.sum()
    _loss = pg_loss * _loss_factor

    # Compute KL penalty loss
    if kl_type == 0:
        kl = _ref_logprobs - _logprobs
        _kl_penalty_loss = (kl_coef * kl).sum(dim=1) * _loss_factor
    elif kl_type == 1:
        kl = _ref_logprobs - _logprobs
        nonneg_nobias_kl = torch.exp(kl) - kl - 1
        _kl_penalty_loss = (kl_coef * nonneg_nobias_kl).sum(dim=1) * _loss_factor
    elif kl_type == 2:
        _kl_penalty_loss = (kl_coef * (_ref_logprobs - _logprobs).square() / 2).sum(
            dim=1
        ) * _loss_factor
    else:
        raise ValueError(f"Unsupported KL type: {kl_type}")

    loss = _loss + _kl_penalty_loss
    return loss


def triton_grpo_loss(
    log_probs,
    log_probs1,
    log_probs2,
    advantages,
    kl_type,
    kl_coef,
    loss_factor,
    clip,
    BLOCK_SIZE_T,
):
    assert log_probs is not None and log_probs1 is not None and log_probs2 is not None
    return GRPOLoss.apply(
        log_probs,
        log_probs1,
        log_probs2,
        advantages,
        kl_type,
        kl_coef,
        loss_factor,
        clip,
        BLOCK_SIZE_T,
    )


GRPO_SHAPES_TV = [(32, 1024)]  # (T, V)：sequence length, vocab size
GRPO_KL_TYPES = ["kl", "unbias", "mse"]  # KL type
GRPO_CONFIG = {
    "dtype": torch.float32,
    "block_size_t": 4,
    "kl_coef": 1.0,
    "loss_factor": 1.0,
    "clip": 0.2,
    "rtol": 1e-2,
    "atol": 1e-4,
}


@pytest.mark.grpo_loss
@pytest.mark.parametrize("T, V", GRPO_SHAPES_TV)
@pytest.mark.parametrize("kl_type", GRPO_KL_TYPES)
def test_accuracy_grpo_loss(T, V, kl_type):
    torch.manual_seed(42)
    dtype = GRPO_CONFIG["dtype"]
    device = torch.device("npu")

    advantages = torch.randn((T,), dtype=dtype, device=device, requires_grad=True)
    log_probs = torch.randn((T, V), dtype=dtype, device=device, requires_grad=True)
    log_probs1 = torch.randn((T, V), dtype=dtype, device=device, requires_grad=True)
    log_probs2 = torch.randn((T, V), dtype=dtype, device=device, requires_grad=True)

    std_advantages = advantages.clone().detach().requires_grad_(True)
    std_log_probs = log_probs.clone().detach().requires_grad_(True)
    std_log_probs1 = log_probs1.clone().detach().requires_grad_(True)
    std_log_probs2 = log_probs2.clone().detach().requires_grad_(True)
    cfg = GRPO_CONFIG
    rtol = cfg["rtol"]
    atol = 2e-4 if kl_type == "mse" else cfg["atol"]

    tri_loss = triton_grpo_loss(
        log_probs,
        log_probs1,
        log_probs2,
        advantages,
        kl_type,
        cfg["kl_coef"],
        cfg["loss_factor"],
        cfg["clip"],
        cfg["block_size_t"],
    )
    tri_loss.backward(tri_loss)

    ref_loss = torch_grpo_loss(
        std_log_probs,
        std_log_probs1,
        std_advantages,
        std_log_probs2,
        kl_type,
        cfg["kl_coef"],
        cfg["loss_factor"],
        cfg["clip"],
    )
    ref_loss.backward(ref_loss)

    print(
        "forward accuracy: ", torch.allclose(tri_loss, ref_loss, rtol=1e-2, atol=1e-4)
    )
    print(
        "backward accuracy: ",
        torch.allclose(log_probs.grad, std_log_probs.grad, rtol=1e-2, atol=1e-4),
    )
