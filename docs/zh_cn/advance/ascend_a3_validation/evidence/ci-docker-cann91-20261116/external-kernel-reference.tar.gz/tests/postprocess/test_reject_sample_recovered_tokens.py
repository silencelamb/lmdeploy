# Copyright © 2025 Huawei Technologies Co., Ltd.
import pytest
import torch
from triton_ascend_kernels.postprocess import sample_recovered_tokens_triton


def sample_recovered_tokens_pytorch(
    output_token_ids,
    cu_num_draft_tokens,
    draft_token_ids,
    draft_probs,
    target_probs,
    q,
    vocab_size,
    IS_NGRAM=False,
):
    batch_size = len(cu_num_draft_tokens)
    for req_idx in range(batch_size):
        start_idx = 0 if req_idx == 0 else cu_num_draft_tokens[req_idx - 1]
        end_idx = cu_num_draft_tokens[req_idx]
        num_draft_tokens = end_idx - start_idx

        for pos in range(num_draft_tokens):
            token_idx = start_idx + pos
            if IS_NGRAM:
                draft_token_id = draft_token_ids[token_idx]
                orig_prob = target_probs[token_idx, draft_token_id].item()
                target_probs[token_idx, draft_token_id] = 0
                prob = target_probs[token_idx].clone()
            else:
                draft_p = draft_probs[token_idx].clone()
                target_p = target_probs[token_idx].clone()
                prob = torch.maximum(
                    target_p - draft_p, torch.tensor(0.0, device=target_p.device)
                )

            q_values = torch.full((vocab_size,), float("-inf"), device=q.device)
            q_values[:vocab_size] = q[req_idx, :vocab_size]

            recovered_id = torch.argmax(prob / q_values).item()
            output_token_ids[token_idx] = recovered_id

            if IS_NGRAM:
                target_probs[token_idx, draft_token_id] = orig_prob


@pytest.fixture
def device():
    return "npu"


@pytest.fixture(autouse=True)
def setup_seed():
    torch.manual_seed(42)


def test_accuracy_sample_recovered_tokens_deterministic(device):
    output_token_ids = torch.empty(2, dtype=torch.int32, device=device)
    cu_num_draft_tokens = torch.tensor([1, 2], dtype=torch.int32, device=device)
    draft_token_ids = torch.tensor([0, 1], dtype=torch.int32, device=device)

    draft_probs = torch.tensor(
        [[0.6, 0.1, 0.3], [0.2, 0.7, 0.1]], dtype=torch.float32, device=device
    )
    target_probs = torch.tensor(
        [[0.8, 0.1, 0.1], [0.3, 0.6, 0.1]], dtype=torch.float32, device=device
    )
    q = torch.tensor(
        [[0.5, 0.3, 0.2], [0.1, 0.8, 0.1]], dtype=torch.float32, device=device
    )
    vocab_size = q.shape[-1]

    sample_recovered_tokens_pytorch(
        output_token_ids,
        cu_num_draft_tokens,
        draft_token_ids,
        draft_probs,
        target_probs,
        q,
        vocab_size,
    )

    output_token_ids_triton = torch.empty(2, dtype=torch.int32, device=device)
    sample_recovered_tokens_triton(
        output_token_ids_triton,
        cu_num_draft_tokens,
        draft_token_ids,
        draft_probs,
        target_probs,
        q,
        max_spec_len=2,
    )

    assert output_token_ids[0].item() == 0
    assert output_token_ids[1].item() == 0
    torch.testing.assert_close(
        output_token_ids, output_token_ids_triton, atol=1e-3, rtol=1e-5
    )


@pytest.mark.parametrize("batch_size", [1, 2, 8])
@pytest.mark.parametrize("vocab_size", [1024, 32000, 129280])
@pytest.mark.parametrize("max_spec_len", [2, 5])
def test_accuracy_sample_recovered_tokens_random_shapes(
    batch_size, vocab_size, max_spec_len, device
):

    # 1. Generate cu_num_draft_tokens
    num_draft_per_req = torch.randint(
        1, max_spec_len + 1, (batch_size,), device=device, dtype=torch.int32
    )
    cu_num_draft_tokens = torch.cumsum(num_draft_per_req, dim=0).int()
    total_draft_tokens = cu_num_draft_tokens[-1].item()

    # 2. Prepare Tensor
    output_token_ids = torch.empty(total_draft_tokens, dtype=torch.int32, device=device)
    output_token_ids_triton = torch.empty(
        total_draft_tokens, dtype=torch.int32, device=device
    )

    draft_token_ids = torch.randint(
        0, vocab_size, (total_draft_tokens,), dtype=torch.int32, device=device
    )

    # 3. Softmax normalized
    draft_probs = torch.randn(
        total_draft_tokens, vocab_size, dtype=torch.float32, device=device
    )
    draft_probs = torch.softmax(draft_probs, dim=-1)

    target_probs = torch.randn(
        total_draft_tokens, vocab_size, dtype=torch.float32, device=device
    )
    target_probs = torch.softmax(target_probs, dim=-1)

    q = torch.randn(batch_size, vocab_size, dtype=torch.float32, device=device)
    q = torch.softmax(q, dim=-1)

    # 4. PyTorch
    sample_recovered_tokens_pytorch(
        output_token_ids,
        cu_num_draft_tokens,
        draft_token_ids,
        draft_probs,
        target_probs,
        q,
        vocab_size,
        IS_NGRAM=False,
    )

    # 5. Triton
    sample_recovered_tokens_triton(
        output_token_ids_triton,
        cu_num_draft_tokens,
        draft_token_ids,
        draft_probs,
        target_probs,
        q,
        max_spec_len,
    )

    # 6. verification
    print(
        f"\n[Params] B={batch_size}, V={vocab_size}, SpecLen={max_spec_len}, TotalTokens={total_draft_tokens}"
    )

    torch.testing.assert_close(
        output_token_ids, output_token_ids_triton, atol=1e-3, rtol=1e-5
    )
