# Copyright © 2025 Huawei Technologies Co., Ltd.

import torch
import torch_npu
import pytest

from triton_ascend_kernels.norm import rms_norm_batch_invariant


def rms_norm_batch_invariant_ref(
    x: torch.Tensor,
    weight: torch.Tensor,
    eps: float = 1e-6,
):
    return torch_npu.npu_rms_norm(x, weight, 1e-6)[0]


@pytest.mark.parametrize("batch_size", [2048, 4096, 8192])
@pytest.mark.parametrize("seq_len", [8, 16, 32])
@pytest.mark.parametrize("hidden_size", [32, 64, 128])
@pytest.mark.parametrize("dtype", [torch.float16, torch.float32])
def test_accuracy_rms_norm_batch_invariant(
    batch_size: int, seq_len: int, hidden_size: int, dtype
):
    x = torch.randn(batch_size, seq_len, hidden_size, device="npu", dtype=dtype)
    weight = torch.randn(hidden_size, device="npu", dtype=dtype)
    res_ref = rms_norm_batch_invariant_ref(x, weight)
    res_triton = rms_norm_batch_invariant(x, weight)
    torch.testing.assert_close(res_ref, res_triton, rtol=1e-3, atol=1e-3)
