# Copyright © 2025 Huawei Technologies Co., Ltd.
import random
import pytest
import torch
import torch_npu
import torch.nn.functional as F

from triton_ascend_kernels.attention import decode_attention_fwd


device = "npu"


@pytest.fixture(autouse=True)
def setup_seed():
    """
    Pytest fixture: Automatically set random seeds before each test run.
    autouse=True indicates that there is no need to manually call and it will be automatically applied.
    """
    seed = 42
    random.seed(seed)
    torch.manual_seed(seed)


def scaled_dot_product_attention_golden(q, k, v, b_seq_len, sm_scale):
    """
    Golden implementation
    """
    B, H_Q, D = q.shape
    _, H_KV, _ = k.shape

    # Initialize output tensors
    attn_logits = []
    attn_lse = []

    # Loop over each batch item
    for i in range(B):
        # Slice the key and value buffers according to the sequence length of the current batch item
        start = b_seq_len[i].item()
        end = b_seq_len[i + 1].item()
        k_i = k[start:end, :, :]  # Shape: (seq_len_i, H_KV, D)
        v_i = v[start:end, :, :]  # Shape: (seq_len_i, H_KV, D)

        # Compute attention scores (logits) between the query and all keys
        logits_i = (
            torch.matmul(q[i].unsqueeze(0).permute(1, 0, 2), k_i.permute(1, 2, 0))
            * sm_scale
        )

        # Apply softmax to get attention weights
        attn_weights_i = torch.softmax(logits_i, dim=-1)  # Shape: (H_Q, 1, seq_len_i)

        # Remove the extra dim for log_softmax to match output shape expectation if needed,
        # but here we keep using logits_i
        # Compute the log of the softmax results for numerical stability
        attn_lse_i = torch.log_softmax(logits_i, dim=-1).squeeze(
            1
        )  # Shape: (H_Q, seq_len_i)

        # out computation
        attn_weights_i = attn_weights_i.squeeze(1)  # (H_Q, seq_len_i)
        out = torch.matmul(
            attn_weights_i, v_i.permute(1, 0, 2)
        )  # (H_Q, seq_len_i) * (H_Q, seq_len_i, D) -> error in dimensions for standard matmul?
        out = torch.matmul(attn_weights_i.unsqueeze(1), v_i.permute(1, 0, 2)).squeeze(1)

        # Append results to lists
        attn_logits.append(out.unsqueeze(0))  # Add batch dimension back
        attn_lse.append(attn_lse_i.unsqueeze(0))  # Add batch dimension back

    # Concatenate the results along the batch dimension
    attn_logits = torch.cat(attn_logits, dim=0)
    attn_lse = torch.cat(attn_lse, dim=0)

    return attn_logits, attn_lse


@pytest.mark.parametrize(
    "B, H_Q, H_KV, D, seq_len",
    [
        (2, 4, 4, 128, 1024),  # MHA Case 1
        (1, 16, 16, 128, 2048),  # MHA Case 2
    ],
)
def test_accuracy_decode_attention(B, H_Q, H_KV, D, seq_len):
    """
    test decode_attention
    """
    dtype = torch.bfloat16
    total_tokens = B * seq_len
    sm_scale = 1.0 / (D**0.5)
    max_kv_splits = 8
    num_kv_splits = torch.full((B,), 4, dtype=torch.int32, device=device)

    # 1. Prepare to input data
    # q represents the new token being generated, one per batch
    q = torch.randn(B, H_Q, D, dtype=dtype, device=device)

    # k_buffer and v_buffer represent all previous tokens
    k_buffer = torch.randn(total_tokens, H_KV, D, dtype=dtype, device=device)
    v_buffer = torch.randn(total_tokens, H_KV, D, dtype=dtype, device=device)

    # o will have the same shape as q
    o = torch.zeros(B, H_Q, D, dtype=dtype, device=device)

    b_seq_len = torch.full((B,), seq_len, device=device)

    kv_indptr = torch.zeros((B + 1,), dtype=torch.int32, device=device)
    kv_indptr[1 : B + 1] = torch.cumsum(b_seq_len[:B], dim=0).to(torch.int32)
    kv_indices = torch.arange(total_tokens, device=device).to(torch.int32)

    # Prepare to output buffer
    attn_logits_buf = torch.empty(
        (B, H_Q, max_kv_splits, D),
        dtype=torch.float32,
        device=device,
    )
    attn_lse_buf = torch.empty(
        (B, H_Q, max_kv_splits),
        dtype=torch.float32,
        device=device,
    )

    # 2. Execute operator
    decode_attention_fwd(
        q,
        k_buffer,
        v_buffer,
        o,
        kv_indptr,
        kv_indices,
        attn_logits_buf,
        attn_lse_buf,
        num_kv_splits,
        max_kv_splits,
        sm_scale,
    )

    # 3. Calculate  Golden
    attn_logits_gt, attn_lse_gt = scaled_dot_product_attention_golden(
        q, k_buffer, v_buffer, kv_indptr, sm_scale
    )

    # 4. Verification result
    max_diff = torch.max(torch.abs(o - attn_logits_gt))
    print(f"\n[Config: B={B}, HQ={H_Q}, HKV={H_KV}, D={D}, SEQ={seq_len}]")
    print(f"Attention out max diff: {max_diff}")

    atol = rtol = 2**-3
    torch.testing.assert_close(o, attn_logits_gt, atol=atol, rtol=atol)
