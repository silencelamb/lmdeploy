# Copyright © 2025 Huawei Technologies Co., Ltd.
# Copyright 2025 Xunhao Lai & Jianqiao Lu.
import math
from typing import Optional
import torch
import pytest

from triton_ascend_kernels.attention import topk_sparse_attention


def topk_sparse_attention_torch(
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    topk_idx: torch.Tensor,
    block_size_k: int,
    cu_seqlens: torch.Tensor,
    softmax_scale: Optional[float] = None,
    block_size_q: int = 1,
) -> torch.Tensor:
    """Simple topk sparse attention varlen version implemented in torch. Extremly slow, only for debugging.

    Args:
        q (torch.Tensor): shape [total_len, num_q_heads, head_dim]
        k (torch.Tensor): shape [total_len, num_kv_heads, head_dim]
        v (torch.Tensor): shape [total_len, num_kv_heads, head_dim]
        topk_idx (torch.Tensor): topk block idx for each query, shape [num_kv_heads, total_len, topk]. -1 means padding.
        block_size_q (int): query block size.
        block_size_k (int): key value block size.
        cu_seqlens (torch.Tensor): shape [batch_size + 1], similar to cu_seqlens in flash_attn_func_varlen.
        softmax_scale (Optional[float], optional): Defaults to None, means 1/sqrt(head_dim).

    Returns:
        torch.Tensor: attention output, shape [total_len, num_q_heads, head_dim]
    """
    total_seqlen, num_q_heads, head_dim = q.shape
    total_seqlen, num_kv_heads, head_dim = k.shape
    num_share_q_heads = num_q_heads // num_kv_heads
    batch_size = cu_seqlens.shape[0] - 1
    topk = topk_idx.shape[-1]
    seqlens = cu_seqlens[1:] - cu_seqlens[:-1]
    seqblocks_q = torch.ceil(seqlens / block_size_q).to(torch.int32)
    cu_seqblocks_q = torch.nn.functional.pad(seqblocks_q.cumsum(0), (1, 0), value=0)
    if softmax_scale is None:
        softmax_scale = 1.0 / math.sqrt(head_dim)
    # get mask
    mask = torch.zeros(
        (num_kv_heads, total_seqlen, total_seqlen), dtype=torch.bool, device=q.device
    )
    for i in range(batch_size):
        num_q_blocks = math.ceil(seqlens[i] / block_size_q)
        num_kv_blocks = math.ceil(seqlens[i] / block_size_k)
        for h in range(num_kv_heads):
            temp_mask = torch.zeros(
                num_q_blocks, num_kv_blocks, dtype=torch.bool, device=q.device
            )
            temp_idx = topk_idx[h, cu_seqblocks_q[i] : cu_seqblocks_q[i + 1]].clone()
            temp_idx[temp_idx < 0] = 0
            temp_mask[torch.arange(num_q_blocks).to(q.device)[:, None], temp_idx] = True
            temp_mask = torch.repeat_interleave(temp_mask, block_size_q, dim=0)
            temp_mask = torch.repeat_interleave(temp_mask, block_size_k, dim=1)
            temp_mask = temp_mask[: seqlens[i], : seqlens[i]]
            mask[
                h, cu_seqlens[i] : cu_seqlens[i + 1], cu_seqlens[i] : cu_seqlens[i + 1]
            ] = temp_mask
    mask = torch.tril(mask).repeat_interleave(num_share_q_heads, 0)
    # qk attn
    qk = (
        torch.einsum("qhd,khd->hqk", q, k.repeat_interleave(num_share_q_heads, 1))
        * softmax_scale
    )
    qk = torch.masked_fill(qk, ~mask, -torch.inf)
    qk = torch.softmax(qk, dim=-1, dtype=torch.float32).to(q.dtype)
    o = torch.einsum("hqk,khd->qhd", qk, v.repeat_interleave(num_share_q_heads, 1))
    return o


def generate_topk_idx_example(
    seqlens: torch.Tensor,
    block_size_k: int,
    topk: int,
    num_heads: int,
    block_size_q: int = 1,
) -> torch.Tensor:
    """Generate topk idx example for test.

    Args:
        seqlens (torch.Tensor): shape [batch_size + 1], similar to cu_seqlens in flash_attn_func_varlen.
        block_size_q (int): query block size
        block_size_k (int): key value block size
        topk (int): selected topk
        num_heads (int): number of key value heads

    Returns:
        torch.Tensor: shape [num_heads, total_seqlen, topk], topk key value block idx for each query. -1 means padding.
    """
    batch_size = seqlens.shape[0]
    num_blocks = torch.ceil(seqlens / block_size_k).to(torch.int32)
    topk_idx_all_heads = []
    cu_seqlens = torch.nn.functional.pad(seqlens.cumsum(0), pad=(1, 0), value=0)
    for _ in range(num_heads):
        topk_idx = [
            torch.randn(seqlens[i], num_blocks[i], device="npu")
            .topk(min(topk, num_blocks[i]), dim=-1)
            .indices.to(torch.int32)
            for i in range(batch_size)
        ]
        topk_idx = [
            torch.nn.functional.pad(
                topk_idx[i], (0, topk - topk_idx[i].shape[-1]), value=topk
            )
            for i in range(batch_size)
        ]
        topk_idx = torch.cat(topk_idx, dim=0)
        topk_idx = torch.sort(topk_idx, dim=1).values
        topk_idx[:, 0] = 0
        q_idx = torch.cat(
            [torch.arange(seqlens[i], device="npu") for i in range(batch_size)], dim=0
        )
        topk_idx[topk_idx > (q_idx // block_size_k)[:, None]] = -1  # -1 means padding
        topk_idx = torch.cat(
            [
                topk_idx[cu_seqlens[i] : cu_seqlens[i + 1]][0::block_size_q]
                for i in range(batch_size)
            ],
            dim=0,
        )
        topk_idx_all_heads.append(topk_idx)
    topk_idx = torch.stack(topk_idx_all_heads, dim=0)
    return topk_idx


@pytest.mark.parametrize("seqlens", [[100, 200, 256]])
@pytest.mark.parametrize("num_heads", [[8, 1]])
@pytest.mark.parametrize("head_dim", [16])
@pytest.mark.parametrize("block_size", [64])
@pytest.mark.parametrize("topk", [5])
def test_accuracy_nsa_topk_sparse_attention(
    seqlens, num_heads, head_dim, block_size, topk
):
    torch.manual_seed(42)
    seqlens = torch.LongTensor(seqlens).int().npu()
    cu_seqlens = torch.cat(
        [
            torch.zeros(1, dtype=torch.int32, device="npu"),
            torch.cumsum(seqlens, dim=0),
        ],
        dim=0,
    ).to(torch.int32)
    num_heads_q, num_heads_k = num_heads
    q = (
        torch.empty(cu_seqlens[-1], num_heads_q, head_dim, device="npu")
        .uniform_(-1, 1)
        .to(torch.float16)
    )
    k = (
        torch.empty(cu_seqlens[-1], num_heads_k, head_dim, device="npu")
        .uniform_(-1, 1)
        .to(torch.float16)
    )
    v = (
        torch.empty(cu_seqlens[-1], num_heads_k, head_dim, device="npu")
        .uniform_(-1, 1)
        .to(torch.float16)
    )
    q.requires_grad = True
    k.requires_grad = True
    v.requires_grad = True

    topk_idx = generate_topk_idx_example(seqlens, block_size, topk, num_heads_k)

    # torch
    o = topk_sparse_attention_torch(q, k, v, topk_idx, block_size, cu_seqlens)

    randn = torch.randn_like(o)
    loss = (o * randn).sum()
    loss.backward()

    q1 = q.clone().detach().requires_grad_()
    k1 = k.clone().detach().requires_grad_()
    v1 = v.clone().detach().requires_grad_()
    topk_idx1 = topk_idx.clone().detach()
    cu_seqlens1 = cu_seqlens.clone().detach()

    # triton
    o1 = topk_sparse_attention(q1, k1, v1, topk_idx1, block_size, cu_seqlens1)

    randn2 = randn.clone().detach()
    loss2 = (o1 * randn2).sum()
    loss2.backward()

    torch.testing.assert_close(o, o1, atol=0.01, rtol=0.01)
    torch.testing.assert_close(q.grad, q1.grad, atol=0.01, rtol=0.01)
    torch.testing.assert_close(k.grad, k1.grad, atol=0.01, rtol=0.01)
    torch.testing.assert_close(v.grad, v1.grad, atol=0.01, rtol=0.01)
