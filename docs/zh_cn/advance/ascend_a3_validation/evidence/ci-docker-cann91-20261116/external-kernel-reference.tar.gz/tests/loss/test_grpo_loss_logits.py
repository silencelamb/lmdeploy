# Copyright © 2025 Huawei Technologies Co., Ltd.
# Copyright (c) 2025, DeepLink.
import torch
import pytest
from triton_ascend_kernels.loss import GRPO_Loss_Optimized, grpo_compute_loss_torch

GRPO_SHAPES_BSV = [(2, 64, 2048)]  # (B, S, V)
GRPO_DTYPES = [torch.float32]
GRPO_CONFIG = {
    "seed": 42,
    "kwargs": {
        "beta": 0.1,
        "loss_type": "grpo",
        "epsilon_low": 0.2,
        "epsilon_high": 0.2,
        "max_completion_length": 8192,
        "delta": 2.7,
        "temperature": 0.7,
    },
    "atol": 1e-5,
    "rtol": 1e-4,
}


def generate_inputs(B, S, V, dtype, device, requires_grad=False):
    BL = B * S
    torch.manual_seed(GRPO_CONFIG["seed"])

    new_logits_3d = torch.randn((B, S, V), device="npu", dtype=dtype)
    ref_logits_3d = torch.randn((B, S, V), device="npu", dtype=dtype)
    old_logits_3d = torch.randn((B, S, V), device="npu", dtype=dtype)

    new_logits_2d = new_logits_3d.view(BL, V).clone()
    ref_logits_2d = ref_logits_3d.view(BL, V).clone()
    old_logits_2d = old_logits_3d.view(BL, V).clone()

    if requires_grad:
        new_logits_3d.requires_grad_(True)
        new_logits_2d.requires_grad_(True)

    input_ids_3d = torch.randint(0, V, (B, S), device="npu")
    mask_3d = torch.ones((B, S), device="npu", dtype=torch.long)
    mask_3d[0, -5:] = 0
    input_ids_2d = input_ids_3d.view(BL)
    mask_2d = mask_3d.view(BL)
    advantages_3d = torch.randn((B,), device="npu", dtype=dtype)
    advantages_2d = advantages_3d.unsqueeze(1).expand(-1, S).reshape(BL)

    return (
        new_logits_3d,
        ref_logits_3d,
        old_logits_3d,
        input_ids_3d,
        advantages_3d,
        mask_3d,
    ), (
        new_logits_2d,
        ref_logits_2d,
        old_logits_2d,
        input_ids_2d,
        advantages_2d,
        mask_2d,
    )


@pytest.mark.grpo_loss
@pytest.mark.parametrize("B, S, V", GRPO_SHAPES_BSV)
@pytest.mark.parametrize("dtype", GRPO_DTYPES)
def test_accuracy_grpo_loss(B, S, V, dtype):
    BL = B * S
    kwargs = GRPO_CONFIG["kwargs"]
    atol = GRPO_CONFIG["atol"]
    rtol = GRPO_CONFIG["rtol"]

    (
        new_logits_ref_3d,
        ref_logits_ref_3d,
        old_logits_ref_3d,
        ids_ref_3d,
        adv_ref_3d,
        mask_ref_3d,
    ), _ = generate_inputs(B, S, V, dtype, device="npu", requires_grad=True)
    adv_ref_torch = adv_ref_3d.unsqueeze(1).expand(-1, S)

    loss_ref, _, _, _, _ = grpo_compute_loss_torch(
        new_logits=new_logits_ref_3d,
        ref_logits=ref_logits_ref_3d,
        old_logits=old_logits_ref_3d,
        input_ids=ids_ref_3d,
        advantages=adv_ref_torch,
        mask=mask_ref_3d,
        **kwargs
    )
    loss_ref_sum = loss_ref.sum()
    loss_ref_sum.backward()
    grad_ref = new_logits_ref_3d.grad.clone().view(BL, V)

    _, (
        new_logits_triton,
        ref_logits_triton,
        old_logits_triton,
        ids_triton,
        adv_triton,
        mask_triton,
    ) = generate_inputs(B, S, V, dtype, device="npu", requires_grad=True)

    loss_triton = GRPO_Loss_Optimized.apply(
        new_logits_triton,
        ref_logits_triton,
        old_logits_triton,
        ids_triton,
        adv_triton,
        mask_triton,
        kwargs["beta"],
        kwargs["loss_type"],
        kwargs["epsilon_low"],
        kwargs["epsilon_high"],
        kwargs["max_completion_length"],
        kwargs["delta"],
        kwargs["temperature"],
    )
    loss_triton_sum = loss_triton.sum()
    loss_triton_sum.backward()
    grad_triton = new_logits_triton.grad.clone()

    torch.testing.assert_close(loss_ref_sum, loss_triton_sum, atol=atol, rtol=rtol)
    torch.testing.assert_close(grad_triton, grad_ref, atol=atol, rtol=rtol)
