import torch
import pytest

from triton_ascend_kernels.gemm import matmul


MATMUL_SHAPES_MKN = [(2048, 7168, 16384)]


@pytest.mark.matmul
@pytest.mark.parametrize("M, K, N", MATMUL_SHAPES_MKN)
@pytest.mark.parametrize("dtype", [torch.bfloat16])
def test_accuracy_matmul(M, K, N, dtype):
    mat_a = torch.randn([M, K], dtype=dtype, device="npu")
    mat_b = torch.randn([K, N], dtype=dtype, device="npu")

    result = matmul(mat_a, mat_b)
    golden = torch.matmul(mat_a, mat_b)

    mask = golden.abs() < 1.0
    atol = rtol = 2**-6

    torch.testing.assert_close(result[mask], golden[mask], atol=atol, rtol=0)
    torch.testing.assert_close(result[~mask], golden[~mask], atol=0, rtol=rtol)
