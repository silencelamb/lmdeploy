import torch
import torch_npu
import pytest
import triton
import triton.language as tl
from benchmark.utils import Benchmark, OpType
from triton_ascend_kernels.gemm.awq_triton import AWQ_TRITON_SUPPORTED_GROUP_SIZES
from triton_ascend_kernels.gemm.awq_triton import awq_dequantize_triton
from triton_ascend_kernels.gemm.awq_triton import awq_gemm_triton
from triton_ascend_kernels.gemm import matmul

device = "npu"


def torch_dequantized_mm(
    input_data,
    qweight,
    scales,
    qzeros,
):
    dequantized_weights = awq_dequantize_triton(qweight, scales, qzeros)
    output_torch = torch.matmul(input_data, dequantized_weights)
    return output_torch


@pytest.mark.parametrize("N", [4, 8, 14, 17, 23, 32])
@pytest.mark.parametrize("K", [128])
@pytest.mark.parametrize("M", [24, 32])
@pytest.mark.parametrize("group_size", AWQ_TRITON_SUPPORTED_GROUP_SIZES)
@pytest.mark.parametrize("splitK", [1])
@pytest.mark.xdist_group("benchmark")
def test_benchmark_awq_gemm_triton(
    M,
    K,
    N,
    group_size,
    splitK,
):
    if group_size == -1:
        group_size = K

    split_k_iters = splitK

    input_rows = N
    input_cols = K
    input_dtype = torch.float32
    qweight_rows = input_cols
    qweight_cols = M // 8
    scales_rows = qweight_rows // group_size
    scales_cols = M
    scales_dtype = torch.float32
    qzeros_rows = scales_rows
    qzeros_cols = qweight_cols

    torch.manual_seed(0)

    input_data = torch.rand((input_rows, input_cols), dtype=input_dtype, device=device)
    qweight = torch.randint(
        0, torch.iinfo(torch.int32).max, (qweight_rows, qweight_cols), device=device
    )
    qzeros = torch.randint(
        0, torch.iinfo(torch.int32).max, (qzeros_rows, qzeros_cols), device=device
    )
    scales = torch.rand((scales_rows, scales_cols), dtype=scales_dtype, device=device)

    def torch_op():
        return torch_dequantized_mm(
            input_data=input_data,
            qweight=qweight,
            scales=scales,
            qzeros=qzeros,
        )

    def triton_op():
        return awq_gemm_triton(
            input_data=input_data,
            qweight=qweight,
            scales=scales,
            qzeros=qzeros,
            split_k_iters=split_k_iters,
        )

    benchmark = Benchmark(
        triton_op=triton_op,
        torch_op=torch_op,
        op_type=OpType.CV,
    )
    benchmark.run()
