# Copyright © 2025 Huawei Technologies Co., Ltd.
# Copyright contributors to the vLLM project
import torch
import pytest

from triton_ascend_kernels.index import triton_convert_req_index_to_global_index
from benchmark.utils import Benchmark, OpType


def _triton_convert_reference_impl(
    req_ids: torch.Tensor,
    block_table: torch.Tensor,
    token_indices: torch.Tensor,
    block_size: int,
    num_topk_tokens: int,
    HAS_PREFILL_WORKSPACE: bool = False,
    prefill_workspace_request_ids: torch.Tensor | None = None,
    prefill_workspace_starts: torch.Tensor | None = None,
) -> torch.Tensor:
    """Reference implementation for triton_convert_req_index_to_global_index (vectorized)."""
    max_blocks_per_req = block_table.shape[1]

    # Compute block_id and offset for all tokens at once
    block_id = token_indices // block_size  # [num_tokens, num_topk_tokens]
    offset = token_indices % block_size  # [num_tokens, num_topk_tokens]

    # Clamp block_id to valid range for indexing (invalid ones will be masked later)
    block_id_clamped = block_id.clamp(0, max_blocks_per_req - 1)

    # Expand req_ids for advanced indexing: [num_tokens] -> [num_tokens, num_topk_tokens]
    req_ids_expanded = req_ids.unsqueeze(1).expand(-1, num_topk_tokens)

    # Get block numbers from block_table using advanced indexing
    block_num = block_table[req_ids_expanded, block_id_clamped]

    # Compute result for decode case: block_num * block_size + offset
    result = block_num * block_size + offset

    # Handle out of bounds: block_id >= max_blocks_per_req -> -1
    out_of_bounds_mask = block_id >= max_blocks_per_req
    result = result.masked_fill(out_of_bounds_mask, -1)

    # Handle prefill workspace if present
    if HAS_PREFILL_WORKSPACE and prefill_workspace_request_ids is not None:
        assert prefill_workspace_starts is not None

        # Which tokens use workspace (prefill_workspace_request_ids >= 0)
        use_workspace_mask = prefill_workspace_request_ids >= 0  # [num_tokens]

        # Get workspace starts for each token (clamp to valid range for indexing)
        workspace_req_ids_clamped = prefill_workspace_request_ids.clamp(min=0)
        workspace_starts = prefill_workspace_starts[
            workspace_req_ids_clamped
        ]  # [num_tokens]

        # Compute workspace result: workspace_start + token_idx
        workspace_result = workspace_starts.unsqueeze(1) + token_indices

        # Overwrite decode result with workspace result for workspace tokens
        use_workspace_mask_expanded = use_workspace_mask.unsqueeze(1).expand(
            -1, num_topk_tokens
        )
        result = torch.where(use_workspace_mask_expanded, workspace_result, result)

    # Handle invalid token indices (-1) - applies to all cases
    invalid_mask = token_indices == -1
    result = result.masked_fill(invalid_mask, -1)

    return result.to(torch.int32)


@pytest.mark.parametrize("block_size", [8, 128])
@pytest.mark.parametrize("num_topk_tokens", [128])
@pytest.mark.xdist_group("benchmark")
def test_benchmark_triton_convert_req_index_to_global_index_decode_only(
    block_size, num_topk_tokens
):
    device = "npu"
    num_tokens = 8
    num_requests = 4
    max_blocks_per_req = 10

    req_id = torch.randint(
        0, num_requests, (num_tokens,), dtype=torch.int32, device=device
    )
    block_table = torch.randint(
        0, 100, (num_requests, max_blocks_per_req), dtype=torch.int32, device=device
    )

    token_indices = torch.randint(
        0,
        block_size * max_blocks_per_req,
        (num_tokens, num_topk_tokens),
        dtype=torch.int32,
        device=device,
    )

    # Set some to -1 to test masking
    token_indices[0, :10] = -1
    token_indices[3, 50:60] = -1

    # Set some to out of bounds
    token_indices[2, 100:110] = max_blocks_per_req * block_size
    token_indices[6, 150:160] = max_blocks_per_req * block_size

    def triton_op():
        _ = triton_convert_req_index_to_global_index(
            req_id,
            block_table,
            token_indices,
            BLOCK_SIZE=block_size,
            NUM_TOPK_TOKENS=num_topk_tokens,
        )

    def torch_op():
        _ = _triton_convert_reference_impl(
            req_id,
            block_table,
            token_indices,
            block_size,
            num_topk_tokens,
        )

    benchmark = Benchmark(
        triton_op=triton_op,
        torch_op=torch_op,
        op_type=OpType.PURE_VECTOR,
    )
    benchmark.run()


@pytest.mark.parametrize("block_size", [16])
@pytest.mark.xdist_group("benchmark")
def test_benchmark_triton_convert_req_index_to_global_index_with_prefill_workspace(
    block_size,
):
    device = "npu"
    num_requests = 4
    max_blocks_per_req = 8
    num_topk_tokens = 128

    # First 6 tokens are decode (reqs 0, 1), last 6 are prefill (reqs 2, 3)
    req_id = torch.tensor(
        [0, 0, 0, 1, 1, 1, 2, 2, 2, 3, 3, 3], dtype=torch.int32, device=device
    )
    prefill_workspace_request_ids = torch.tensor(
        [-1, -1, -1, -1, -1, -1, 0, 0, 0, 1, 1, 1], dtype=torch.int32, device=device
    )

    # Workspace starts for the 2 prefill reqs: req 2 starts at 0, req 3 starts at 100
    prefill_workspace_starts = torch.tensor([0, 100], dtype=torch.int32, device=device)

    block_table = torch.randint(
        0, 50, (num_requests, max_blocks_per_req), dtype=torch.int32, device=device
    )
    token_indices = torch.randint(
        0,
        block_size * max_blocks_per_req,
        (req_id.shape[0], num_topk_tokens),
        dtype=torch.int32,
        device=device,
    )

    # Set some to -1 to test masking
    token_indices[0, :10] = -1
    token_indices[3, 50:60] = -1

    # Set some to out of bounds
    token_indices[2, 100:110] = max_blocks_per_req * block_size
    token_indices[6, 150:160] = max_blocks_per_req * block_size

    def triton_op():
        _ = triton_convert_req_index_to_global_index(
            req_id,
            block_table,
            token_indices,
            BLOCK_SIZE=block_size,
            NUM_TOPK_TOKENS=num_topk_tokens,
            HAS_PREFILL_WORKSPACE=True,
            prefill_workspace_request_ids=prefill_workspace_request_ids,
            prefill_workspace_starts=prefill_workspace_starts,
        )

    def torch_op():
        _ = _triton_convert_reference_impl(
            req_id,
            block_table,
            token_indices,
            block_size,
            num_topk_tokens,
            HAS_PREFILL_WORKSPACE=True,
            prefill_workspace_request_ids=prefill_workspace_request_ids,
            prefill_workspace_starts=prefill_workspace_starts,
        )

    benchmark = Benchmark(
        triton_op=triton_op,
        torch_op=torch_op,
        op_type=OpType.PURE_VECTOR,
    )
    benchmark.run()
