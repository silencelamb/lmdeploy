# Copyright © 2025 Huawei Technologies Co., Ltd.
# Copyright contributors to the vLLM project
import torch
import pytest
import torch.nn.functional as F

from triton_ascend_kernels.moe import fused_gdn_gating
from benchmark.utils import Benchmark, OpType


def _fused_gdn_gating_reference_impl(
    A_log: torch.Tensor,
    a: torch.Tensor,
    b: torch.Tensor,
    dt_bias: torch.Tensor,
    beta: float = 1.0,
    threshold: float = 20.0,
) -> torch.Tensor:
    g = -A_log.float().exp() * F.softplus(a.float() + dt_bias)
    beta_output = b.sigmoid()
    return g, beta_output


@pytest.mark.parametrize("tp_size", [1])
@pytest.mark.parametrize("num_v_heads", [8, 128])
@pytest.mark.parametrize("batch", [1, 4096])
@pytest.mark.xdist_group("benchmark")
def test_benchmark_fused_gdn_gating(batch, num_v_heads, tp_size):
    device = "npu"
    A_log = torch.randn(num_v_heads // tp_size, dtype=torch.float32, device=device)
    a = torch.randn((batch, num_v_heads // tp_size), dtype=torch.float32, device=device)
    b = torch.randn((batch, num_v_heads // tp_size), dtype=torch.float32, device=device)
    dt_bias = torch.ones((num_v_heads // tp_size), dtype=torch.float32, device=device)

    def triton_op():
        _, _ = fused_gdn_gating(
            A_log,
            a,
            b,
            dt_bias,
        )

    def torch_op():
        _, _ = _fused_gdn_gating_reference_impl(
            A_log,
            a,
            b,
            dt_bias,
        )

    benchmark = Benchmark(
        triton_op=triton_op,
        torch_op=torch_op,
        op_type=OpType.PURE_VECTOR,
    )
    benchmark.run()
