import torch
import pytest

from triton_ascend_kernels.gemm import matmul
from benchmark.utils import Benchmark, OpType


MATMUL_SHAPES_MKN = [(2048, 7168, 16384)]


@pytest.mark.parametrize("M, K, N", MATMUL_SHAPES_MKN)
@pytest.mark.parametrize("dtype", [torch.bfloat16])
@pytest.mark.xdist_group("benchmark")
def test_benchmark_matmul(
    M,
    K,
    N,
    dtype,
):
    mat_a = torch.randn([M, K], dtype=dtype, device="npu")
    mat_b = torch.randn([K, N], dtype=dtype, device="npu")

    benchmark = Benchmark(
        triton_op=lambda: matmul(mat_a, mat_b),
        torch_op=lambda: torch.matmul(mat_a, mat_b),
        op_type=OpType.PURE_CUBE,
    )
    benchmark.run()
