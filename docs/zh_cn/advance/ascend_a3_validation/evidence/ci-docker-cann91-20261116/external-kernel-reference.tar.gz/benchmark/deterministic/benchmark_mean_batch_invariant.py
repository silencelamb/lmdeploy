# Copyright © 2025 Huawei Technologies Co., Ltd.

import torch
import pytest
from triton_ascend_kernels.deterministic import mean_batch_invariant
from benchmark.utils import Benchmark, OpType


def deterministic_sum(x, dim):
    x_permuted = x.transpose(dim, 0)
    result = torch.zeros_like(x_permuted[0])

    for i in range(x_permuted.shape[0]):
        result += x_permuted[i]

    return result


def deterministic_mean(x, dim):
    sum_val = deterministic_sum(x, dim)
    count = x.size(dim)
    mean_val = sum_val / count
    return mean_val


@pytest.mark.xdist_group("benchmark")
@pytest.mark.parametrize("batch_size", [128])
@pytest.mark.parametrize("hidden_size", [32])
def test_benchmark_mean_batch_invariant(
    batch_size: int,
    hidden_size: int,
):

    torch.manual_seed(42)
    x = torch.randn(batch_size, hidden_size, dtype=torch.float32).npu()
    dim = torch.Tensor([1]).npu().to(torch.int64)

    def torch_op():
        _ = deterministic_mean(x, 1)

    def triton_op():
        _ = mean_batch_invariant(x, dim, keepdim=False, dtype=torch.float32)

    benchmark = Benchmark(
        triton_op=triton_op,
        torch_op=torch_op,
        op_type=OpType.PURE_VECTOR,
    )
    benchmark.run()
