# Copyright © 2026 Huawei Technologies Co., Ltd.

import random
import torch
import pytest

from benchmark.utils import Benchmark, OpType


def pytorch_dsa_prefill(
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    topk_indices: torch.Tensor,
    query_rope: torch.Tensor,
    key_rope: torch.Tensor,
    scale,
) -> torch.Tensor:
    bsz, seqlen_q, n_heads, kv_lora_rank = query.shape
    _, seqlen_k, _, qk_rope_head_dim = key_rope.shape
    q = torch.cat([query, query_rope], -1)
    k = torch.cat([key, key_rope], -1)
    v = key.clone()
    scores = (
        torch.einsum(
            "bshc,btc->bsht", q.to(torch.float32), k.to(torch.float32).squeeze(2)
        )
        * scale
    )
    index_mask = (
        torch.full((bsz, seqlen_q, seqlen_k), float("-inf"), device=query.device)
        .scatter_(-1, topk_indices.to(torch.int64).squeeze(2), 0)
        .unsqueeze(2)
    )
    scores += index_mask
    scores = scores.softmax(dim=-1).to(q.dtype)
    o = torch.einsum("bsht,btc->bshc", scores, v.to(q.dtype).squeeze(2)).to(q.dtype)
    return o


@pytest.mark.skipif(True, reason="Due to triton-ascend version, DSA test is skipped")
@pytest.mark.parametrize(
    "batch, q_seq_len, k_seq_len, head_num, kv_lora_rank, qk_rope_head_dim, dtype",
    [
        (
            batch,
            q_seq_len,
            2048,
            16,
            512,
            64,
            dtype,
        )
        for batch, q_seq_len in [
            [2, 4096],
            [16, 4096],
            [32, 1024],
            [128, 1024],
        ]
        for dtype in [torch.bfloat16, torch.float16]
    ],
)
def test_dsa_prefill(
    batch, q_seq_len, k_seq_len, head_num, kv_lora_rank, qk_rope_head_dim, dtype
):
    device = "npu"
    sparse_block_count = 1024
    scale_value = 0.041666666666666664
    query = torch.randn(
        batch,
        q_seq_len,
        head_num,
        kv_lora_rank,
        device=device,
        dtype=dtype,
    )
    query_rope = torch.randn(
        batch,
        q_seq_len,
        head_num,
        qk_rope_head_dim,
        device=device,
        dtype=dtype,
    )
    key = torch.randn(
        batch,
        k_seq_len,
        1,
        kv_lora_rank,
        device=device,
        dtype=dtype,
    )
    key_rope = torch.randn(
        batch,
        k_seq_len,
        1,
        qk_rope_head_dim,
        device=device,
        dtype=dtype,
    )
    value = key
    idxs = random.sample(range(k_seq_len), sparse_block_count)
    topk_indices = (
        torch.tensor([idxs for _ in range(batch * q_seq_len * 1)], device=device)
        .reshape(batch, q_seq_len, 1, sparse_block_count)
        .to(torch.int32)
    )

    def triton_op():
        triton_out = dsa_prefill_forward(
            query, key, value, topk_indices, query_rope, key_rope, scale_value
        )

    def torch_op():
        pytorch_out = pytorch_dsa_prefill(
            query, key, value, topk_indices, query_rope, key_rope, scale_value
        )

    benchmark = Benchmark(
        triton_op=triton_op,
        torch_op=torch_op,
        op_type=OpType.CV,
    )
    benchmark.run()
