# Copyright © 2025 Huawei Technologies Co., Ltd.
# Copyright (c) 2025, DeepLink.
import torch
import pytest
from triton_ascend_kernels.norm import rms_norm_batch_invariant
from benchmark.utils import Benchmark, OpType


def torch_rms_norm_batch_invariant(
    input_x: torch.Tensor, weight: torch.Tensor, eps: float = 1e-6
):
    original_shape = input_x.shape
    original_dtype = input_x.dtype

    input_2d = input_x.reshape(-1, input_x.shape[-1])
    n_rows, n_cols = input_2d.shape

    output_2d = torch.empty_like(input_2d)

    if original_dtype in [torch.float16, torch.bfloat16]:
        input_2d = input_2d.to(torch.float32)
        weight = weight.to(torch.float32)
        output_2d = output_2d.to(torch.float32)

    for i in range(n_rows):
        row = input_2d[i]
        sum_sq = torch.sum(row.pow(2))
        mean_sq = sum_sq / n_cols
        rms = torch.sqrt(mean_sq + eps)
        inv_rms = 1.0 / rms
        normalized_row = row * inv_rms
        weighted_row = normalized_row * weight
        output_2d[i] = weighted_row

    output_2d = output_2d.to(original_dtype)
    output = output_2d.reshape(original_shape)

    return output


def triton_rms_norm_batch_invariant(
    input_x: torch.Tensor, weight: torch.Tensor, eps: float = 1e-6
):

    return rms_norm_batch_invariant(
        input_x,
        weight,
        eps,
    )


@pytest.mark.xdist_group("benchmark")
@pytest.mark.parametrize("batch_size", [128])
@pytest.mark.parametrize("seq_len", [8])
@pytest.mark.parametrize("hidden_size", [32])
@pytest.mark.parametrize("dtype", [torch.float16])
def test_benchmark_rms_norm_batch_invariant(
    batch_size: int, seq_len: int, hidden_size: int, dtype
):

    torch.manual_seed(42)
    x = torch.randn(batch_size, seq_len, hidden_size, device="npu", dtype=dtype)
    weight = torch.randn(hidden_size, device="npu", dtype=dtype)

    def torch_op():
        _ = torch_rms_norm_batch_invariant(x, weight)

    def triton_op():
        _ = triton_rms_norm_batch_invariant(x, weight)

    benchmark = Benchmark(
        triton_op=triton_op,
        torch_op=torch_op,
        op_type=OpType.OTHER,
    )
    benchmark.run()
