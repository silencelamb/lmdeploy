# Copyright © 2025 Huawei Technologies Co., Ltd.
# Copyright contributors to the vLLM project
# Copyright (c) 2023-2025, Songlin Yang, Yu Zhang
import pytest
import torch
import torch.nn.functional as F

from triton_ascend_kernels.norm import l2norm_fwd
from benchmark.utils import Benchmark, OpType


@pytest.mark.parametrize(
    ("B", "T", "H", "D", "dtype"),
    [
        pytest.param(*test, id="B{}-T{}-H{}-D{}-{}".format(*test))
        for test in [
            (1, 63, 1, 60, torch.float),
            (2, 500, 4, 64, torch.float),
            (2, 1000, 2, 100, torch.float),
            (3, 1024, 4, 128, torch.float),
            (4, 1024, 5, 1024, torch.float16),
            (4, 1024, 5, 1024, torch.bfloat16),
            (5, 1024, 6, 2048, torch.float16),
            (5, 1024, 6, 2048, torch.bfloat16),
        ]
    ],
)
@pytest.mark.xdist_group("benchmark")
def test_benchmark_l2norm(B: int, T: int, H: int, D: int, dtype: torch.dtype):
    torch.manual_seed(42)
    device = torch.device("npu")
    x = torch.randn(B, T, H, D, dtype=dtype).to(device)
    x = x * 0.5 + 0.3

    benchmark = Benchmark(
        triton_op=lambda: l2norm_fwd(x),
        torch_op=lambda: F.normalize(x, dim=-1, p=2),
        op_type=OpType.PURE_VECTOR,
    )
    benchmark.run()
