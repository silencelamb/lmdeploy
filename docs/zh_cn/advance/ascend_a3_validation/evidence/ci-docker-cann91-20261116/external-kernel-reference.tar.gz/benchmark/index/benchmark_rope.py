# Copyright © 2025 Huawei Technologies Co., Ltd.
# Copyright 2024 LinkedIn Corporation
import os
import pytest
import torch

from transformers.models.llama.configuration_llama import LlamaConfig
from transformers.models.llama.modeling_llama import LlamaRotaryEmbedding
from transformers.models.llama.modeling_llama import apply_rotary_pos_emb

from triton_ascend_kernels.index import triton_rotary_pos_emb
from tests.index.test_rope import transformers_version_dispatch
from benchmark.utils import Benchmark, OpType

device = "npu"

SLEEP_SECONDS = 0.1


@pytest.mark.xdist_group("benchmark")
@pytest.mark.parametrize(
    "bsz, seq_len, num_q_heads, num_kv_heads, head_dim",
    [
        (1, 16, 4, 4, 8),
        (1, 128, 32, 32, 64),
        (2, 128, 32, 32, 64),
        # different q/k heads
        (1, 128, 32, 8, 64),
        (2, 128, 32, 8, 64),
    ],
)
@pytest.mark.parametrize(
    "dtype",
    [
        (torch.float32),
        (torch.bfloat16),
    ],
)
@pytest.mark.parametrize(
    "expand_position_ids",
    [True, False],
)
def test_benchmark_rope(
    bsz,
    seq_len,
    num_q_heads,
    num_kv_heads,
    head_dim,
    dtype,
    expand_position_ids,
):
    rotary_emb = transformers_version_dispatch(
        "4.48.0",
        LlamaRotaryEmbedding,
        LlamaRotaryEmbedding,
        before_kwargs={"dim": head_dim, "device": device},
        after_kwargs={
            "config": LlamaConfig(num_kv_heads=num_kv_heads, head_dim=head_dim),
            "device": device,
        },
    )

    _tensor_q = (
        torch.randn((bsz, seq_len, num_q_heads, head_dim), device=device)
        .transpose(1, 2)
        .to(dtype)
    )

    _tensor_k = (
        torch.randn((bsz, seq_len, num_kv_heads, head_dim), device=device)
        .transpose(1, 2)
        .to(dtype)
    )

    q1 = _tensor_q.clone().requires_grad_(True)
    k1 = _tensor_k.clone().requires_grad_(True)

    q2 = _tensor_q.clone().requires_grad_(True)
    k2 = _tensor_k.clone().requires_grad_(True)

    pos_ids = torch.arange(seq_len, device=device, dtype=torch.long).unsqueeze(0)
    if expand_position_ids:
        pos_ids = pos_ids.expand(bsz, -1)
    cos, sin = rotary_emb(k1, pos_ids)

    hf_q, hf_k = apply_rotary_pos_emb(q1, k1, cos, sin, pos_ids)
    dq, dk = (
        torch.randn_like(hf_q, device=device),
        torch.randn_like(hf_k, device=device).to(dtype),
    )

    def torch_fn():
        # validate forward pass
        hf_q, hf_k = apply_rotary_pos_emb(q1, k1, cos, sin, pos_ids)
        # validate backward pass
        q1_grad, k1_grad = torch.autograd.grad(
            (hf_q, hf_k), (q1, k1), (dq.clone(), dk.clone()), allow_unused=True
        )

    def triton_fn():
        # validate forward pass
        tt_q, tt_k = triton_rotary_pos_emb(q2, k2, cos, sin)

        # validate backward pass
        q2_grad, k2_grad = torch.autograd.grad(
            (tt_q, tt_k), (q2, k2), (dq.clone(), dk.clone()), allow_unused=True
        )

    benchmark = Benchmark(
        triton_op=lambda: triton_fn(),
        torch_op=lambda: torch_fn(),
        op_type=OpType.OTHER,
    )
    benchmark.run()
