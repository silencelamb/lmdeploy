# Copyright © 2026 Huawei Technologies Co., Ltd.

import random
import torch
import pytest

from benchmark.utils import Benchmark, OpType


def pytorch_dsa_decode(
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    wkv_b: torch.Tensor,
    topk_indices: torch.Tensor,
    query_rope: torch.Tensor,
    key_rope: torch.Tensor,
    scale,
) -> torch.Tensor:
    bsz, seqlen_q, n_heads, qk_nope_head_dim = query.shape
    _, seqlen_k, _, qk_rope_head_dim = key_rope.shape
    v_head_dim = wkv_b.shape[1] - qk_nope_head_dim
    q_nope = torch.einsum(
        "bshd,hdc->bshc",
        query.to(torch.float32),
        wkv_b[:, :qk_nope_head_dim].to(torch.float32),
    ).to(query.dtype)
    q = torch.cat([q_nope, query_rope], -1)
    k = torch.cat([key, key_rope], -1)
    v = key.clone()
    scores = (
        torch.einsum(
            "bshc,btc->bsht", q.to(torch.float32), k.to(torch.float32).squeeze(2)
        )
        * scale
    )
    index_mask = (
        torch.full((bsz, seqlen_q, seqlen_k), float("-inf"), device=query.device)
        .scatter_(-1, topk_indices.to(torch.int64).squeeze(2), 0)
        .unsqueeze(2)
    )
    scores += index_mask
    scores = scores.softmax(dim=-1).to(q.dtype)
    attention_out = torch.einsum(
        "bsht,btc->bshc", scores.to(torch.float32), v.to(torch.float32).squeeze(2)
    ).to(q.dtype)
    o = torch.einsum("bshc,hdc->bshd", attention_out, wkv_b[:, -v_head_dim:])
    return o


@pytest.mark.skipif(True, reason="Due to triton-ascend version, DSA test is skipped")
@pytest.mark.parametrize(
    "batch, q_seq_len, k_seq_len, head_num, qk_nope_head_dim, qk_rope_head_dim, kv_lora_rank, v_head_dim, dtype",
    [
        (
            batch,
            1,
            k_seq_len,
            16,
            128,
            64,
            512,
            128,
            dtype,
        )
        for batch in [16, 128]
        for k_seq_len in [1024, 8192]
        for dtype in [torch.float16]
    ],
)
def test_dsa_decode(
    batch,
    q_seq_len,
    k_seq_len,
    head_num,
    qk_nope_head_dim,
    qk_rope_head_dim,
    kv_lora_rank,
    v_head_dim,
    dtype,
):
    device = "npu"
    sparse_block_count = 1024
    scale_value = 0.041666666666666664
    query = torch.randn(
        batch,
        q_seq_len,
        head_num,
        qk_nope_head_dim,
        device=device,
        dtype=dtype,
    )
    query_rope = torch.randn(
        batch,
        q_seq_len,
        head_num,
        qk_rope_head_dim,
        device=device,
        dtype=dtype,
    )
    key = torch.randn(
        batch,
        k_seq_len,
        1,
        kv_lora_rank,
        device=device,
        dtype=dtype,
    )
    key_rope = torch.randn(
        batch,
        k_seq_len,
        1,
        qk_rope_head_dim,
        device=device,
        dtype=dtype,
    )
    wkv_b = torch.randn(
        head_num,
        (qk_nope_head_dim + v_head_dim),
        kv_lora_rank,
        device=device,
        dtype=dtype,
    )
    value = key
    topk_indices = torch.randint(
        0, k_seq_len, (batch, 1, 1024), device=device, dtype=torch.int32
    )
    idxs = random.sample(range(k_seq_len), sparse_block_count)
    topk_indices = (
        torch.tensor([idxs for _ in range(batch * q_seq_len * 1)], device=device)
        .reshape(batch, q_seq_len, 1, sparse_block_count)
        .to(torch.int32)
    )

    def triton_op():
        triton_out = dsa_decode_forward(
            query, key, value, wkv_b, topk_indices, query_rope, key_rope, scale_value
        )

    def torch_op():
        pytorch_out = pytorch_dsa_decode(
            query, key, value, wkv_b, topk_indices, query_rope, key_rope, scale_value
        )

    benchmark = Benchmark(
        triton_op=triton_op,
        torch_op=torch_op,
        op_type=OpType.CV,
    )
    benchmark.run()
