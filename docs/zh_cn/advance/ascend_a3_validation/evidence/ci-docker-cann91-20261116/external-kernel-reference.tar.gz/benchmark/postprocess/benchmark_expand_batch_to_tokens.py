# Copyright © 2026 Huawei Technologies Co., Ltd.
import pytest
import torch

from triton_ascend_kernels.postprocess import expand_batch_to_tokens
from benchmark.utils import Benchmark, OpType


def expand_batch_to_tokens_pytorch(
    x: torch.Tensor,  # [batch_size]
    cu_num_tokens: torch.Tensor,  # [batch_size]
    num_tokens: int,
    replace_from: int = 0,
    replace_to: int = 0,
) -> torch.Tensor:
    """Expand [batch_size] tensor to [num_tokens] tensor based on the number of
    tokens per batch in cu_num_tokens.
    For example, if x = [a, b, c] and cu_num_tokens = [2, 5, 6], then
    num_tokens = 6, and expanded_x = [a, a, b, b, b, c].
    Args:
        x: [batch_size] tensor to expand.
        cu_num_tokens: [batch_size] tensor containing the cumulative number of
            tokens per batch. Each element represents the total number of
            tokens up to and including that batch.
        num_tokens: Total number of tokens.
        replace_from: int = 0
            Value to be replaced if it is found in x.
        replace_to: int = 0
            Value to replace with when replace_from is found.
    Returns:
        expanded_x: [num_tokens] tensor.
    """
    batch_size = x.shape[0]
    assert cu_num_tokens.shape[0] == batch_size
    expanded_x = x.new_empty(num_tokens)
    expand_pytorch(
        expanded_x,
        x,
        cu_num_tokens,
        replace_from,
        replace_to,
        MAX_NUM_TOKENS=32,  # To avoid recompilation.
    )
    return expanded_x


def expand_pytorch(
    output_ptr,  # [num_tokens]
    input_ptr,  # [batch_size]
    cu_num_tokens_ptr,  # [batch_size]
    replace_from,
    replace_to,
    MAX_NUM_TOKENS,
):
    batch_size = len(input_ptr)
    for req_idx in range(batch_size):
        start_idx = 0 if req_idx == 0 else cu_num_tokens_ptr[req_idx - 1]
        end_idx = cu_num_tokens_ptr[req_idx]
        num_tokens = end_idx - start_idx
        src_val = input_ptr[req_idx]
        src_val = replace_to if src_val == replace_from else src_val
        offset = torch.arange(MAX_NUM_TOKENS, device=num_tokens.device)
        mask = offset < num_tokens
        output_slice = start_idx + offset[mask]
        output_ptr[output_slice] = src_val


@pytest.mark.parametrize("batch_size ", [8])
@pytest.mark.xdist_group("benchmark")
def test_benchmark_expand_batch_to_tokens(batch_size):
    device = "npu"
    x = torch.randint(1, 16, (batch_size,), device="npu", dtype=torch.int32)
    num_draft_per_req = torch.randint(
        1, 32 + 1, (batch_size,), device="npu", dtype=torch.int32
    )
    cu_num_draft_tokens = torch.cumsum(num_draft_per_req, dim=0).int()
    num_tokens = cu_num_draft_tokens[-1].item()

    replace_from = 1
    replace_to = 0

    def torch_op():
        expand_batch_to_tokens_pytorch(
            x=x,
            cu_num_tokens=cu_num_draft_tokens,
            num_tokens=num_tokens,
            replace_from=replace_from,
            replace_to=replace_to,
        )

    def triton_op():
        expand_batch_to_tokens(
            x=x,
            cu_num_tokens=cu_num_draft_tokens,
            num_tokens=num_tokens,
            replace_from=replace_from,
            replace_to=replace_to,
        )

    benchmark = Benchmark(
        triton_op=triton_op,
        torch_op=torch_op,
        op_type=OpType.OTHER,
    )
    benchmark.run()
