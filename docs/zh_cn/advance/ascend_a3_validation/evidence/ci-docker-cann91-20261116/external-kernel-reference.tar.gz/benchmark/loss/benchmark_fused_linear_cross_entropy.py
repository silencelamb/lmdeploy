# Copyright © 2025 Huawei Technologies Co., Ltd.
# Copyright 2024 LinkedIn Corporation
import pytest
import torch

from tests.loss.test_fused_linear_cross_entropy import set_seed, TorchLMHeadCE, LMHeadCE
from benchmark.utils import Benchmark, OpType

device = "npu"
set_seed()


@pytest.mark.xdist_group("benchmark")
@pytest.mark.parametrize(
    "B, T, H, V",
    [
        pytest.param(
            1, 165, 2560, 151936, marks=pytest.mark.skip(reason="bad performance")
        ),
        pytest.param(
            8, 128, 1024, 4096, marks=pytest.mark.skip(reason="bad performance")
        ),
        (4, 47, 31, 123),  # random shape
    ],
)
@pytest.mark.parametrize(
    "reduction, scalar, dtype",
    [
        ("mean", 1.0, torch.bfloat16),
        ("mean", 1.0, torch.float32),
        ("sum", 1.0, torch.bfloat16),
        ("sum", 1.0, torch.float32),
    ],
)
@pytest.mark.parametrize("bias", [True, False])
@pytest.mark.parametrize(
    "has_ce_weight, label_smoothing, ignore_index, lse_square_scale, softcap, return_z_loss, accum_dtype",
    [
        (False, 0, -100, 0, None, False, None),
        # Pass non-default values once to ensure all params work along
        (True, 0.1, 42, 1e-4, 30.0, True, torch.float32),
    ],
)
def test_benchmark_fused_linear_cross_entropy(
    B,
    T,
    H,
    V,
    scalar,
    dtype,
    bias,
    has_ce_weight,
    lse_square_scale,
    label_smoothing,
    ignore_index,
    reduction,
    softcap,
    return_z_loss,
    accum_dtype,
):
    if has_ce_weight:
        ce_weight = torch.rand(V, device=device, dtype=torch.float32)
    else:
        ce_weight = None
    torch_lm_head_ce = TorchLMHeadCE(
        H=H,
        V=V,
        bias=bias,
        ce_weight=ce_weight,
        lse_square_scale=lse_square_scale,
        label_smoothing=label_smoothing,
        ignore_index=ignore_index,
        reduction=reduction,
        softcap=softcap,
        return_z_loss=return_z_loss,
        dtype=dtype,
    ).to(device)
    lm_head_ce = LMHeadCE(
        H=H,
        V=V,
        bias=bias,
        ce_weight=ce_weight,
        lse_square_scale=lse_square_scale,
        label_smoothing=label_smoothing,
        ignore_index=ignore_index,
        reduction=reduction,
        softcap=softcap,
        return_z_loss=return_z_loss,
        dtype=dtype,
        accum_dtype=accum_dtype,
    ).to(device)

    # init the linear in all CEs with the same weights
    torch_lm_head_ce.lin.weight.data = lm_head_ce.lin.weight.data = torch.rand(
        V, H, device=device, dtype=dtype
    )

    if bias:
        torch_lm_head_ce.lin.bias.data = lm_head_ce.lin.bias.data = torch.rand(
            V, device=device, dtype=dtype
        )

    _tensor = torch.randn(B * T, H, device=device, dtype=dtype) * scalar
    _input1 = _tensor.detach().clone().requires_grad_(True)
    _input2 = _tensor.detach().clone().requires_grad_(True)

    target = torch.randint(0, V, (B * T,), device=device, dtype=torch.long)
    # Assign some random number of elements as ignore_index
    num_elements_to_assign = torch.randint(
        1, B * T // 2, (1,)
    ).item()  # Random number of elements to set to ignore_index
    indices_to_assign = torch.randperm(B * T)[
        :num_elements_to_assign
    ]  # Randomly select indices
    target[indices_to_assign] = ignore_index

    def torch_fn():
        if return_z_loss:
            output1, z_output1 = torch_lm_head_ce(_input1, target)
        else:
            output1 = torch_lm_head_ce(_input1, target)
        grad_output = torch.ones_like(output1)
        output1.backward(gradient=grad_output)

    def triton_fn():
        if return_z_loss:
            output2, z_output2 = lm_head_ce(_input2, target)
        else:
            output2 = lm_head_ce(_input2, target)
        grad_output = torch.ones_like(output2)
        output2.backward(gradient=grad_output)

    benchmark = Benchmark(
        triton_op=lambda: triton_fn(),
        torch_op=lambda: torch_fn(),
        op_type=OpType.OTHER,
    )
    benchmark.run()
