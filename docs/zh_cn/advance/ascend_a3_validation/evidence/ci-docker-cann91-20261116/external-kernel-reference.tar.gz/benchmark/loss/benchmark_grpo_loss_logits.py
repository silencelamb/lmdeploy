# Copyright © 2025 Huawei Technologies Co., Ltd.
# Copyright (c) 2025, DeepLink.
import torch
import triton
import pytest
from triton_ascend_kernels.loss import GRPO_Loss_Optimized, grpo_compute_loss_torch
from benchmark.utils import Benchmark, OpType


BENCHMARK_SHAPES = [
    ("Small-Batch", 1, 1024, 32000),
    ("Medium-Batch", 4, 512, 50257),
    ("Large-Batch", 8, 512, 50257),
    ("XLarge-Batch", 16, 256, 128000),
]

DTYPES = [torch.float16, torch.float32]

GRPO_KWARGS = {
    "beta": 0.1,
    "loss_type": "grpo",
    "epsilon_low": 0.2,
    "epsilon_high": 0.2,
    "max_completion_length": 8192,
    "delta": 2.7,
    "temperature": 1.0,
}


@pytest.mark.benchmark
@pytest.mark.parametrize("name,B,S,V", BENCHMARK_SHAPES)
@pytest.mark.parametrize("dtype", DTYPES)
@pytest.mark.xdist_group("benchmark")
def test_benchmark_grpo_loss(name, B, S, V, dtype):
    if not torch.npu.is_available():
        pytest.skip("NPU is not available, skipping benchmark")

    BL = B * S
    # skip large float32 test cases (to avoid OOM)
    if dtype == torch.float32 and BL * V > 8 * 512 * 50257:
        pytest.skip(f"Skipping {name} (BL={BL}, V={V}, dtype=float32) to avoid OOM")

    print(f"\n{'='*80}")
    print(f"GRPO Loss Forward Pass Benchmark - {name}")
    print(
        f"Device: {torch.npu.get_device_name(0)} | Shape: B={B}, S={S}, V={V} | Dtype: {str(dtype).split('.')[-1]}"
    )
    print(f"{'='*80}")

    torch.manual_seed(42)
    new_logits = torch.randn((BL, V), device="npu", dtype=dtype)
    ref_logits = torch.randn((BL, V), device="npu", dtype=dtype)
    old_logits = torch.randn((BL, V), device="npu", dtype=dtype)
    input_ids = torch.randint(0, V, (BL,), device="npu")
    advantages = torch.randn((BL,), device="npu", dtype=dtype)
    mask = torch.randint(0, 2, (BL,), device="npu").bool()

    benchmark = Benchmark(
        triton_op=lambda: GRPO_Loss_Optimized.apply(
            new_logits,
            ref_logits,
            old_logits,
            input_ids,
            advantages,
            mask,
            GRPO_KWARGS["beta"],
            GRPO_KWARGS["loss_type"],
            GRPO_KWARGS["epsilon_low"],
            GRPO_KWARGS["epsilon_high"],
            GRPO_KWARGS["max_completion_length"],
            GRPO_KWARGS["delta"],
            GRPO_KWARGS["temperature"],
        ),
        torch_op=lambda: grpo_compute_loss_torch(
            new_logits,
            ref_logits,
            old_logits,
            input_ids,
            advantages,
            mask,
            **GRPO_KWARGS,
        ),
        op_type=OpType.PURE_CUBE,
    )
    benchmark.run()
