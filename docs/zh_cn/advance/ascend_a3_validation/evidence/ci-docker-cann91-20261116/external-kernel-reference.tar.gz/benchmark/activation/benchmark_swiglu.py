# Copyright © 2025 Huawei Technologies Co., Ltd.
# Copyright 2024 LinkedIn Corporation
import pytest
import torch
import torch_npu

from transformers.models.llama.configuration_llama import LlamaConfig
from transformers.models.llama.modeling_llama import LlamaMLP
from transformers.models.phi3.configuration_phi3 import Phi3Config
from transformers.models.phi3.modeling_phi3 import Phi3MLP

from triton_ascend_kernels.activation import Phi3SwiGLUMLP
from triton_ascend_kernels.activation import SwiGLUMLP
from benchmark.utils import Benchmark, OpType

device = "npu"

LLAMA_CONFIG = LlamaConfig(
    hidden_size=4096,
    intermediate_size=11008,
    hidden_act="silu",
)
PHI3_CONFIG = Phi3Config(
    hidden_size=4096,
    intermediate_size=11008,
    hidden_act="silu",
)
SLEEP_SECONDS = 0.1


@pytest.mark.xdist_group("benchmark")
@pytest.mark.parametrize(
    "bsz, seq_len, hidden_size, intermediate_size,dtype",
    [
        (2, 2, 2, 4, torch.bfloat16),
        (2, 256, 256, 8192, torch.bfloat16),
        pytest.param(
            2,
            2,
            2,
            4,
            torch.float32,
            marks=pytest.mark.skip(reason="bad performance"),
        ),
        pytest.param(
            2,
            256,
            256,
            8192,
            torch.float32,
            marks=pytest.mark.skip(reason="bad performance"),
        ),
        pytest.param(
            2,
            256,
            256,
            512,
            torch.bfloat16,
            marks=pytest.mark.skip(reason="bad performance"),
        ),
        pytest.param(
            2,
            256,
            256,
            512,
            torch.float32,
            marks=pytest.mark.skip(reason="bad performance"),
        ),
        # weird shapes
        pytest.param(
            6,
            42,
            123,
            431,
            torch.float32,
            marks=pytest.mark.skip(reason="bad performance"),
        ),
        pytest.param(
            6,
            42,
            123,
            431,
            torch.bfloat16,
            marks=pytest.mark.skip(reason="bad performance"),
        ),
    ],
)
def test_benchmark_llamamlp(bsz, seq_len, hidden_size, intermediate_size, dtype):
    _input = torch.randn(bsz, seq_len, hidden_size, device=device, dtype=dtype)

    x1 = _input.clone().requires_grad_(True)
    x2 = _input.clone().requires_grad_(True)

    # initialize weights
    G = torch.randn(hidden_size, intermediate_size, device=device, dtype=dtype)
    U = torch.randn(hidden_size, intermediate_size, device=device, dtype=dtype)
    D = torch.randn(intermediate_size, hidden_size, device=device, dtype=dtype)

    def triton_fn():
        _mlp = SwiGLUMLP(config=LLAMA_CONFIG).to(device).to(dtype)
        _mlp.gate_proj.weight.data = G.T
        _mlp.up_proj.weight.data = U.T
        _mlp.down_proj.weight.data = D.T

        y2 = _mlp(x2)
        dy = torch.randn_like(y2)
        y2.backward(dy.clone(), retain_graph=True)

    def torch_fn():
        llama_mlp = LlamaMLP(config=LLAMA_CONFIG).to(device).to(dtype)
        llama_mlp.gate_proj.weight.data = G.T
        llama_mlp.up_proj.weight.data = U.T
        llama_mlp.down_proj.weight.data = D.T

        y1 = llama_mlp(x1)
        dy = torch.randn_like(y1)
        y1.backward(dy.clone(), retain_graph=True)

    benchmark = Benchmark(
        triton_op=lambda: triton_fn(),
        torch_op=lambda: torch_fn(),
        op_type=OpType.OTHER,
    )
    benchmark.run()


@pytest.mark.xdist_group("benchmark")
@pytest.mark.parametrize(
    "bsz, seq_len, hidden_size, intermediate_size",
    [
        pytest.param(
            2, 256, 256, 512, marks=pytest.mark.skip(reason="bad performance")
        ),
        # weird shapes
        (6, 42, 123, 431),
    ],
)
@pytest.mark.parametrize(
    "dtype",
    [
        torch.float32,
        torch.bfloat16,
    ],
)
def test_benchmark_phi3mlp(bsz, seq_len, hidden_size, intermediate_size, dtype):
    _input = torch.randn(bsz, seq_len, hidden_size, device=device, dtype=dtype)

    x1 = _input.clone().requires_grad_(True)
    x2 = _input.clone().requires_grad_(True)

    # initialize weights
    GU = torch.randn(hidden_size, intermediate_size * 2, device=device, dtype=dtype)
    D = torch.randn(intermediate_size, hidden_size, device=device, dtype=dtype)

    def torch_fn():
        phi3_mlp = Phi3MLP(config=PHI3_CONFIG).to(device).to(dtype)
        phi3_mlp.gate_up_proj.weight.data = GU.T
        phi3_mlp.down_proj.weight.data = D.T
        y1 = phi3_mlp(x1)
        dy = torch.randn_like(y1)
        y1.backward(dy.clone(), retain_graph=True)

    def triton_fn():
        _mlp = Phi3SwiGLUMLP(config=PHI3_CONFIG).to(device).to(dtype)
        _mlp.gate_up_proj.weight.data = GU.T
        _mlp.down_proj.weight.data = D.T
        y2 = _mlp(x2)
        dy = torch.randn_like(y2)
        y2.backward(dy.clone(), retain_graph=True)

    benchmark = Benchmark(
        triton_op=lambda: triton_fn(),
        torch_op=lambda: torch_fn(),
        op_type=OpType.OTHER,
    )
    benchmark.run()
