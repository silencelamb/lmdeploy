# Copyright © 2025 Huawei Technologies Co., Ltd.
# Copyright 2024 LinkedIn Corporation
import pytest
import torch

from triton_ascend_kernels.norm import RMSNorm

from tests.norm.test_rms_norm import LlamaRMSNorm, GemmaRMSNorm, BaseRMSNorm, set_seed
from benchmark.utils import Benchmark, OpType


set_seed(42)
torch.use_deterministic_algorithms(True)

device = "npu"

SLEEP_SECONDS = 0.1


@pytest.mark.xdist_group("benchmark")
@pytest.mark.flaky(reruns=3, reruns_delay=2)
@pytest.mark.parametrize(
    "bs, sl, hd",
    [
        (2, 4, 8),
        (5, 123, 123),
        (1, 441, 2046),
    ],
)
@pytest.mark.parametrize(
    "dtype",
    [
        (torch.float32),
        (torch.bfloat16),
    ],
)
@pytest.mark.parametrize(
    "reference, offset, casting_mode",
    [
        (LlamaRMSNorm, 0.0, "llama"),
        (GemmaRMSNorm, 1.0, "gemma"),
        (BaseRMSNorm, 0.0, "none"),
    ],
)
@pytest.mark.parametrize(
    "in_place",
    [
        True,
        False,
    ],
)
def test_benchmark_rms_norm(
    bs, sl, hd, dtype, reference, offset, casting_mode, in_place
):
    _tensor = torch.randn(bs, sl, hd, device=device, dtype=dtype)

    h1 = _tensor.clone().requires_grad_(True)
    h2 = _tensor.clone().requires_grad_(True)

    # do
    do = torch.randn(bs, sl, hd, device=device, dtype=dtype)

    def torch_fn():
        ref_rms = reference(hidden_size=hd).to(device).to(dtype)
        ref_o = ref_rms(h1)
        ref_o.backward(do, retain_graph=True)

    def triton_fn():
        # triton
        triton_rms = (
            RMSNorm(
                hidden_size=hd,
                offset=offset,
                casting_mode=casting_mode,
                in_place=in_place,
            )
            .to(device)
            .to(dtype)
        )
        triton_o = triton_rms(h2)
        triton_o.backward(do, retain_graph=True)

    benchmark = Benchmark(
        triton_op=lambda: triton_fn(),
        torch_op=lambda: torch_fn(),
        op_type=OpType.OTHER,
    )
    benchmark.run()
