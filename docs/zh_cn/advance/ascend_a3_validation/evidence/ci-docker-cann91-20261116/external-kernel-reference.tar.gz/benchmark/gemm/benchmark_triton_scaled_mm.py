import random
import importlib
from typing import Optional
import numpy as np
import torch
import pytest
from benchmark.utils import Benchmark, OpType

triton_scaled_mm_module = importlib.import_module(
    "triton_ascend_kernels.gemm.triton_scaled_mm"
)
triton_scaled_mm = triton_scaled_mm_module.triton_scaled_mm

device = "npu"


def seed_everything(seed: int = 0):
    """Set random seeds for reproducibility."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    if hasattr(torch, "npu") and torch.npu.is_available():
        torch.npu.manual_seed_all(seed)


def torch_scaled_mm(
    a: torch.Tensor,
    b: torch.Tensor,
    scale_a: torch.Tensor,
    scale_b: torch.Tensor,
    out_dtype: type[torch.dtype],
    bias: Optional[torch.Tensor] = None,
) -> torch.Tensor:
    out = torch.mm(a.to(torch.float32), b.to(torch.float32))
    out = scale_a * out
    out = scale_b.T * out
    out = out.to(out_dtype)
    if bias is not None:
        out = out + bias

    return out


def get_8bit_types():
    """Return supported 8-bit dtypes."""
    types = [torch.int8]

    return types


@pytest.mark.parametrize("M", [64, 256])
@pytest.mark.parametrize("N", [256, 512])
@pytest.mark.parametrize("K", [128, 512])
@pytest.mark.parametrize("out_dtype", [torch.float16])
@pytest.mark.parametrize("in_dtype", [torch.int8])
@pytest.mark.parametrize("use_scalar_scale_a", [True])
@pytest.mark.parametrize("use_scalar_scale_b", [True, False])
@pytest.mark.parametrize("use_bias", [False])
@pytest.mark.xdist_group("benchmark")
def test_benchmark_triton_scaled_mm(
    M, K, N, out_dtype, in_dtype, use_scalar_scale_a, use_scalar_scale_b, use_bias
):
    def is_floating_point_type(t):
        return torch.tensor([1, 1], dtype=t).is_floating_point()

    seed_everything(0)

    if is_floating_point_type(in_dtype):
        a = (0.25 * torch.rand((M, K), dtype=torch.float32, device=device)).to(in_dtype)
        b = (0.25 * torch.rand((K, N), dtype=torch.float32, device=device)).to(in_dtype)
    else:
        a = torch.randint(-32, 32, (M, K), dtype=in_dtype, device=device)
        b = torch.randint(-32, 32, (K, N), dtype=in_dtype, device=device)

    if use_scalar_scale_a:
        scale_a = torch.rand((1, 1), device=device)
    else:
        scale_a = 0.25 * torch.rand((M, 1), device=device)

    if use_scalar_scale_b:
        scale_b = torch.rand((1, 1), device=device)
    else:
        scale_b = 0.25 * torch.rand((N, 1), device=device)

    bias = None
    if use_bias:
        bias = torch.rand((N,), device=device, dtype=out_dtype)

    def torch_op():
        return torch_scaled_mm(
            a=a, b=b, scale_a=scale_a, scale_b=scale_b, out_dtype=out_dtype, bias=bias
        )

    def triton_op():
        return triton_scaled_mm(
            input_data=a,
            weight=b,
            scale_a=scale_a,
            scale_b=scale_b,
            out_dtype=out_dtype,
            bias=bias,
        )

    benchmark = Benchmark(
        triton_op=triton_op,
        torch_op=torch_op,
        op_type=OpType.CV,
    )
    benchmark.run()
