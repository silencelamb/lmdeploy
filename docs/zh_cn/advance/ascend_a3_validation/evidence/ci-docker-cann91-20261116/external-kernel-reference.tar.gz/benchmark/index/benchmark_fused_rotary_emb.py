# Copyright © 2025 Huawei Technologies Co., Ltd.
# Copyright (c) 2025, DeepLink.
import pytest
import torch
from torch import nn
from triton_ascend_kernels.index import fused_rotary_emb
from benchmark.utils import Benchmark, OpType


def rotate_half(x):
    """Rotates half the hidden dims of the input."""
    x1 = x[..., : x.shape[-1] // 2]
    x2 = x[..., x.shape[-1] // 2 :]
    return torch.cat((-x2, x1), dim=-1)


def apply_rotary_pos_emb(q, k, cos, sin, position_ids=None, unsqueeze_dim=2):
    """Applies Rotary Position Embedding to the query and key tensors."""
    cos = cos.unsqueeze(unsqueeze_dim)
    sin = sin.unsqueeze(unsqueeze_dim)
    q_embed = (q * cos) + (rotate_half(q) * sin)
    k_embed = (k * cos) + (rotate_half(k) * sin)
    return q_embed, k_embed


class DummyRotaryEmbedding(nn.Module):
    def __init__(self, dim, max_position_embeddings=2048, base=10000, device=None):
        super().__init__()
        self.dim = dim
        self.max_position_embeddings = max_position_embeddings
        self.base = base
        inv_freq = 1.0 / (
            self.base
            ** (
                torch.arange(0, self.dim, 2, dtype=torch.int64).float().to(device)
                / self.dim
            )
        )
        self.register_buffer("inv_freq", inv_freq, persistent=False)

    def forward(self, x, position_ids, seq_len=None):
        inv_freq_expanded = (
            self.inv_freq[None, :, None].float().expand(position_ids.shape[0], -1, 1)
        )
        position_ids_expanded = position_ids[:, None, :].float()
        freqs = (inv_freq_expanded @ position_ids_expanded).transpose(1, 2)
        emb = torch.cat((freqs, freqs), dim=-1)
        cos = emb.cos().to(dtype=x.dtype)
        sin = emb.sin().to(dtype=x.dtype)
        return cos, sin


class DummyLinearScalingRotaryEmbedding(DummyRotaryEmbedding):
    def __init__(
        self,
        dim,
        max_position_embeddings=2048,
        base=10000,
        device=None,
        scaling_factor=1.0,
    ):
        self.scaling_factor = scaling_factor
        super().__init__(dim, max_position_embeddings, base, device)

    def forward(self, x, position_ids, seq_len=None):
        position_ids = position_ids.float() / self.scaling_factor
        cos, sin = super().forward(x, position_ids, seq_len)
        return cos, sin


@pytest.mark.parametrize("dtype", [torch.float16])
@pytest.mark.parametrize("batch_size", [2])
@pytest.mark.parametrize("head_dim", [64])
@pytest.mark.parametrize("q_num_heads, k_num_heads", [(4, 2)])
@pytest.mark.parametrize("seq_len", [100, 500, 1000])
@pytest.mark.xdist_group("benchmark")
def test_benchmark_fused_rotary_emb(
    dtype: torch.dtype,
    batch_size: int,
    head_dim: int,
    q_num_heads: int,
    k_num_heads: int,
    seq_len: int,
):
    device = torch.device("npu")
    q = torch.rand(batch_size, seq_len, q_num_heads, head_dim, dtype=dtype).to(device)
    k = torch.rand(batch_size, seq_len, k_num_heads, head_dim, dtype=dtype).to(device)
    position_ids = torch.randint(0, seq_len + 100, (batch_size, seq_len)).to(device)
    rotary_emb = DummyLinearScalingRotaryEmbedding(head_dim, scaling_factor=1.0).to(
        device
    )
    inv_freq = rotary_emb.inv_freq
    scaling_factor = rotary_emb.scaling_factor

    def torch_op():
        with torch.inference_mode():
            cos, sin = rotary_emb(q, position_ids)
            return apply_rotary_pos_emb(q, k, cos, sin, position_ids=position_ids)

    def triton_op():
        with torch.inference_mode():
            return fused_rotary_emb(
                q, k, position_ids, inv_freq, scaling_factor=scaling_factor
            )

    benchmark = Benchmark(
        triton_op=triton_op,
        torch_op=torch_op,
        op_type=OpType.PURE_CUBE,
    )
    benchmark.run()
