# Copyright (c) Huawei Technologies Co., Ltd. 2025. All rights reserved.
# SPDX-FileCopyrightText: Copyright (c) 2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# Copyright 2024 Bytedance Ltd. and/or its affiliate
import os

import pytest
import torch

from benchmark.utils import Benchmark, OpType
from triton_ascend_kernels.loss.verl_linear_cross_entropy import linear_cross_entropy
from triton_ascend_kernels.loss.verl_cross_entropy_kernels import (
    run_triton_d_weight,
    run_triton_d_hidden,
)

MAX_TEST_CASES = int(os.environ.get("MAX_TEST_CASES", 5))

LINEAR_CE_CASES = [
    (1, 1388, 4096, 1024),
    (1, 8192, 4096, 1024),
][:MAX_TEST_CASES]


def run_torch_linear_ce(
    hidden: torch.Tensor,
    weight: torch.Tensor,
    labels: torch.Tensor,
    temperature: float,
    reduction: str = "none",
):
    hidden_2d = hidden.squeeze(0).to(torch.float32)  # [num_tokens, hidden_size]
    weight_t = weight.transpose(0, 1).to(torch.float32)  # [hidden_size, vocab_size]

    logits = torch.matmul(hidden_2d, weight_t)  # [num_tokens, vocab_size]
    logits /= temperature

    pd = torch.nn.functional.softmax(logits, dim=-1)
    entropy_a = torch.logsumexp(logits, dim=-1)
    entropy_b = torch.sum(pd * logits, dim=-1)
    entropy = entropy_a - entropy_b  # [num_tokens]

    logprobs = torch.nn.functional.cross_entropy(
        logits, labels.squeeze(0), reduction=reduction
    )
    logprobs = torch.neg(logprobs)
    return logprobs, entropy


def torch_op_d_weight(
    hidden: torch.Tensor,
    weight: torch.Tensor,
    labels: torch.Tensor,
    temperature: float,
    reduction: int,
):
    logits = (
        torch.matmul(hidden.to(torch.float32), weight.T.to(torch.float32)) / temperature
    )

    if reduction == 0:
        loss_vec = torch.nn.functional.cross_entropy(logits, labels, reduction="none")
    elif reduction == 1:
        loss_vec = torch.nn.functional.cross_entropy(logits, labels, reduction="sum")
    else:
        loss_vec = torch.nn.functional.cross_entropy(logits, labels, reduction="mean")
    loss = loss_vec.sum()
    if hidden.grad is not None:
        hidden.grad = None
    if weight.grad is not None:
        weight.grad = None
    loss.backward()
    d_weight_expected = weight.grad.detach().to(torch.float32)
    return logits, d_weight_expected


def torch_op_d_hidden(
    hidden: torch.Tensor,
    weight: torch.Tensor,
    labels: torch.Tensor,
    temperature: float,
    reduction: int,
):
    logits = (
        torch.matmul(hidden.to(torch.float32), weight.T.to(torch.float32)) / temperature
    )

    if reduction == 0:
        loss_vec = torch.nn.functional.cross_entropy(logits, labels, reduction="none")
    elif reduction == 1:
        loss_vec = torch.nn.functional.cross_entropy(logits, labels, reduction="sum")
    else:
        loss_vec = torch.nn.functional.cross_entropy(logits, labels, reduction="mean")
    loss = loss_vec.sum()
    if hidden.grad is not None:
        hidden.grad = None
    if weight.grad is not None:
        weight.grad = None
    loss.backward()
    d_hidden_expected = hidden.grad.detach().to(torch.float32)
    return logits, d_hidden_expected


@pytest.mark.skipif(True, reason="Due to not enough memory, verl test skipped")
@pytest.mark.parametrize(
    "batch_size, num_tokens, hidden_size, vocab_size", LINEAR_CE_CASES
)
@pytest.mark.parametrize("dtype", [torch.bfloat16])
@pytest.mark.xdist_group("benchmark")
def test_benchmark_linear_cross_entropy(
    batch_size: int,
    num_tokens: int,
    hidden_size: int,
    vocab_size: int,
    dtype,
):
    temperature = 1.5

    hidden = (
        torch.empty((batch_size, num_tokens, hidden_size), dtype=dtype, device="npu")
        .uniform_(-0.5, 0.5)
        .requires_grad_()
    )
    weight = (
        torch.empty((vocab_size, hidden_size), dtype=dtype, device="npu")
        .uniform_(-0.5, 0.5)
        .requires_grad_()
    )
    labels = torch.randint(0, vocab_size, (batch_size, num_tokens), device="npu")
    with torch.no_grad():
        benchmark = Benchmark(
            triton_op=lambda: linear_cross_entropy(hidden, weight, labels, temperature),
            torch_op=lambda: run_torch_linear_ce(hidden, weight, labels, temperature),
            op_type=OpType.OTHER,
        )
        benchmark.run()

@pytest.mark.skipif(True, reason="Due to not enough memory, verl test skipped")
@pytest.mark.parametrize(
    "batch_size, num_tokens, hidden_size, vocab_size", LINEAR_CE_CASES
)
@pytest.mark.parametrize("dtype", [torch.bfloat16])
@pytest.mark.xdist_group("benchmark")
def test_benchmark_linear_cross_entropy_bwd(
    batch_size: int,
    num_tokens: int,
    hidden_size: int,
    vocab_size: int,
    dtype,
):
    temperature = 1.5

    hidden = (
        torch.empty((batch_size, num_tokens, hidden_size), dtype=dtype, device="npu")
        .uniform_(-0.5, 0.5)
        .requires_grad_()
    )
    weight = (
        torch.empty((vocab_size, hidden_size), dtype=dtype, device="npu")
        .uniform_(-0.5, 0.5)
        .requires_grad_()
    )
    labels = torch.randint(0, vocab_size, (batch_size, num_tokens), device="npu")

    g_entropy = torch.empty((num_tokens,), dtype=dtype, device="npu").uniform_(
        -0.5, 0.5
    )
    g_logprobs = torch.empty((num_tokens,), dtype=dtype, device="npu").uniform_(-1, 1)

    (torch_logprobs, torch_entropy) = run_torch_linear_ce(
        hidden, weight, labels, temperature
    )
    (kernel_logprobs, kernel_entropy) = linear_cross_entropy(
        hidden, weight, labels, temperature
    )

    benchmark = Benchmark(
        triton_op=lambda: torch.autograd.grad(
            (kernel_entropy, kernel_logprobs),
            (hidden, weight),
            (g_entropy, g_logprobs),
            retain_graph=True,
        ),
        torch_op=lambda: torch.autograd.grad(
            (torch_entropy, torch_logprobs),
            (hidden, weight),
            (g_entropy, g_logprobs),
            retain_graph=True,
        ),
        op_type=OpType.OTHER,
    )
    benchmark.run()


@pytest.mark.parametrize(
    "batch_size, num_tokens, hidden_size, vocab_size", LINEAR_CE_CASES
)
@pytest.mark.parametrize("dtype", [torch.bfloat16])
@pytest.mark.xdist_group("benchmark")
def test_benchmark_efficient_entropy_backward_kernel_d_weight(
    batch_size: int,
    num_tokens: int,
    hidden_size: int,
    vocab_size: int,
    dtype,
):
    temperature = 1.5
    reduction = 0
    hidden = (
        torch.empty((num_tokens, hidden_size), dtype=dtype, device="npu")
        .uniform_(-0.5, 0.5)
        .requires_grad_()
    )
    weight = (
        torch.empty((vocab_size, hidden_size), dtype=dtype, device="npu")
        .uniform_(-0.5, 0.5)
        .requires_grad_()
    )
    labels = torch.randint(0, vocab_size, (num_tokens,), device="npu")

    logits, _ = torch_op_d_weight(hidden, weight, labels, temperature, reduction)

    max_val = logits.max(dim=-1).values.to(torch.float32)
    exp_logits = torch.exp(logits.to(torch.float32) - max_val.unsqueeze(-1))
    accu = exp_logits.sum(dim=-1)
    if reduction == 0:
        d_logprobs = -torch.ones((num_tokens,), dtype=torch.float32, device="npu")
    elif reduction == 1:
        d_logprobs = torch.tensor([-1.0], dtype=torch.float32, device="npu")
    else:
        d_logprobs = torch.tensor([-1.0], dtype=torch.float32, device="npu")
    d_entropy = torch.zeros((num_tokens,), dtype=torch.float32, device="npu")
    entropy_b = torch.zeros((num_tokens,), dtype=torch.float32, device="npu")
    d_weight = torch.zeros((vocab_size, hidden_size), device="npu", dtype=torch.float32)

    benchmark = Benchmark(
        triton_op=lambda: run_triton_d_weight(
            hidden,
            weight,
            labels,
            max_val,
            accu,
            d_entropy,
            d_logprobs,
            entropy_b,
            d_weight,
        ),
        torch_op=lambda: torch_op_d_weight(
            hidden, weight, labels, temperature, reduction
        ),
        op_type=OpType.OTHER,
    )
    benchmark.run()


@pytest.mark.skipif(True, reason="Due to not enough memory, verl test skipped")
@pytest.mark.parametrize(
    "batch_size, num_tokens, hidden_size, vocab_size", LINEAR_CE_CASES
)
@pytest.mark.parametrize("dtype", [torch.bfloat16])
@pytest.mark.xdist_group("benchmark")
def test_benchmark_efficient_entropy_backward_kernel_d_hidden(
    batch_size: int,
    num_tokens: int,
    hidden_size: int,
    vocab_size: int,
    dtype,
):
    temperature = 1.5
    reduction = 0
    hidden = (
        torch.empty((num_tokens, hidden_size), dtype=dtype, device="npu")
        .uniform_(-0.5, 0.5)
        .requires_grad_()
    )
    weight = (
        torch.empty((vocab_size, hidden_size), dtype=dtype, device="npu")
        .uniform_(-0.5, 0.5)
        .requires_grad_()
    )
    labels = torch.randint(0, vocab_size, (num_tokens,), device="npu")

    logits, _ = torch_op_d_weight(hidden, weight, labels, temperature, reduction)

    max_val = logits.max(dim=-1).values.to(torch.float32)
    exp_logits = torch.exp(logits.to(torch.float32) - max_val.unsqueeze(-1))
    accu = exp_logits.sum(dim=-1)
    if reduction == 0:
        d_logprobs = -torch.ones((num_tokens,), dtype=torch.float32, device="npu")
    elif reduction == 1:
        d_logprobs = torch.tensor([-1.0], dtype=torch.float32, device="npu")
    else:
        d_logprobs = torch.tensor([-1.0], dtype=torch.float32, device="npu")
    d_entropy = torch.zeros((num_tokens,), dtype=torch.float32, device="npu")
    entropy_b = torch.zeros((num_tokens,), dtype=torch.float32, device="npu")
    d_hidden = torch.zeros((num_tokens, hidden_size), device="npu", dtype=torch.float32)

    benchmark = Benchmark(
        triton_op=lambda: run_triton_d_hidden(
            hidden,
            weight,
            labels,
            max_val,
            accu,
            d_entropy,
            d_logprobs,
            entropy_b,
            d_hidden,
        ),
        torch_op=lambda: run_triton_d_hidden(
            hidden,
            weight,
            labels,
            max_val,
            accu,
            d_entropy,
            d_logprobs,
            entropy_b,
            d_hidden,
        ),
        op_type=OpType.OTHER,
    )
    benchmark.run()
