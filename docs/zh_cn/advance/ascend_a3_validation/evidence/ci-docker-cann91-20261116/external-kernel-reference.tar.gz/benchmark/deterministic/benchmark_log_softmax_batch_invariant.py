# Copyright © 2026 Huawei Technologies Co., Ltd.

import torch
import pytest
from triton_ascend_kernels.deterministic import log_softmax_batch_invariant
from benchmark.utils import Benchmark, OpType


def log_softmax_deterministic(x: torch.Tensor, dim: int = -1) -> torch.Tensor:
    result = torch.zeros_like(x)
    N, C = x.shape

    for i in range(N):
        row_data = x[i]
        row_max = torch.max(row_data)
        row_stable = row_data - row_max

        exp_row = torch.exp(row_stable)
        row_sum = 0.0
        for j in range(C):
            row_sum += exp_row[j].item()

        log_softmax_row = row_stable - torch.log(
            torch.tensor(row_sum, dtype=x.dtype, device=x.device)
        )

        result[i] = log_softmax_row

    return result


@pytest.mark.xdist_group("benchmark")
@pytest.mark.parametrize("batch_size", [128])
@pytest.mark.parametrize("hidden_size", [256])
def test_benchmark_log_softmax_batch_invariant(
    batch_size: int,
    hidden_size: int,
):

    torch.manual_seed(42)
    x = torch.randn(batch_size, hidden_size, dtype=torch.bfloat16).npu()

    def torch_op():
        _ = log_softmax_deterministic(x, -1)

    def triton_op():
        _ = log_softmax_batch_invariant(x, -1)

    benchmark = Benchmark(
        triton_op=triton_op,
        torch_op=torch_op,
        op_type=OpType.PURE_VECTOR,
    )
    benchmark.run()
