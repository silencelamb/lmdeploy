# Copyright © 2025 Huawei Technologies Co., Ltd.
# Copyright 2024 LinkedIn Corporation
import random
import os
import pytest
import torch
import torch_npu

import torch.nn.functional as F
import numpy as np


from torch.nn import CrossEntropyLoss as CrossEntropyLoss_
from triton_ascend_kernels.loss import CrossEntropyLoss
from benchmark.utils import Benchmark, OpType

device = "npu"


def set_seed(seed=42):
    """
    Fix all random seeds we use for reproducibility.
    """
    # Python random seed
    random.seed(seed)
    # Numpy random seed
    np.random.seed(0)
    # PyTorch random seed
    torch.manual_seed(seed)
    torch_npu.npu.manual_seed(seed)
    torch_npu.npu.manual_seed_all(seed)
    # Python hash seed
    os.environ["PYTHONHASHSEED"] = str(seed)


set_seed()


def _test_benchmark_once(target_ce, B, T, V, reduction, scalar, dtype):
    torch.manual_seed(0)
    torch_ce = CrossEntropyLoss_(reduction=reduction)

    _tensor = torch.randn(B * T, V, device=device, dtype=dtype) * scalar
    _input = _tensor.detach().clone().requires_grad_(True)
    _input2 = _tensor.detach().clone().requires_grad_(True)

    target = torch.randint(0, V, (B * T,), device=device, dtype=torch.long)

    def torch_fn():
        output = torch_ce(_input, target)
        output.backward(gradient=torch.ones_like(output))

    def triton_fn():
        output2 = target_ce(_input2, target)
        output2.backward(gradient=torch.ones_like(output2))

    benchmark = Benchmark(
        triton_op=lambda: triton_fn(),
        torch_op=lambda: torch_fn(),
        op_type=OpType.PURE_VECTOR,
    )
    benchmark.run()


@pytest.mark.xdist_group("benchmark")
@pytest.mark.parametrize(
    "B, T, V",
    [
        (2, 2048, 32000),  # llama
        (3, 423, 32000),  # weird shapes
    ],
)
@pytest.mark.parametrize(
    "reduction",
    [
        "sum",
        "mean",
        pytest.param("none", marks=pytest.mark.skip(reason="bad performance")),
    ],
)
@pytest.mark.parametrize(
    "scalar, dtype",
    [
        (1.0, torch.bfloat16),
        (1.0, torch.float32),
    ],
)
def test_benchmark(B, T, V, scalar, dtype, reduction):
    triton_ce = CrossEntropyLoss(reduction=reduction)
    _test_benchmark_once(triton_ce, B, T, V, reduction, scalar, dtype)
