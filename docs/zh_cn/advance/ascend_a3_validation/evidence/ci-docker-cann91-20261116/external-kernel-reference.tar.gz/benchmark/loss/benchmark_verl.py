# Copyright (c) Huawei Technologies Co., Ltd. 2025. All rights reserved.
# SPDX-FileCopyrightText: Copyright (c) 2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# Copyright 2024 Bytedance Ltd. and/or its affiliate
import os

import pytest
import torch

from benchmark.utils import Benchmark
from triton_ascend_kernels.loss.verl_linear_cross_entropy import linear_cross_entropy
from triton_ascend_kernels.loss.verl_cross_entropy_kernels import (
    run_triton_fwd_mainloop,
    run_epilogue_tp,
    run_epilogue_update,
)

MAX_TEST_CASES = int(os.environ.get("MAX_TEST_CASES", 5))

LINEAR_CE_CASES = [
    (1, 1937, 3584, 152064),
    (1, 2169, 896, 151936),
    (1, 1530, 2048, 32256),
    (1, 1388, 4096, 102400),
    (1, 8192, 4096, 102400),
][:MAX_TEST_CASES]


@pytest.mark.skipif(True, reason="Due to not enough memory, verl test skipped")
@pytest.mark.parametrize(
    "batch_size, num_tokens, hidden_size, vocab_size", LINEAR_CE_CASES
)
@pytest.mark.parametrize("dtype", [torch.bfloat16])
def test_benchmark_epilogue_fwd(
    batch_size: int,
    num_tokens: int,
    hidden_size: int,
    vocab_size: int,
    dtype,
):
    temperature = 1.5
    vocab_per_split = 1024
    num_splits = (vocab_size + vocab_per_split - 1) // vocab_per_split
    device = "npu"

    hidden = (
        torch.empty((num_tokens, hidden_size), dtype=dtype, device=device)
        .uniform_(-0.5, 0.5)
        .requires_grad_()
    )
    weight = (
        torch.empty((vocab_size, hidden_size), dtype=dtype, device=device)
        .uniform_(-0.5, 0.5)
        .requires_grad_()
    )
    labels = torch.randint(
        0, vocab_size, (num_tokens,), dtype=torch.int64, device=device
    )

    reduced_max = torch.empty((num_tokens, num_splits), dtype=dtype, device=device)
    original_max = torch.empty_like(reduced_max)
    accu = torch.empty_like(reduced_max)
    entropy_b_in = torch.empty_like(reduced_max)

    benchmark = Benchmark(
        triton_op=lambda: run_epilogue_tp(
            num_tokens, vocab_size, reduced_max, original_max, accu, entropy_b_in
        )
    )
    benchmark.run()


@pytest.mark.skipif(True, reason="Due to not enough memory, verl test skipped")
@pytest.mark.parametrize(
    "batch_size, num_tokens, hidden_size, vocab_size", LINEAR_CE_CASES
)
@pytest.mark.parametrize("dtype", [torch.bfloat16])
def test_benchmark_epilogue_update_fwd(
    batch_size: int,
    num_tokens: int,
    hidden_size: int,
    vocab_size: int,
    dtype,
):
    temperature = 1.5
    reduction = 0
    device = "npu"

    hidden = torch.randn((num_tokens, hidden_size), dtype=dtype, device=device)
    weight = torch.randn((vocab_size, hidden_size), dtype=dtype, device=device)
    labels = torch.randint(
        0, vocab_size, (num_tokens,), dtype=torch.int64, device=device
    )

    logits = (
        torch.matmul(hidden.to(torch.float32), weight.to(torch.float32).T) / temperature
    )
    max_val = logits.max(dim=-1).values
    exp_logits = torch.exp(logits - max_val.unsqueeze(-1))
    accu = exp_logits.sum(dim=-1)
    entropy_b = torch.sum(exp_logits * (logits - max_val.unsqueeze(-1)), dim=-1)
    logprobs = logits[torch.arange(num_tokens, device=device), labels]

    benchmark = Benchmark(
        triton_op=lambda: run_epilogue_update(
            num_tokens,
            vocab_size,
            logprobs,
            max_val,
            accu,
            entropy_b,
            reduction=reduction,
        )
    )
    benchmark.run()
