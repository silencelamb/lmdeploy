# Copyright © 2025 Huawei Technologies Co., Ltd.

import torch
import pytest
from triton_ascend_kernels.deterministic import linear_batch_invariant
from benchmark.utils import Benchmark, OpType


def linear_torch(x, y):
    K = x.shape[1]
    x1 = x[:, : K // 2]
    x2 = x[:, K // 2 :]
    y1 = y[:, : K // 2]
    y2 = y[:, K // 2 :]

    partial_result1 = torch.matmul(x1, y1.t())
    partial_result2 = torch.matmul(x2, y2.t())

    return partial_result1 + partial_result2


@pytest.mark.xdist_group("benchmark")
@pytest.mark.parametrize("M", [1])
@pytest.mark.parametrize("K", [1024])
@pytest.mark.parametrize("N", [151936])
def test_benchmark_mm_batch_invariant(
    M: int,
    K: int,
    N: int,
):

    torch.manual_seed(42)
    x = torch.randn(M, K, device="npu", dtype=torch.bfloat16)
    y = torch.randn(N, K, device="npu", dtype=torch.bfloat16)

    def torch_op():
        _ = linear_torch(x, y)

    def triton_op():
        _ = linear_batch_invariant(x, y, bias=None)

    benchmark = Benchmark(
        triton_op=triton_op,
        torch_op=torch_op,
        op_type=OpType.PURE_CUBE,
    )
    benchmark.run()
