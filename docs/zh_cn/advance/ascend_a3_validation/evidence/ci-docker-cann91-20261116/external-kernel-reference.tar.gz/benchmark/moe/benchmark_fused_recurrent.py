# Copyright © 2025 Huawei Technologies Co., Ltd.
# Copyright (c) 2023-2025, Songlin Yang, Yu Zhang
import torch
import pytest
import torch.nn.functional as F
from einops import repeat

from triton_ascend_kernels.moe import fused_recurrent_gated_delta_rule
from benchmark.utils import Benchmark, OpType


def recurrent_gated_delta_rule_ref(
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    beta: torch.Tensor,
    g: torch.Tensor,
    scale: float = None,
    initial_state: torch.Tensor = None,
    output_final_state: bool = False,
):
    q, k, v, beta, g = map(
        lambda x: x.transpose(1, 2).contiguous().to(torch.float32), [q, k, v, beta, g]
    )
    B, H, T, K, V = *k.shape, v.shape[-1]
    o = torch.zeros(B, H, T, V).to(v)
    h = torch.zeros(B, H, K, V).to(v)
    if initial_state is not None:
        h = initial_state
    if scale is None:
        scale = 1 / (q.shape[-1] ** 0.5)
    q = q * scale
    for i in range(T):
        b_q = q[:, :, i]
        b_k = k[:, :, i]
        b_v = v[:, :, i].clone()
        h = h.clone() * g[:, :, i].exp()[..., None, None]
        b_beta = beta[:, :, i]
        b_v = b_v - (h.clone() * b_k[..., None]).sum(-2)
        b_v = b_v * b_beta[..., None]
        h = h.clone() + b_k.unsqueeze(-1) * b_v.unsqueeze(-2)
        o[:, :, i] = torch.einsum("bhd,bhdm->bhm", b_q, h)
    if not output_final_state:
        h = None
    o = o.transpose(1, 2).contiguous()
    return o, h


@pytest.mark.parametrize(
    ("B", "T", "H", "HV", "D", "scale", "gate_logit_normalizer", "dtype"),
    [
        pytest.param(
            *test,
            id="B{}-T{}-H{}-HV{}-D{}-scale{}-gate_logit_normalizer{}-{}".format(*test)
        )
        for test in [
            (1, 63, 1, 1, 64, 1, 1, torch.float),
            (2, 1024, 4, 8, 128, 1, 10, torch.float16),
        ]
    ],
)
@pytest.mark.xdist_group("benchmark")
def test_benchmark_fused_recurrent(
    B: int,
    T: int,
    H: int,
    HV: int,
    D: int,
    scale: float,
    gate_logit_normalizer: float,
    dtype: torch.dtype,
):
    device = "npu"
    torch.manual_seed(42)
    q = torch.randn(B, T, H, D, dtype=torch.float32)
    k = torch.randn(B, T, H, D, dtype=torch.float32)
    v = torch.randn(B, T, HV, D, dtype=dtype)
    beta = torch.rand(B, T, HV, dtype=dtype).sigmoid()
    g = F.logsigmoid(torch.rand(B, T, HV, dtype=torch.float32))
    g = g / gate_logit_normalizer
    h0 = torch.randn(B, HV, D, D, dtype=torch.float32)
    q, k, v, beta, g, h0 = map(
        lambda x: x.to(device).requires_grad_(), (q, k, v, beta, g, h0)
    )

    def torch_op():
        _, _ = recurrent_gated_delta_rule_ref(
            q=F.normalize(
                repeat(q.clone(), "b t h d -> b t (h g) d", g=HV // H), p=2, dim=-1
            ).to(dtype),
            k=F.normalize(
                repeat(k.clone(), "b t h d -> b t (h g) d", g=HV // H), p=2, dim=-1
            ).to(dtype),
            v=v.clone(),
            beta=beta.clone(),
            g=g.clone(),
            scale=scale,
            initial_state=h0.clone(),
            output_final_state=True,
        )

    def triton_op():
        _, _ = fused_recurrent_gated_delta_rule(
            q=q.clone(),
            k=k.clone(),
            v=v.clone(),
            beta=beta.clone(),
            g=g.clone(),
            scale=scale,
            initial_state=h0.clone(),
            inplace_final_state=False,
            use_qk_l2norm_in_kernel=True,
        )

    benchmark = Benchmark(
        triton_op=triton_op,
        torch_op=torch_op,
        op_type=OpType.PURE_VECTOR,
    )
    benchmark.run()
