#! /bin/bash
# Copyright © 2025 Huawei Technologies Co., Ltd.

PROJECT_DIR=$(dirname "$0")
cd "${PROJECT_DIR}"

CI_MODE=false

function init_env()
{
    # Setup CANN environment
    if [[ -z "${ASCEND_HOME_PATH}" ]]; then
        echo "ASCEND_HOME_PATH is not set, try to source from default path."
        source /usr/local/Ascend/ascend-toolkit/set_env.sh
    fi

    # Install dependencies
    pip install -e .'[dev]'

    # In CI mode, use specific version of bishengir
    if [[ "${CI_MODE}" == true ]]; then
        export PATH=/usr/local/Ascend/8.5.0/compiler/bishengir/bin:$PATH
    fi
}

function build_package()
{
    pip install build
    python3 -m build
}

function run_tests()
{
    if [[ "${CI_MODE}" == true ]]; then
        BASE_BRANCH=$(git show-branch -a \
            | grep '*' \
            | grep -v "$(git rev-parse --abbrev-ref HEAD)" \
            | head -n1 \
            | sed 's/.*\[\(.*\)\].*/\1/' \
            | sed 's/[\^~].*//')

        # Fallback to master if BASE_BRANCH detection fails
        if [[ -z "${BASE_BRANCH}" ]]; then
            echo "Warning: Could not detect base branch, defaulting to 'master'"
            BASE_BRANCH="master"
        fi

        DIR_LIST=$(git diff --name-only HEAD "${BASE_BRANCH}" \
            | grep -E '^(benchmark|src|tests)/|^(build\.sh|pyproject\.toml)$' \
            | xargs -r dirname \
            | xargs -r -n1 basename \
            | sort -u)

        if [[ -z "${DIR_LIST}" ]]; then
            echo "No file changed, skipping tests"
        elif grep -qx '\.' <<< "${DIR_LIST}"; then
            echo "Root directory changed, running all tests"
            python3.10 -m pytest -n 16 --dist loadgroup
        else
            while IFS= read -r dir; do
                echo "Running tests for ${dir}"
                python3.10 -m pytest "tests/${dir}" "benchmark/${dir}" -n 16 --dist loadgroup
            done <<< "${DIR_LIST}"
        fi
    else
        pytest -n 16 --dist loadgroup
    fi
}

function clean_up()
{
    rm -rf dist/
    rm -rf build/
    rm -rf triton_ascend_kernels.egg-info/
}

function show_usage()
{
    echo "Usage: $0 <command> [-ci]"
    echo ""
    echo "Options:"
    echo "  -ci      CI mode: uninstall triton_ascend if installed during init"
    echo ""
    echo "Commands:"
    echo "  build    Initialize environment, clean up, and build package"
    echo "  test     Initialize environment and run tests"
    echo ""
}

function do_build()
{
    clean_up
    build_package
}

function do_test()
{
    init_env
    run_tests
}

function main()
{
    if [[ $# -eq 0 ]]; then
        show_usage
        exit 1
    fi

    # Parse command
    local cmd="$1"
    shift

    # Parse optional flags
    while [[ $# -gt 0 ]]; do
        case "$1" in
            -ci)
                CI_MODE=true
                shift
                ;;
            *)
                echo "Error: Unknown option '$1'"
                show_usage
                exit 1
                ;;
        esac
    done

    case "${cmd}" in
        build)
            do_build
            ;;
        test)
            do_test
            ;;
        *)
            echo "Error: Unknown command '${cmd}'"
            show_usage
            exit 1
            ;;
    esac
}

main "$@"
