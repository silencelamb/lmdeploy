# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
# Copyright © 2026 Huawei Technologies Co., Ltd.
import torch
import triton
import triton.language as tl
from triton_ascend_kernels.utils import get_npu_vectorcore_num


@triton.jit
def _log_softmax_kernel(
    input_ptr,
    output_ptr,
    input_row_stride,
    output_row_stride,
    n_rows,
    n_cols,
    BLOCK_SIZE: tl.constexpr,
):
    """
    Compute log_softmax along the last dimension of a 2D tensor.
    Each block handles multiple rows due to fixed grid size.
    """
    # Get the block index
    pid = tl.program_id(0)
    num_blocks = tl.num_programs(0)

    # Calculate the range of rows this block should handle
    rows_per_block = (n_rows + num_blocks - 1) // num_blocks
    start_row = pid * rows_per_block
    end_row = tl.minimum((pid + 1) * rows_per_block, n_rows)

    # Loop over the rows assigned to this block
    for row_idx in range(start_row, end_row):
        # Compute base pointers for input and output rows
        row_start_ptr = input_ptr + row_idx * input_row_stride
        output_row_start_ptr = output_ptr + row_idx * output_row_stride

        # Step 1: Find maximum value in the row for numerical stability
        max_val = -float("inf")
        for col_offset in range(0, n_cols, BLOCK_SIZE):
            col_idx = col_offset + tl.arange(0, BLOCK_SIZE)
            mask = col_idx < n_cols

            # Load values
            vals = tl.load(row_start_ptr + col_idx, mask=mask, other=-float("inf"))

            # Update maximum
            max_val = tl.max(tl.maximum(vals, max_val))

        # Step 2: Compute sum of exp(x - max_val)
        sum_exp = 0.0
        for col_offset in range(0, n_cols, BLOCK_SIZE):
            col_idx = col_offset + tl.arange(0, BLOCK_SIZE)
            mask = col_idx < n_cols

            # Load values
            vals = tl.load(row_start_ptr + col_idx, mask=mask, other=0.0)

            # Compute exp(x - max_val) and accumulate
            exp_vals = tl.exp(vals - max_val)
            sum_exp += tl.sum(tl.where(mask, exp_vals, 0.0))

        # Compute log(sum_exp)
        log_sum_exp = tl.log(sum_exp)

        # Step 3: Compute final log_softmax values: x - max_val - log_sum_exp
        for col_offset in range(0, n_cols, BLOCK_SIZE):
            col_idx = col_offset + tl.arange(0, BLOCK_SIZE)
            mask = col_idx < n_cols

            # Load values
            vals = tl.load(row_start_ptr + col_idx, mask=mask)

            # Compute log_softmax
            output_vals = vals - max_val - log_sum_exp

            # Store results
            tl.store(output_row_start_ptr + col_idx, output_vals, mask=mask)


def log_softmax_batch_invariant(input_x: torch.Tensor, dim: int = -1) -> torch.Tensor:
    """
    Compute log_softmax using Triton kernel with fixed grid size.

    Args:
        input_x: Input tensor
        dim: Dimension along which to compute log_softmax
             (only -1 or last dim supported)

    Returns:
        Tensor with log_softmax applied along the specified dimension
    """
    if dim != -1 and dim != input_x.ndim - 1:
        raise ValueError(
            "This implementation only supports log_softmax along the last dimension"
        )

    # Flatten all dimensions except the last one
    original_shape = input_x.shape
    input_2d = input_x.reshape(-1, input_x.shape[-1])
    input_2d = input_2d.contiguous()

    n_rows, n_cols = input_2d.shape

    # Allocate output tensor
    output = torch.empty_like(input_2d)

    # Choose block size based on the number of columns
    BLOCK_SIZE = 2048

    # Fixed grid size
    grid = (get_npu_vectorcore_num(),)

    # Launch kernel with fixed grid
    _log_softmax_kernel[grid](
        input_2d,
        output,
        input_2d.stride(0),
        output.stride(0),
        n_rows,
        n_cols,
        BLOCK_SIZE=BLOCK_SIZE,
    )

    # Reshape output back to original shape
    return output.reshape(original_shape)
