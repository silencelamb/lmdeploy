# Copyright © 2025 Huawei Technologies Co., Ltd.
# Copyright contributors to the vLLM project
# Copyright (c) 2024, Tri Dao.
import torch
import triton
import triton.language as tl
import triton.language.extra.cann.extension as tle

PAD_SLOT_ID = -1


@triton.jit()
def _causal_conv1d_update_kernel_no_cache_len_no_mtp(
    x_ptr,
    conv_state_ptr,
    weight_ptr,
    bias_ptr,
    conv_state_indices_ptr,
    out_ptr,
    pad_slot_id,
    batch: tl.constexpr,
    dim: tl.constexpr,
    align_val: tl.constexpr,
    state_len: tl.constexpr,  # 3 4 5
    seq_len: tl.constexpr,  # 1 2
    width: tl.constexpr,  # 4, <= seq_len + state_len
    out_len: tl.constexpr,
    x_batch_stride: tl.constexpr,
    conv_batch_stride: tl.constexpr,
    out_batch_stride: tl.constexpr,
    DIM_BLOCK: tl.constexpr,  # dim % DIM_BLOCK must be 0
    HAS_BIAS: tl.constexpr,
    SILU_ACTIVATION: tl.constexpr,
    IS_CONTINUOUS_BATCHING: tl.constexpr,
    USE_PAD_SLOT: tl.constexpr,
):
    pid = tl.program_id(0)
    cat_len: tl.constexpr = state_len + seq_len  # 4
    sub_state_len: tl.constexpr = state_len - seq_len  # 3
    sub_align_dim: tl.constexpr = DIM_BLOCK // align_val

    conv_begin: tl.constexpr = (cat_len - width + 1) - seq_len

    if IS_CONTINUOUS_BATCHING:
        conv_batch_offs = tl.load(conv_state_indices_ptr + pid)
    else:
        conv_batch_offs = pid

    if USE_PAD_SLOT:
        if conv_batch_offs == pad_slot_id:
            # not processing as this is not the actual sequence
            return

    for doffs in range(0, dim, DIM_BLOCK):

        conv_state = tl.load(
            conv_state_ptr
            + conv_batch_offs * conv_batch_stride
            + doffs * state_len
            + tl.arange(0, DIM_BLOCK * state_len)
        )
        conv_state_T = (
            conv_state.reshape(sub_align_dim, align_val * state_len)
            .trans()
            .reshape(align_val, state_len * sub_align_dim)
            .trans()
            .reshape(
                state_len * DIM_BLOCK,
            )
        )

        x = tl.load(
            x_ptr
            + pid * x_batch_stride
            + doffs * seq_len
            + tl.arange(0, DIM_BLOCK * seq_len)
        )
        x_T = (
            x.reshape(sub_align_dim, align_val * seq_len)
            .trans()
            .reshape(align_val, seq_len * sub_align_dim)
            .trans()
            .reshape(
                seq_len * DIM_BLOCK,
            )
        )

        x_new_T = tl.full([cat_len * DIM_BLOCK], 0, x_ptr.dtype.element_ty)
        x_new_T = tle.insert_slice(
            x_new_T,
            conv_state_T,
            offsets=(0,),
            sizes=(state_len * DIM_BLOCK,),
            strides=(1,),
        )  # [cat_len , DIM_BLOCK].view(-1)
        x_new_T = tle.insert_slice(
            x_new_T,
            x_T,
            offsets=(state_len * DIM_BLOCK,),
            sizes=(seq_len * DIM_BLOCK,),
            strides=(1,),
        )

        new_conv_state_T = tle.extract_slice(
            x_new_T, (seq_len * DIM_BLOCK,), (state_len * DIM_BLOCK,), (1,)
        )  # [state_len, DIM_BLOCK].view(-1)
        new_conv_state = (
            new_conv_state_T.reshape(state_len * align_val, sub_align_dim)
            .trans()
            .reshape(sub_align_dim * state_len, align_val)
            .trans()
            .reshape(
                DIM_BLOCK * state_len,
            )
        )  # [DIM_BLOCK, state_len].view(-1)
        tl.store(
            conv_state_ptr
            + conv_batch_offs * conv_batch_stride
            + doffs * state_len
            + tl.arange(0, DIM_BLOCK * state_len),
            new_conv_state,
        )

        weight = tl.load(weight_ptr + doffs * width + tl.arange(0, DIM_BLOCK * width))
        weight_T = (
            weight.reshape(sub_align_dim, align_val * width)
            .trans()
            .reshape(align_val, width * sub_align_dim)
            .trans()
            .reshape(
                width * DIM_BLOCK,
            )
        )  # [width, DIM_BLOCK].view(-1)

        if HAS_BIAS:
            bias = tl.load(bias_ptr + doffs + tl.arange(0, DIM_BLOCK))
        else:
            bias = 0

        if width == cat_len:
            result = (
                tl.sum((x_new_T.to(tl.float32) * weight_T).reshape(width, DIM_BLOCK), 0)
                + bias
            )
            if SILU_ACTIVATION:
                result = result / (1 + tl.exp(-result))
            tl.store(
                out_ptr
                + pid * out_batch_stride
                + (doffs + tl.arange(0, DIM_BLOCK)) * out_len,
                result,
            )
        else:
            for i in range(seq_len):
                x_conv_part = tle.extract_slice(
                    x_new_T, ((conv_begin + i) * DIM_BLOCK), (width * DIM_BLOCK), (1,)
                ).to(tl.float32)
                result = (
                    tl.sum((x_conv_part * weight_T).reshape(width, DIM_BLOCK), 0) + bias
                )
                if SILU_ACTIVATION:
                    result = result / (1 + tl.exp(-result))
                tl.store(
                    out_ptr
                    + pid * out_batch_stride
                    + (doffs + tl.arange(0, DIM_BLOCK)) * out_len,
                    result,
                )


def causal_conv1d_update(
    x: torch.Tensor,
    conv_state: torch.Tensor,
    weight: torch.Tensor,
    bias: torch.Tensor | None = None,
    activation: bool | str | None = None,
    conv_state_indices: torch.Tensor | None = None,
    num_accepted_tokens: torch.Tensor | None = None,
    pad_slot_id: int = PAD_SLOT_ID,
    validate_data=False,
):
    """
    x: Input tensor which can take the following shapes:

    - `[batch, dim]` - single token prediction
    - `[batch, dim, seqlen]` - single or multiple tokens prediction
    - `[num_tokens, dim]` - continuous batching, where num_tokens is
        the total tokens of all sequences in that batch

    conv_state: (..., dim, state_len), where state_len >= width - 1
    weight: (dim, width)
    bias: (dim,)
    conv_state_indices: (batch,), dtype int32
        If not None, the conv_state is a larger tensor along the batch dim,
        and we are selecting the batch coords specified by conv_state_indices.
        Useful for a continuous batching scenario.
    num_accepted_tokens: (batch,), dtype int32
        If not None, it indicates the number of accepted tokens for each
        sequence in the batch.
        This is used in speculative decoding, where the conv_state is updated
        in a sliding window manner.
    pad_slot_id: int
            if conv_state_indices is passed, lets the kernel identify padded
            entries that will not be processed,
            for example: conv_state_indices = [pad_slot_id, 1 ,20 ,pad_slot_id]
            in this case, the kernel will not process entries at
            indices 0 and 3
    out: (batch, dim) or (batch, dim, seqlen) or (num_tokens, dim), same shape as `x`
    """
    if validate_data:
        assert pad_slot_id is not None
        assert x.stride(1) == 1
    if isinstance(activation, bool):
        activation = "silu" if activation is True else None
    elif activation is not None:
        assert activation in ["silu", "swish"]

    original_x_dtype = x.dtype
    x = x.to(conv_state.dtype)
    unsqueeze = x.dim() == 2
    if unsqueeze:
        # make it (batch, dim, seqlen) with seqlen == 1
        x = x.unsqueeze(-1)
    batch, dim, seqlen = x.shape
    _, width = weight.shape
    # conv_state: (..., dim, state_len), where state_len >= width - 1
    num_cache_lines, _, state_len = conv_state.size()

    if validate_data:
        assert dim == weight.size(0)
        assert (
            conv_state.stride(-2) == 1
        ), f"ERROR: expect contiguous along feat-dim of conv_state (currently stride={conv_state.stride()})"
        assert state_len >= width - 1
        # when above happens, we don't shift-left to keep any records in conv_state
        assert dim == conv_state.size(1)
        if conv_state_indices is None:
            assert conv_state.size(0) >= batch
        else:
            assert (batch,) == conv_state_indices.shape

        assert num_cache_lines >= batch
        assert weight.stride(1) == 1  # Need this

    # adopt the strategy in vLLM that overwrite on 'x' directly, rather than creating a new tensor 'o'
    out = x

    if num_accepted_tokens is None:
        DIM_BLOCK = dim & -dim
        DIM_BLOCK_THD = 2048 if DIM_BLOCK <= 2048 else 1024
        while DIM_BLOCK > DIM_BLOCK_THD:
            DIM_BLOCK = DIM_BLOCK // 2
        _causal_conv1d_update_kernel_no_cache_len_no_mtp[(batch, 1, 1)](
            x,
            conv_state,
            weight,
            bias,
            conv_state_indices,
            out,
            pad_slot_id,
            batch=batch,
            dim=dim,
            align_val=16,
            state_len=conv_state.shape[-1],  # 3 4 5
            seq_len=x.shape[-1],  # 1 2
            width=width,  # 4, <= seq_len + state_len
            out_len=out.shape[-1],
            x_batch_stride=x.stride()[0],
            conv_batch_stride=conv_state.stride()[0],
            out_batch_stride=out.stride()[0],
            DIM_BLOCK=DIM_BLOCK,  # dim % DIM_BLOCK must be 0
            HAS_BIAS=bias is not None,
            SILU_ACTIVATION=activation in ["silu", "swish"],
            IS_CONTINUOUS_BATCHING=conv_state_indices is not None,
            USE_PAD_SLOT=pad_slot_id is not None,
        )
    else:
        raise NotImplementedError("Currently only support num_accepted_tokens is None")

    if unsqueeze:
        out = out.squeeze(-1)
    return out.to(original_x_dtype)
