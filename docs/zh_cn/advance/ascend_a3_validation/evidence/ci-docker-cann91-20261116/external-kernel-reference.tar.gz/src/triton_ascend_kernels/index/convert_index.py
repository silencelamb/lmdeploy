# Copyright © 2025 Huawei Technologies Co., Ltd.
# Copyright contributors to the vLLM project
import torch
import numpy as np

import triton
import triton.language as tl

from triton_ascend_kernels.utils import get_npu_vectorcore_num


# Kernel with prefill workspace support
@triton.jit
def _convert_req_index_to_global_index_kernel(
    req_id_ptr,  # int32 [num_tokens]
    block_table_ptr,  # int32 [num_requests, max_num_blocks_per_req]
    token_indices_ptr,  # int32 [num_tokens, NUM_TOPK_TOKENS]
    out_ptr,  # int32 [num_tokens, NUM_TOPK_TOKENS]
    prefill_request_id_ptr,  # int32 [num_tokens], -1 for decode, >=0 for prefill
    workspace_starts_ptr,  # int32 [num_prefill_reqs+1] or nullptr
    # shapes (compile-time where possible)
    max_num_blocks_per_req: tl.constexpr,
    rows_per_prog: tl.constexpr,
    tiles_per_row: tl.constexpr,
    num_tokens: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
    BLOCK_N: tl.constexpr,  # tile width along columns
    HAS_PREFILL: tl.constexpr,
    # strides (in elements)
    bt_stride0,
    bt_stride1,
    ti_stride0,
    ti_stride1,
    out_stride0,
    out_stride1,
):
    # program_id(0) -> token_id (row)
    row_blk_id = tl.program_id(0)

    for row_id in range(0, rows_per_prog):
        token_id = row_blk_id * rows_per_prog + row_id
        if token_id < num_tokens:
            # Load request id for this token (no mask: grid is exact)
            req = tl.load(req_id_ptr + token_id)

            is_prefill = False
            if HAS_PREFILL:
                prefill_req_id = tl.load(prefill_request_id_ptr + token_id)
                is_prefill = prefill_req_id.to(tl.float32) >= 0
                workspace_start = tl.load(
                    workspace_starts_ptr + prefill_req_id, mask=is_prefill, other=0
                )

            # tile index along columns
            for tile_id in range(0, tiles_per_row):
                # Each program covers BLOCK_N consecutive columns
                indice_id = tile_id * BLOCK_N + tl.arange(0, BLOCK_N)

                # Load token indices for this tile
                ti_ptr = (
                    token_indices_ptr + token_id * ti_stride0 + indice_id * ti_stride1
                )
                tok = tl.load(ti_ptr)  # int32

                # Only token == -1 should propagate as -1
                is_invalid_tok = tok.to(tl.float32) < 0

                # Compute block id and in-block offset
                block_id = tok // BLOCK_SIZE
                inblock_off = tok % BLOCK_SIZE

                # Guard block_table access
                valid_block = (block_id < max_num_blocks_per_req) & (block_id >= 0)
                bt_ptr = block_table_ptr + req * bt_stride0 + block_id * bt_stride1
                is_invalid_tok |= ~valid_block
                base = tl.load(bt_ptr, mask=valid_block & (not is_prefill), other=0)
                out_val = base * BLOCK_SIZE + inblock_off

                # Override with prefill output if prefill is enabled
                if HAS_PREFILL:
                    prefill_out = workspace_start + tok
                    out_val = tl.where(is_prefill, prefill_out, out_val)
                out_val = tl.where(is_invalid_tok, -1, out_val)

                # Store results
                out_ptr_ij = out_ptr + token_id * out_stride0 + indice_id * out_stride1
                tl.store(out_ptr_ij, out_val)


def triton_convert_req_index_to_global_index(
    req_id: torch.Tensor,  # int32 [num_tokens]
    block_table: torch.Tensor,  # int32 [num_requests, max_num_blocks_per_req]
    token_indices: torch.Tensor,  # int32 [num_tokens, NUM_TOPK_TOKENS]
    BLOCK_SIZE: int = 64,
    NUM_TOPK_TOKENS: int = 2048,
    BLOCK_N: int = 128,  # tile width along columns
    HAS_PREFILL_WORKSPACE: bool = False,
    prefill_workspace_request_ids: torch.Tensor | None = None,
    prefill_workspace_starts: torch.Tensor | None = None,
):
    """
    out[token_id, indice_id] =
        block_table[req_id[token_id],
            token_indices[token_id, indice_id] // BLOCK_SIZE] * BLOCK_SIZE
        + token_indices[token_id, indice_id] % BLOCK_SIZE

    Only when token_indices[token_id, indice_id] == -1 do we output -1.
    For safety, we also output -1 if the derived block_id would be
        out-of-bounds.

    When HAS_PREFILL_WORKSPACE is True, prefill tokens are mapped to workspace offsets
    instead of global cache slots. prefill_workspace_request_ids and
    prefill_workspace_starts must be provided.

    prefill_workspace_request_ids: int32 [num_tokens], -1 for decode else
        prefill request index (maps to prefill_workspace_starts)
    prefill_workspace_starts: int32 [num_prefills], 0-indexed workspace
        starts for each prefill request
    """
    assert req_id.dtype == torch.int32
    assert block_table.dtype == torch.int32
    assert token_indices.dtype == torch.int32
    assert token_indices.shape[1] == NUM_TOPK_TOKENS
    assert (
        NUM_TOPK_TOKENS % BLOCK_N == 0
    ), f"NUM_TOPK_TOKENS ({NUM_TOPK_TOKENS}) must be divisible by BLOCK_N ({BLOCK_N})"

    if HAS_PREFILL_WORKSPACE:
        assert prefill_workspace_request_ids is not None
        assert prefill_workspace_starts is not None
        assert prefill_workspace_request_ids.dtype == torch.int32
        assert prefill_workspace_starts.dtype == torch.int32

    num_tokens = req_id.shape[0]
    max_num_blocks_per_req = block_table.shape[1]
    tiles_per_row = NUM_TOPK_TOKENS // BLOCK_N

    # Ensure contiguous tensors on the same device
    req_id_c = req_id.contiguous()
    block_table_c = block_table.contiguous()
    token_indices_c = token_indices.contiguous()
    out = torch.empty_like(token_indices_c)

    # Strides in elements
    bt_stride0, bt_stride1 = block_table_c.stride()
    ti_stride0, ti_stride1 = token_indices_c.stride()
    out_stride0, out_stride1 = out.stride()

    # Prepare prefill pointers
    if HAS_PREFILL_WORKSPACE:
        assert prefill_workspace_request_ids is not None  # for mypy
        assert prefill_workspace_starts is not None  # for mypy
        assert prefill_workspace_request_ids.is_contiguous()
        assert prefill_workspace_starts.is_contiguous()

    # Exact 2D grid: tokens × column tiles

    core_num = get_npu_vectorcore_num()

    rows_per_prog = triton.cdiv(num_tokens, core_num)

    grid = (core_num,)

    _convert_req_index_to_global_index_kernel[grid](
        req_id_c,
        block_table_c,
        token_indices_c,
        out,
        prefill_workspace_request_ids,
        prefill_workspace_starts,
        # shapes / constexprs
        max_num_blocks_per_req,
        rows_per_prog,
        tiles_per_row,
        num_tokens,
        BLOCK_SIZE,
        BLOCK_N,
        HAS_PREFILL_WORKSPACE,
        # strides
        bt_stride0,
        bt_stride1,
        ti_stride0,
        ti_stride1,
        out_stride0,
        out_stride1,
    )
    return out
