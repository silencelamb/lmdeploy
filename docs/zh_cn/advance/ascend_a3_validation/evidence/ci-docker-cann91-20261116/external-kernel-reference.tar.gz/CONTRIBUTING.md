# 贡献指南

本项目欢迎广大开发者体验并参与贡献。在参与社区贡献之前，请参考[Ascend社区协作指南](https://gitcode.com/Ascend/community/blob/master/docs/role-guidance.md)了解行为准则，进行CLA协议签署，了解贡献流程。

## 环境配置
基于Ascend平台开发triton算子时，需配置triton-ascend的开发环境。请参考[triton-ascend安装指南](https://gitcode.com/Ascend/triton-ascend/blob/master/docs/sources/getting-started/installation.md)安装triton-ascend及对应的依赖软件包。

## 代码开发

添加新 Kernel：
- 添加新的Kernel实现到 `src/triton_ascend_kernels/`，依据Kernel属性分类存放。
- 添加单元测试用例到 `tests/`目录下，依据Kernel属性分类存放， 注意，测试用例文件名需以`test_`开头，测试函数名需以`test_accuracy_`开头。
- 添加性能测试用例到 `benchmark/`目录下， 依据Kernel属性分类存放，注意，测试用例文件名需以`benchmark_`开头，测试函数名需以`test_benchmark_`开头。

## 编译构建

在项目根目录下执行以下命令构建whl包：
```shell
bash build.sh build
```

## 测试验证

在项目根目录下执行以下命令进行测试验证：

```shell
# 执行全量测试用例（涵盖tests目录和benchmark目录下的全部用例）
bash build.sh test
# 执行单个测试用例（以tests/gemm/test_matmul.py为例）
pytest tests/gemm/test_matmmul.py
```

### 性能要求
benchmark 对应用例所有 shape 要求通过， 算子代码要求修改为昇腾亲和适配后的代码且性能要求达标再上库，以下性能标准二选一：
- 有对标的AscendC算子实现的：纯cube/纯vector：0.9x AscendC，CV类：0.7x AscendC
- 无对标的AscendC算子实现的：优于小算子拼接实现

在提交benchmark用例时需要遵循以下步骤(以matmul为例)：
- 在benchmark文件夹内相应算子类别目录下创建性能测试脚本，脚本名以`benchmark_`开头，如`benchmark_matmul.py`，测试函数名以`test_benchmark_`开头，如`test_benchmark_matmul()`
- 因msprof要求单卡上只能有一个算子性能采集程序，故对测试函数固定使用pytest标记`@pytest.mark.xdist_group("benchmark")`，使benchmark用例串行执行
- 在`benchmark_matmul.py`内导入依赖`from benchmark.utils import Benckmark, OpType`
- 构造需要的input tensors后，创建Benchmark对象并以lambda表达式的方法传入torch_op和triton_op以及op_type
  - 如：`benchmark = Benchmark(
        triton_op=lambda: matmul(mat_a, mat_b), # mat_a, mat_b 为输入矩阵
        torch_op=lambda: torch.matmul(mat_a, mat_b),
        op_type=OpType.PURE_CUBE,
    )`
- 执行 `benchmark.run()`

注：OpType对照上述性能标准：
- OpType.PURE_CUBE为纯cube类算子
- OpType.PURE_VECTOR为纯vector类算子
- OpType.CV为cv融合类算子
- OpType.OTHER为无对标AscendC算子实现的小算子拼接算子


## PR提交
### pre-commit
提交代码前，使用 pre-commit 工具在执行`git commit`前自动运行一系列检查或格式化操作，以保证代码质量、一致性和规范性。
```
pip install pre-commit
pre-commit run --all-files
```
