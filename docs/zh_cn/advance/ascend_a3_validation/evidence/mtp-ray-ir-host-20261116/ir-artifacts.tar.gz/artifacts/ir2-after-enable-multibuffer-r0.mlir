#map = affine_map<()[s0, s1, s2] -> (((s0 - s1) floordiv s2) mod 2)>
#map1 = affine_map<()[s0] -> (s0 + 1)>
#map2 = affine_map<()[s0, s1, s2, s3] -> (s0 + s1 + s2 + s3 * 128)>
#map3 = affine_map<()[s0] -> (128, s0)>
#map4 = affine_map<()[s0, s1] -> (s1 + 32, s0)>
#map5 = affine_map<()[s0, s1] -> (s0 - s1)>
#map6 = affine_map<()[s0, s1] -> (s1 + 128, s0)>
#map7 = affine_map<()[s0, s1] -> (32, s0 - s1)>
#map8 = affine_map<()[s0] -> (0, s0)>
#map9 = affine_map<()[s0, s1] -> (128, s0 - s1)>
#map10 = affine_map<()[s0, s1, s2, s3, s4, s5, s6] -> (((s0 - s1) floordiv s3 + ((s4 - s5) floordiv s6) * ((-s1 + s2 + s3 - 1) floordiv s3)) mod 2)>
#map11 = affine_map<()[s0, s1] -> (s0 + s1)>
#map12 = affine_map<()[s0] -> (s0 + 1024)>
#map13 = affine_map<()[s0] -> (s0 + 2048)>
module {
  func.func @fused_recurrent_gated_delta_rule_fwd_kernel(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xbf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg4: memref<?xbf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg5: memref<?xbf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg6: memref<?xf32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg7: memref<?xbf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg8: memref<?xbf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 1 : i32}, %arg9: memref<?xf32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg10: memref<?xf32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 1 : i32}, %arg11: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg12: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg13: memref<?xi64, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg14: f32, %arg15: i64, %arg16: i64, %arg17: i32, %arg18: i32, %arg19: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, func_dyn_memref_args = dense<[false, true, true, true, true, true, true, true, true, true, true, true, true, true, false, false, false, false, false, false]> : vector<20xi1>, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.storage_aligned, mix_mode = "aiv", parallel_mode = "simd"} {
    %c48 = arith.constant 48 : index
    %c1 = arith.constant 1 : index
    %c48_i32 = arith.constant 48 : i32
    %cst = arith.constant 0.000000e+00 : bf16
    %c32 = arith.constant 32 : index
    %c128 = arith.constant 128 : index
    %cst_0 = arith.constant 0.000000e+00 : f32
    %c16384_i32 = arith.constant 16384 : i32
    %c1_i64 = arith.constant 1 : i64
    %c262144_i64 = arith.constant 262144 : i64
    %c4_i64 = arith.constant 4 : i64
    %c16_i64 = arith.constant 16 : i64
    %c128_i64 = arith.constant 128 : i64
    %c8_i64 = arith.constant 8 : i64
    %c32_i32 = arith.constant 32 : i32
    %c128_i32 = arith.constant 128 : i32
    %c2_i32 = arith.constant 2 : i32
    %c16_i32 = arith.constant 16 : i32
    %c0 = arith.constant 0 : index
    %cst_1 = arith.constant 9.99999997E-7 : f32
    %c256_i64 = arith.constant 256 : i64
    %c1024_i64 = arith.constant 1024 : i64
    %c1600_i64 = arith.constant 1600 : i64
    %c1728_i64 = arith.constant 1728 : i64
    %c2240_i64 = arith.constant 2240 : i64
    %c2272_i64 = arith.constant 2272 : i64
    %c2528_i64 = arith.constant 2528 : i64
    %c2560_i64 = arith.constant 2560 : i64
    %c3072_i64 = arith.constant 3072 : i64
    %c3104_i64 = arith.constant 3104 : i64
    %c3360_i64 = arith.constant 3360 : i64
    %c3392_i64 = arith.constant 3392 : i64
    %c3424_i64 = arith.constant 3424 : i64
    %c19808_i64 = arith.constant 19808 : i64
    %c36192_i64 = arith.constant 36192 : i64
    %c36320_i64 = arith.constant 36320 : i64
    %c44512_i64 = arith.constant 44512 : i64
    %c44544_i64 = arith.constant 44544 : i64
    %c44576_i64 = arith.constant 44576 : i64
    %c60960_i64 = arith.constant 60960 : i64
    %c78368_i64 = arith.constant 78368 : i64
    %c94880_i64 = arith.constant 94880 : i64
    %c2_i64 = arith.constant 2 : i64
    %c103072_i64 = arith.constant 103072 : i64
    %c0_i64 = arith.constant 0 : i64
    %c103328_i64 = arith.constant 103328 : i64
    %c768_i64 = arith.constant 768 : i64
    %c103584_i64 = arith.constant 103584 : i64
    %c1536_i64 = arith.constant 1536 : i64
    %c120032_i64 = arith.constant 120032 : i64
    %c94752_i64 = arith.constant 94752 : i64
    %c61984_i64 = arith.constant 61984 : i64
    %c103648_i64 = arith.constant 103648 : i64
    %0 = hivm.hir.pointer_cast(%c61984_i64) : memref<32x128xf32, #hivm.address_space<ub>>
    annotation.mark %0 {hivm.multi_buffer = 2 : i32} : memref<32x128xf32, #hivm.address_space<ub>>
    %1 = hivm.hir.pointer_cast(%c103648_i64) : memref<32x128xf32, #hivm.address_space<ub>>
    annotation.mark %1 {hivm.multi_buffer = 2 : i32} : memref<32x128xf32, #hivm.address_space<ub>>
    %2 = hivm.hir.pointer_cast(%c94752_i64) : memref<32xbf16, #hivm.address_space<ub>>
    annotation.mark %2 {hivm.multi_buffer = 2 : i32} : memref<32xbf16, #hivm.address_space<ub>>
    %3 = hivm.hir.pointer_cast(%c120032_i64) : memref<32xbf16, #hivm.address_space<ub>>
    annotation.mark %3 {hivm.multi_buffer = 2 : i32} : memref<32xbf16, #hivm.address_space<ub>>
    %4 = hivm.hir.pointer_cast(%c61984_i64) : memref<32x128xf32, #hivm.address_space<ub>>
    annotation.mark %4 {hivm.multi_buffer = 2 : i32} : memref<32x128xf32, #hivm.address_space<ub>>
    %5 = hivm.hir.pointer_cast(%c103648_i64) : memref<32x128xf32, #hivm.address_space<ub>>
    annotation.mark %5 {hivm.multi_buffer = 2 : i32} : memref<32x128xf32, #hivm.address_space<ub>>
    %6 = hivm.hir.pointer_cast(%c1536_i64) : memref<32xbf16, #hivm.address_space<ub>>
    annotation.mark %6 {hivm.multi_buffer = 2 : i32} : memref<32xbf16, #hivm.address_space<ub>>
    %7 = hivm.hir.pointer_cast(%c103584_i64) : memref<32xbf16, #hivm.address_space<ub>>
    annotation.mark %7 {hivm.multi_buffer = 2 : i32} : memref<32xbf16, #hivm.address_space<ub>>
    %8 = hivm.hir.pointer_cast(%c768_i64) : memref<128xbf16, #hivm.address_space<ub>>
    annotation.mark %8 {hivm.multi_buffer = 2 : i32} : memref<128xbf16, #hivm.address_space<ub>>
    %9 = hivm.hir.pointer_cast(%c103328_i64) : memref<128xbf16, #hivm.address_space<ub>>
    annotation.mark %9 {hivm.multi_buffer = 2 : i32} : memref<128xbf16, #hivm.address_space<ub>>
    %10 = hivm.hir.pointer_cast(%c0_i64) : memref<128xbf16, #hivm.address_space<ub>>
    annotation.mark %10 {hivm.multi_buffer = 2 : i32} : memref<128xbf16, #hivm.address_space<ub>>
    %11 = hivm.hir.pointer_cast(%c103072_i64) : memref<128xbf16, #hivm.address_space<ub>>
    annotation.mark %11 {hivm.multi_buffer = 2 : i32} : memref<128xbf16, #hivm.address_space<ub>>
    %12 = hivm.hir.pointer_cast(%c94752_i64) : memref<32x1xf32, #hivm.address_space<ub>>
    %13 = hivm.hir.pointer_cast(%c120032_i64) : memref<32x1xf32, #hivm.address_space<ub>>
    %14 = arith.muli %arg17, %arg18 : i32
    %15 = arith.muli %14, %arg19 : i32
    annotation.mark %15 {logical_block_num} : i32
    %16 = hivm.hir.get_block_idx -> i64
    %17 = arith.trunci %16 : i64 to i32
    %18 = arith.muli %arg19, %arg18 : i32
    hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_MTE2>, <EVENT_ID0>]
    scf.for %arg20 = %17 to %15 step %c48_i32  : i32 {
      %19 = arith.index_cast %arg20 : i32 to index
      %20 = arith.index_cast %17 : i32 to index
      %21 = affine.apply #map()[%19, %20, %c48]
      %22 = arith.index_cast %21 : index to i64
      %23 = arith.cmpi eq, %22, %c1_i64 : i64
      %24 = arith.select %23, %1, %0 : memref<32x128xf32, #hivm.address_space<ub>>
      %25 = arith.index_cast %arg20 : i32 to index
      %26 = arith.index_cast %17 : i32 to index
      %27 = affine.apply #map()[%25, %26, %c48]
      %28 = arith.index_cast %27 : index to i64
      %29 = arith.cmpi eq, %28, %c1_i64 : i64
      %30 = arith.select %29, %5, %4 : memref<32x128xf32, #hivm.address_space<ub>>
      hivm.hir.set_mask_norm
      %31 = arith.remsi %arg20, %arg19 : i32
      %32 = arith.divsi %arg20, %arg19 : i32
      %33 = arith.remsi %32, %arg18 : i32
      %34 = arith.divsi %arg20, %18 : i32
      %35 = arith.remsi %34, %arg17 : i32
      %36 = arith.divsi %31, %c16_i32 : i32
      %37 = arith.remsi %31, %c16_i32 : i32
      %38 = arith.divsi %37, %c2_i32 : i32
      %39 = arith.index_cast %36 : i32 to index
      %reinterpret_cast = memref.reinterpret_cast %arg11 to offset: [%39], sizes: [1], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %40 = memref.load %reinterpret_cast[%c0] : memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %41 = arith.extsi %40 : i32 to i64
      %42 = affine.apply #map1()[%39]
      %reinterpret_cast_2 = memref.reinterpret_cast %arg11 to offset: [%42], sizes: [1], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %43 = memref.load %reinterpret_cast_2[%c0] : memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %44 = arith.extsi %43 : i32 to i64
      %45 = arith.subi %44, %41 : i64
      %46 = arith.cmpi eq, %45, %c0_i64 : i64
      scf.if %46 {
      } else {
        %47 = arith.muli %35, %c128_i32 : i32
        %48 = arith.muli %33, %c32_i32 : i32
        %49 = arith.muli %41, %c8_i64 : i64
        %50 = arith.extsi %38 : i32 to i64
        %51 = arith.addi %49, %50 : i64
        %52 = arith.muli %51, %c128_i64 : i64
        %53 = arith.muli %41, %c16_i64 : i64
        %54 = arith.extsi %37 : i32 to i64
        %55 = arith.addi %53, %54 : i64
        %56 = arith.muli %55, %c128_i64 : i64
        %57 = arith.extsi %35 : i32 to i64
        %58 = arith.muli %57, %arg16 : i64
        %59 = arith.addi %58, %41 : i64
        %60 = arith.muli %59, %c16_i64 : i64
        %61 = arith.addi %60, %54 : i64
        %62 = arith.muli %61, %c128_i64 : i64
        %reinterpret_cast_3 = memref.reinterpret_cast %arg12 to offset: [%39], sizes: [1], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
        %63 = memref.load %reinterpret_cast_3[%c0] : memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
        %64 = arith.extsi %63 : i32 to i64
        %reinterpret_cast_4 = memref.reinterpret_cast %arg13 to offset: [%39], sizes: [1], strides: [1] : memref<?xi64, #hivm.address_space<gm>> to memref<1xi64, strided<[1], offset: ?>, #hivm.address_space<gm>>
        %65 = memref.load %reinterpret_cast_4[%c0] : memref<1xi64, strided<[1], offset: ?>, #hivm.address_space<gm>>
        %66 = arith.cmpi sle, %65, %c0_i64 : i64
        scf.if %66 {
        } else {
          %67 = arith.muli %65, %c4_i64 : i64
          %68 = arith.remsi %64, %c4_i64 : i64
          %69 = arith.addi %67, %68 : i64
          %70 = arith.muli %69, %c262144_i64 : i64
          %71 = arith.muli %37, %c16384_i32 : i32
          %72 = arith.index_cast %70 : i64 to index
          %73 = arith.index_cast %71 : i32 to index
          %74 = arith.index_cast %48 : i32 to index
          %75 = arith.index_cast %47 : i32 to index
          %76 = affine.apply #map2()[%75, %72, %73, %74]
          %reinterpret_cast_5 = memref.reinterpret_cast %arg9 to offset: [%76], sizes: [32, 128], strides: [128, 1] : memref<?xf32, #hivm.address_space<gm>> to memref<32x128xf32, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
          %77 = affine.max #map3()[%74]
          %78 = affine.min #map4()[%77, %74]
          %79 = affine.apply #map5()[%78, %74]
          %80 = affine.max #map3()[%75]
          %81 = affine.min #map6()[%80, %75]
          %82 = affine.apply #map5()[%81, %75]
          %83 = affine.min #map7()[%78, %74]
          %84 = affine.max #map8()[%83]
          %85 = affine.min #map9()[%81, %75]
          %86 = affine.max #map8()[%85]
          %87 = arith.cmpi slt, %84, %c32 : index
          %88 = arith.cmpi slt, %86, %c128 : index
          %89 = arith.ori %87, %88 : i1
          %subview = memref.subview %reinterpret_cast_5[0, 0] [%84, %86] [1, 1] : memref<32x128xf32, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x?xf32, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
          %subview_6 = memref.subview %24[0, 0] [%84, %86] [1, 1] : memref<32x128xf32, #hivm.address_space<ub>> to memref<?x?xf32, strided<[128, 1]>, #hivm.address_space<ub>>
          scf.if %89 {
            hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
            hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
            %collapse_shape = memref.collapse_shape %24 [[0, 1]] : memref<32x128xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
            hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
            hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
            hivm.hir.vbrc ins(%cst_0 : f32) outs(%collapse_shape : memref<4096xf32, #hivm.address_space<ub>>)
            hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
            hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
          } {hivm.unlikely_condition}
          hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_MTE2>, <EVENT_ID0>]
          hivm.hir.pipe_barrier[<PIPE_MTE2>]
          hivm.hir.load ins(%subview : memref<?x?xf32, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_6 : memref<?x?xf32, strided<[128, 1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %cst_0 : f32 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
          %90 = arith.index_cast %52 : i64 to index
          %91 = arith.index_cast %62 : i64 to index
          %92 = arith.index_cast %56 : i64 to index
          %93 = arith.cmpi slt, %82, %c128 : index
          %94 = arith.cmpi slt, %79, %c32 : index
          hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
          hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID2>]
          %95:7 = scf.for %arg21 = %c0_i64 to %45 step %c1_i64 iter_args(%arg22 = %24, %arg23 = %55, %arg24 = %55, %arg25 = %75, %arg26 = %75, %arg27 = %74, %arg28 = %74) -> (memref<32x128xf32, #hivm.address_space<ub>>, i64, i64, index, index, index, index)  : i64 {
            %96 = arith.index_cast %arg21 : i64 to index
            %97 = arith.index_cast %45 : i64 to index
            %98 = arith.index_cast %arg20 : i32 to index
            %99 = arith.index_cast %17 : i32 to index
            %100 = affine.apply #map10()[%96, %c0, %97, %c1, %98, %99, %c48]
            %101 = arith.index_cast %100 : index to i64
            %102 = arith.cmpi eq, %101, %c1_i64 : i64
            %103 = arith.select %102, %3, %2 : memref<32xbf16, #hivm.address_space<ub>>
            %104 = arith.index_cast %arg21 : i64 to index
            %105 = arith.index_cast %45 : i64 to index
            %106 = arith.index_cast %arg20 : i32 to index
            %107 = arith.index_cast %17 : i32 to index
            %108 = affine.apply #map10()[%104, %c0, %105, %c1, %106, %107, %c48]
            %109 = arith.index_cast %108 : index to i64
            %110 = arith.cmpi eq, %109, %c1_i64 : i64
            %111 = arith.select %110, %7, %6 : memref<32xbf16, #hivm.address_space<ub>>
            %112 = arith.index_cast %arg21 : i64 to index
            %113 = arith.index_cast %45 : i64 to index
            %114 = arith.index_cast %arg20 : i32 to index
            %115 = arith.index_cast %17 : i32 to index
            %116 = affine.apply #map10()[%112, %c0, %113, %c1, %114, %115, %c48]
            %117 = arith.index_cast %116 : index to i64
            %118 = arith.cmpi eq, %117, %c1_i64 : i64
            %119 = arith.select %118, %9, %8 : memref<128xbf16, #hivm.address_space<ub>>
            %120 = arith.index_cast %arg21 : i64 to index
            %121 = arith.index_cast %45 : i64 to index
            %122 = arith.index_cast %arg20 : i32 to index
            %123 = arith.index_cast %17 : i32 to index
            %124 = affine.apply #map10()[%120, %c0, %121, %c1, %122, %123, %c48]
            %125 = arith.index_cast %124 : index to i64
            %126 = arith.cmpi eq, %125, %c1_i64 : i64
            %127 = arith.select %126, %11, %10 : memref<128xbf16, #hivm.address_space<ub>>
            %128 = arith.index_cast %arg21 : i64 to index
            %129 = arith.index_cast %45 : i64 to index
            %130 = arith.index_cast %arg20 : i32 to index
            %131 = arith.index_cast %17 : i32 to index
            %132 = affine.apply #map10()[%128, %c0, %129, %c1, %130, %131, %c48]
            %133 = arith.index_cast %132 : index to i64
            %134 = arith.cmpi eq, %133, %c1_i64 : i64
            %135 = arith.select %134, %13, %12 : memref<32x1xf32, #hivm.address_space<ub>>
            %136 = arith.index_cast %arg21 : i64 to index
            %137 = arith.index_cast %45 : i64 to index
            %138 = arith.index_cast %arg20 : i32 to index
            %139 = arith.index_cast %17 : i32 to index
            %140 = affine.apply #map10()[%136, %c0, %137, %c1, %138, %139, %c48]
            %141 = arith.index_cast %140 : index to i1
            %142 = arith.select %141, %c1_i64, %c2_i64 : i64
            %143 = arith.index_cast %arg24 : i64 to index
            %reinterpret_cast_7 = memref.reinterpret_cast %arg7 to offset: [%143], sizes: [1], strides: [1] : memref<?xbf16, #hivm.address_space<gm>> to memref<1xbf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
            %144 = arith.index_cast %arg23 : i64 to index
            %reinterpret_cast_8 = memref.reinterpret_cast %arg6 to offset: [%144], sizes: [1], strides: [1] : memref<?xf32, #hivm.address_space<gm>> to memref<1xf32, strided<[1], offset: ?>, #hivm.address_space<gm>>
            %145 = affine.apply #map11()[%90, %arg25]
            %reinterpret_cast_9 = memref.reinterpret_cast %arg3 to offset: [%145], sizes: [128], strides: [1] : memref<?xbf16, #hivm.address_space<gm>> to memref<128xbf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
            %146 = affine.apply #map11()[%90, %arg26]
            %reinterpret_cast_10 = memref.reinterpret_cast %arg4 to offset: [%146], sizes: [128], strides: [1] : memref<?xbf16, #hivm.address_space<gm>> to memref<128xbf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
            %147 = affine.apply #map11()[%91, %arg27]
            %reinterpret_cast_11 = memref.reinterpret_cast %arg8 to offset: [%147], sizes: [32], strides: [1] : memref<?xbf16, #hivm.address_space<gm>> to memref<32xbf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
            %148 = affine.apply #map11()[%92, %arg28]
            %reinterpret_cast_12 = memref.reinterpret_cast %arg5 to offset: [%148], sizes: [32], strides: [1] : memref<?xbf16, #hivm.address_space<gm>> to memref<32xbf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
            %subview_13 = memref.subview %reinterpret_cast_9[0] [%82] [1] : memref<128xbf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xbf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
            %subview_14 = memref.subview %127[0] [%82] [1] : memref<128xbf16, #hivm.address_space<ub>> to memref<?xbf16, strided<[1]>, #hivm.address_space<ub>>
            scf.if %93 {
              hivm.hir.vbrc ins(%cst : bf16) outs(%127 : memref<128xbf16, #hivm.address_space<ub>>)
              hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
              hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
            } {hivm.unlikely_condition}
            hivm.hir.load ins(%subview_13 : memref<?xbf16, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_14 : memref<?xbf16, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %cst : bf16 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
            hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
            %149 = hivm.hir.pointer_cast(%c256_i64) : memref<128xf32, #hivm.address_space<ub>>
            hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
            hivm.hir.vcast ins(%127 : memref<128xbf16, #hivm.address_space<ub>>) outs(%149 : memref<128xf32, #hivm.address_space<ub>>)
            %subview_15 = memref.subview %reinterpret_cast_10[0] [%82] [1] : memref<128xbf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xbf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
            %subview_16 = memref.subview %119[0] [%82] [1] : memref<128xbf16, #hivm.address_space<ub>> to memref<?xbf16, strided<[1]>, #hivm.address_space<ub>>
            scf.if %93 {
              hivm.hir.vbrc ins(%cst : bf16) outs(%119 : memref<128xbf16, #hivm.address_space<ub>>)
              hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
              hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
            } {hivm.unlikely_condition}
            hivm.hir.load ins(%subview_15 : memref<?xbf16, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_16 : memref<?xbf16, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %cst : bf16 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
            hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
            %150 = hivm.hir.pointer_cast(%c1024_i64) : memref<128xf32, #hivm.address_space<ub>>
            hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
            hivm.hir.vcast ins(%119 : memref<128xbf16, #hivm.address_space<ub>>) outs(%150 : memref<128xf32, #hivm.address_space<ub>>)
            %subview_17 = memref.subview %reinterpret_cast_12[0] [%79] [1] : memref<32xbf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xbf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
            %subview_18 = memref.subview %111[0] [%79] [1] : memref<32xbf16, #hivm.address_space<ub>> to memref<?xbf16, strided<[1]>, #hivm.address_space<ub>>
            scf.if %94 {
              hivm.hir.vbrc ins(%cst : bf16) outs(%111 : memref<32xbf16, #hivm.address_space<ub>>)
              hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
              hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
            } {hivm.unlikely_condition}
            hivm.hir.load ins(%subview_17 : memref<?xbf16, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_18 : memref<?xbf16, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %cst : bf16 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
            hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
            %151 = hivm.hir.pointer_cast(%c1600_i64) : memref<32xf32, #hivm.address_space<ub>>
            hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
            hivm.hir.vcast ins(%111 : memref<32xbf16, #hivm.address_space<ub>>) outs(%151 : memref<32xf32, #hivm.address_space<ub>>)
            %152 = hivm.hir.pointer_cast(%c1728_i64) : memref<128xf32, #hivm.address_space<ub>>
            hivm.hir.pipe_barrier[<PIPE_V>]
            hivm.hir.vmul ins(%149, %149 : memref<128xf32, #hivm.address_space<ub>>, memref<128xf32, #hivm.address_space<ub>>) outs(%152 : memref<128xf32, #hivm.address_space<ub>>)
            %153 = hivm.hir.pointer_cast(%c2240_i64) : memref<1xf32, #hivm.address_space<ub>>
            %154 = hivm.hir.pointer_cast(%c2272_i64) : memref<64xf32, #hivm.address_space<ub>>
            hivm.hir.pipe_barrier[<PIPE_V>]
            hivm.hir.vreduce <sum> ins(%152 : memref<128xf32, #hivm.address_space<ub>>) outs(%153 : memref<1xf32, #hivm.address_space<ub>>) temp_buffer(%154 : memref<64xf32, #hivm.address_space<ub>>) reduce_dims = [0]
            hivm.hir.set_flag[<PIPE_V>, <PIPE_S>, <EVENT_ID0>]
            hivm.hir.wait_flag[<PIPE_V>, <PIPE_S>, <EVENT_ID0>]
            %155 = memref.load %153[%c0] : memref<1xf32, #hivm.address_space<ub>>
            %156 = arith.addf %155, %cst_1 : f32
            %157 = math.sqrt %156 : f32
            %158 = hivm.hir.pointer_cast(%c256_i64) : memref<128xf32, #hivm.address_space<ub>>
            %159 = hivm.hir.pointer_cast(%c2528_i64) : memref<8xf32, #hivm.address_space<ub>>
            hivm.hir.vdiv ins(%149, %157 : memref<128xf32, #hivm.address_space<ub>>, f32) outs(%158 : memref<128xf32, #hivm.address_space<ub>>) temp_buffer(%159 : memref<8xf32, #hivm.address_space<ub>>)
            %160 = hivm.hir.pointer_cast(%c2560_i64) : memref<128xf32, #hivm.address_space<ub>>
            hivm.hir.vmul ins(%150, %150 : memref<128xf32, #hivm.address_space<ub>>, memref<128xf32, #hivm.address_space<ub>>) outs(%160 : memref<128xf32, #hivm.address_space<ub>>)
            %161 = hivm.hir.pointer_cast(%c3072_i64) : memref<1xf32, #hivm.address_space<ub>>
            %162 = hivm.hir.pointer_cast(%c3104_i64) : memref<64xf32, #hivm.address_space<ub>>
            hivm.hir.pipe_barrier[<PIPE_V>]
            hivm.hir.vreduce <sum> ins(%160 : memref<128xf32, #hivm.address_space<ub>>) outs(%161 : memref<1xf32, #hivm.address_space<ub>>) temp_buffer(%162 : memref<64xf32, #hivm.address_space<ub>>) reduce_dims = [0]
            hivm.hir.set_flag[<PIPE_V>, <PIPE_S>, <EVENT_ID0>]
            hivm.hir.wait_flag[<PIPE_V>, <PIPE_S>, <EVENT_ID0>]
            %163 = memref.load %161[%c0] : memref<1xf32, #hivm.address_space<ub>>
            %164 = arith.addf %163, %cst_1 : f32
            %165 = math.sqrt %164 : f32
            %166 = hivm.hir.pointer_cast(%c1024_i64) : memref<128xf32, #hivm.address_space<ub>>
            %167 = hivm.hir.pointer_cast(%c3360_i64) : memref<8xf32, #hivm.address_space<ub>>
            hivm.hir.vdiv ins(%150, %165 : memref<128xf32, #hivm.address_space<ub>>, f32) outs(%166 : memref<128xf32, #hivm.address_space<ub>>) temp_buffer(%167 : memref<8xf32, #hivm.address_space<ub>>)
            %168 = hivm.hir.pointer_cast(%c256_i64) : memref<128xf32, #hivm.address_space<ub>>
            hivm.hir.vmul ins(%158, %arg14 : memref<128xf32, #hivm.address_space<ub>>, f32) outs(%168 : memref<128xf32, #hivm.address_space<ub>>)
            %169 = memref.load %reinterpret_cast_8[%c0] : memref<1xf32, strided<[1], offset: ?>, #hivm.address_space<gm>>
            %170 = hivm.hir.pointer_cast(%c3392_i64) : memref<1xf32, #hivm.address_space<ub>>
            memref.store %169, %170[%c0] : memref<1xf32, #hivm.address_space<ub>>
            hivm.hir.set_flag[<PIPE_S>, <PIPE_V>, <EVENT_ID0>]
            %171 = hivm.hir.pointer_cast(%c3392_i64) : memref<1xf32, #hivm.address_space<ub>>
            hivm.hir.wait_flag[<PIPE_S>, <PIPE_V>, <EVENT_ID0>]
            hivm.hir.vexp ins(%170 : memref<1xf32, #hivm.address_space<ub>>) outs(%171 : memref<1xf32, #hivm.address_space<ub>>)
            hivm.hir.set_flag[<PIPE_V>, <PIPE_S>, <EVENT_ID0>]
            hivm.hir.wait_flag[<PIPE_V>, <PIPE_S>, <EVENT_ID0>]
            %172 = memref.load %171[%c0] : memref<1xf32, #hivm.address_space<ub>>
            %173 = hivm.hir.pointer_cast(%c3424_i64) : memref<32x128xf32, #hivm.address_space<ub>>
            %collapse_shape = memref.collapse_shape %arg22 [[0, 1]] : memref<32x128xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
            %collapse_shape_19 = memref.collapse_shape %173 [[0, 1]] : memref<32x128xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
            hivm.hir.vmul ins(%collapse_shape, %172 : memref<4096xf32, #hivm.address_space<ub>>, f32) outs(%collapse_shape_19 : memref<4096xf32, #hivm.address_space<ub>>)
            %expand_shape = memref.expand_shape %166 [[0, 1]] output_shape [1, 128] : memref<128xf32, #hivm.address_space<ub>> into memref<1x128xf32, #hivm.address_space<ub>>
            %174 = hivm.hir.pointer_cast(%c19808_i64) : memref<32x128xf32, #hivm.address_space<ub>>
            hivm.hir.pipe_barrier[<PIPE_V>]
            hivm.hir.vmul ins(%173, %expand_shape : memref<32x128xf32, #hivm.address_space<ub>>, memref<1x128xf32, #hivm.address_space<ub>>) outs(%174 : memref<32x128xf32, #hivm.address_space<ub>>) broadcast = [0]
            %175 = hivm.hir.pointer_cast(%c36192_i64) : memref<32x1xf32, #hivm.address_space<ub>>
            %176 = hivm.hir.pointer_cast(%c36320_i64) : memref<2048xf32, #hivm.address_space<ub>>
            hivm.hir.pipe_barrier[<PIPE_V>]
            hivm.hir.vreduce <sum> ins(%174 : memref<32x128xf32, #hivm.address_space<ub>>) outs(%175 : memref<32x1xf32, #hivm.address_space<ub>>) temp_buffer(%176 : memref<2048xf32, #hivm.address_space<ub>>) reduce_dims = [1]
            %collapse_shape_20 = memref.collapse_shape %175 [[0, 1]] : memref<32x1xf32, #hivm.address_space<ub>> into memref<32xf32, #hivm.address_space<ub>>
            %177 = hivm.hir.pointer_cast(%c1600_i64) : memref<32xf32, #hivm.address_space<ub>>
            hivm.hir.pipe_barrier[<PIPE_V>]
            hivm.hir.vsub ins(%151, %collapse_shape_20 : memref<32xf32, #hivm.address_space<ub>>, memref<32xf32, #hivm.address_space<ub>>) outs(%177 : memref<32xf32, #hivm.address_space<ub>>)
            %178 = memref.load %reinterpret_cast_7[%c0] : memref<1xbf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
            %179 = hivm.hir.pointer_cast(%c44512_i64) : memref<1xbf16, #hivm.address_space<ub>>
            memref.store %178, %179[%c0] : memref<1xbf16, #hivm.address_space<ub>>
            hivm.hir.set_flag[<PIPE_S>, <PIPE_V>, <EVENT_ID0>]
            %180 = hivm.hir.pointer_cast(%c44544_i64) : memref<1xf32, #hivm.address_space<ub>>
            hivm.hir.wait_flag[<PIPE_S>, <PIPE_V>, <EVENT_ID0>]
            hivm.hir.vcast ins(%179 : memref<1xbf16, #hivm.address_space<ub>>) outs(%180 : memref<1xf32, #hivm.address_space<ub>>)
            hivm.hir.set_flag[<PIPE_V>, <PIPE_S>, <EVENT_ID0>]
            hivm.hir.wait_flag[<PIPE_V>, <PIPE_S>, <EVENT_ID0>]
            %181 = memref.load %180[%c0] : memref<1xf32, #hivm.address_space<ub>>
            %182 = hivm.hir.pointer_cast(%c1600_i64) : memref<32xf32, #hivm.address_space<ub>>
            hivm.hir.vmul ins(%177, %181 : memref<32xf32, #hivm.address_space<ub>>, f32) outs(%182 : memref<32xf32, #hivm.address_space<ub>>)
            %expand_shape_21 = memref.expand_shape %182 [[0, 1]] output_shape [32, 1] : memref<32xf32, #hivm.address_space<ub>> into memref<32x1xf32, #hivm.address_space<ub>>
            %183 = hivm.hir.pointer_cast(%c44576_i64) : memref<32x128xf32, #hivm.address_space<ub>>
            %184 = hivm.hir.pointer_cast(%c60960_i64) : memref<256xf32, #hivm.address_space<ub>>
            hivm.hir.pipe_barrier[<PIPE_V>]
            hivm.hir.vmul ins(%expand_shape_21, %expand_shape : memref<32x1xf32, #hivm.address_space<ub>>, memref<1x128xf32, #hivm.address_space<ub>>) outs(%183 : memref<32x128xf32, #hivm.address_space<ub>>) temp_buffer(%184 : memref<256xf32, #hivm.address_space<ub>>) broadcast = [0, 1]
            %collapse_shape_22 = memref.collapse_shape %183 [[0, 1]] : memref<32x128xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
            %collapse_shape_23 = memref.collapse_shape %30 [[0, 1]] : memref<32x128xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
            hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, %142]
            hivm.hir.pipe_barrier[<PIPE_V>]
            hivm.hir.vadd ins(%collapse_shape_19, %collapse_shape_22 : memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_23 : memref<4096xf32, #hivm.address_space<ub>>)
            %expand_shape_24 = memref.expand_shape %168 [[0, 1]] output_shape [1, 128] : memref<128xf32, #hivm.address_space<ub>> into memref<1x128xf32, #hivm.address_space<ub>>
            %185 = hivm.hir.pointer_cast(%c78368_i64) : memref<32x128xf32, #hivm.address_space<ub>>
            hivm.hir.pipe_barrier[<PIPE_V>]
            hivm.hir.vmul ins(%30, %expand_shape_24 : memref<32x128xf32, #hivm.address_space<ub>>, memref<1x128xf32, #hivm.address_space<ub>>) outs(%185 : memref<32x128xf32, #hivm.address_space<ub>>) broadcast = [0]
            %186 = hivm.hir.pointer_cast(%c94880_i64) : memref<2048xf32, #hivm.address_space<ub>>
            hivm.hir.pipe_barrier[<PIPE_V>]
            hivm.hir.vreduce <sum> ins(%185 : memref<32x128xf32, #hivm.address_space<ub>>) outs(%135 : memref<32x1xf32, #hivm.address_space<ub>>) temp_buffer(%186 : memref<2048xf32, #hivm.address_space<ub>>) reduce_dims = [1]
            %collapse_shape_25 = memref.collapse_shape %135 [[0, 1]] : memref<32x1xf32, #hivm.address_space<ub>> into memref<32xf32, #hivm.address_space<ub>>
            hivm.hir.pipe_barrier[<PIPE_V>]
            hivm.hir.vcast ins(%collapse_shape_25 : memref<32xf32, #hivm.address_space<ub>>) outs(%103 : memref<32xbf16, #hivm.address_space<ub>>)
            hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
            %subview_26 = memref.subview %103[0] [%79] [1] : memref<32xbf16, #hivm.address_space<ub>> to memref<?xbf16, strided<[1]>, #hivm.address_space<ub>>
            %subview_27 = memref.subview %reinterpret_cast_11[0] [%79] [1] : memref<32xbf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xbf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
            hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
            hivm.hir.pipe_barrier[<PIPE_MTE3>]
            hivm.hir.store ins(%subview_26 : memref<?xbf16, strided<[1]>, #hivm.address_space<ub>>) outs(%subview_27 : memref<?xbf16, strided<[1], offset: ?>, #hivm.address_space<gm>>)
            %187 = arith.addi %64, %arg21 : i64
            %188 = arith.addi %187, %c1_i64 : i64
            %189 = arith.remsi %188, %c4_i64 : i64
            %190 = arith.addi %67, %189 : i64
            %191 = arith.muli %190, %c262144_i64 : i64
            %192 = arith.index_cast %191 : i64 to index
            %193 = affine.apply #map2()[%75, %192, %73, %74]
            %reinterpret_cast_28 = memref.reinterpret_cast %arg10 to offset: [%193], sizes: [32, 128], strides: [128, 1] : memref<?xf32, #hivm.address_space<gm>> to memref<32x128xf32, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
            %subview_29 = memref.subview %30[0, 0] [%84, %86] [1, 1] : memref<32x128xf32, #hivm.address_space<ub>> to memref<?x?xf32, strided<[128, 1]>, #hivm.address_space<ub>>
            %subview_30 = memref.subview %reinterpret_cast_28[0, 0] [%84, %86] [1, 1] : memref<32x128xf32, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x?xf32, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
            hivm.hir.store ins(%subview_29 : memref<?x?xf32, strided<[128, 1]>, #hivm.address_space<ub>>) outs(%subview_30 : memref<?x?xf32, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>)
            hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, %142]
            %194 = arith.addi %arg23, %c16_i64 : i64
            %195 = arith.addi %arg24, %c16_i64 : i64
            %196 = affine.apply #map12()[%arg25]
            %197 = affine.apply #map12()[%arg26]
            %198 = affine.apply #map13()[%arg27]
            %199 = affine.apply #map13()[%arg28]
            scf.yield %30, %194, %195, %196, %197, %198, %199 : memref<32x128xf32, #hivm.address_space<ub>>, i64, i64, index, index, index, index
          }
          hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
          hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID2>]
          hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_MTE2>, <EVENT_ID0>]
        }
      } {pipeline.veconly}
    } {autoblockify.subloop}
    hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_MTE2>, <EVENT_ID0>]
    hivm.hir.pipe_barrier[<PIPE_ALL>]
    return
  }
}

