#map = affine_map<()[s0, s1] -> (((s0 - s1) floordiv 48) mod 2)>
#map1 = affine_map<()[s0] -> (s0 + 1)>
#map2 = affine_map<()[s0, s1, s2, s3] -> (s0 + s1 + s2 + s3 * 128)>
#map3 = affine_map<()[s0] -> (128, s0)>
#map4 = affine_map<()[s0, s1] -> (s1 + 32, s0)>
#map5 = affine_map<()[s0, s1] -> (s0 - s1)>
#map6 = affine_map<()[s0, s1] -> (s1 + 128, s0)>
#map7 = affine_map<()[s0, s1] -> (32, s0 - s1)>
#map8 = affine_map<()[s0] -> (0, s0)>
#map9 = affine_map<()[s0, s1] -> (128, s0 - s1)>
#map10 = affine_map<()[s0, s1, s2, s3] -> ((s0 + ((s2 - s3) floordiv 48) * s1) mod 2)>
#map11 = affine_map<()[s0, s1] -> (s0 + s1)>
#map12 = affine_map<()[s0] -> (s0 + 1024)>
#map13 = affine_map<()[s0] -> (s0 + 2048)>
module attributes {dlti.target_system_spec = #dlti.target_system_spec<"NPU" : #hacc.target_device_spec<#dlti.dl_entry<"AI_CORE_COUNT", 24 : i32>, #dlti.dl_entry<"CUBE_CORE_COUNT", 24 : i32>, #dlti.dl_entry<"VECTOR_CORE_COUNT", 48 : i32>, #dlti.dl_entry<"UB_SIZE", 1572864 : i32>, #dlti.dl_entry<"L1_SIZE", 4194304 : i32>, #dlti.dl_entry<"L0A_SIZE", 524288 : i32>, #dlti.dl_entry<"L0B_SIZE", 524288 : i32>, #dlti.dl_entry<"L0C_SIZE", 1048576 : i32>, #dlti.dl_entry<"UB_ALIGN_SIZE", 256 : i32>, #dlti.dl_entry<"L1_ALIGN_SIZE", 256 : i32>, #dlti.dl_entry<"L0C_ALIGN_SIZE", 4096 : i32>>>,   hivm.aic_bitcode = #hivm.aic_bitcode<"/root/workspace/a3-validation-20261112/envs/dependencies/triton/backends/ascend/bishengir/lib/meta_op.aic.bc">, hivm.aiv_bitcode = #hivm.aiv_bitcode<"/root/workspace/a3-validation-20261112/envs/dependencies/triton/backends/ascend/bishengir/lib/meta_op.aiv.bc">, hivm.host_bitcode = #hivm.host_bitcode<"/root/workspace/a3-validation-20261112/envs/dependencies/triton/backends/ascend/bishengir/lib/host.bc">, hivm.mix_aic_bitcode = #hivm.mix_aic_bitcode<"/root/workspace/a3-validation-20261112/envs/dependencies/triton/backends/ascend/bishengir/lib/meta_op.mix.aic.bc">, hivm.mix_aiv_bitcode = #hivm.mix_aiv_bitcode<"/root/workspace/a3-validation-20261112/envs/dependencies/triton/backends/ascend/bishengir/lib/meta_op.mix.aiv.bc">, hivm.module_core_type = #hivm.module_core_type<AIV>, memref.memref_as_ptr} {
  func.func @fused_recurrent_gated_delta_rule_fwd_kernel_infer_task_type_function() -> i8 attributes {hacc.function_kind = #hacc.function_kind<HOST>, hacc.host_func_type = #hacc.host_func_type<infer_task_type_function>} {
    %c10_i8 = arith.constant 10 : i8
    return %c10_i8 : i8
  }
  func.func private @broadcast_scalar_float_to_1d(f32, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIV>, llvm.emit_c_interface}
  func.func private @load_gm_to_ubuf_2d_float(memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<gm>>, memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<ub>>, i32, f32, index) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIV>, llvm.emit_c_interface}
  func.func private @broadcast_scalar_bfloat16_t_to_1d(bf16, memref<?xbf16, strided<[?], offset: ?>, #hivm.address_space<ub>>) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIV>, llvm.emit_c_interface}
  func.func private @load_gm_to_ubuf_1d_bfloat16_t(memref<?xbf16, strided<[?], offset: ?>, #hivm.address_space<gm>>, memref<?xbf16, strided<[?], offset: ?>, #hivm.address_space<ub>>, i32, bf16, index) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIV>, llvm.emit_c_interface}
  func.func private @vcast_bfloat16_t_to_float_1d_with_mode(memref<?xbf16, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, i32) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIV>, llvm.emit_c_interface}
  func.func private @vmul_1d_float(memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIV>, llvm.emit_c_interface}
  func.func private @enablevc_reduce_sum_r_float(memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, f32) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIV>, llvm.emit_c_interface}
  func.func private @vdiv_vs_1d_float(memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, f32, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIV>, llvm.emit_c_interface}
  func.func private @vmuls_vs_1d_float(memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, f32, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIV>, llvm.emit_c_interface}
  func.func private @vexp_1d_float(memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIV>, llvm.emit_c_interface}
  func.func private @vmul_2d_float(memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<ub>>, memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<ub>>, memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIV>, llvm.emit_c_interface}
  func.func private @enablevc_reduce_sum_ar_float(memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<ub>>, memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, f32) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIV>, llvm.emit_c_interface}
  func.func private @vsub_1d_float(memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIV>, llvm.emit_c_interface}
  func.func private @vadd_1d_float(memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIV>, llvm.emit_c_interface}
  func.func private @vcast_float_to_bfloat16_t_1d_with_mode(memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xbf16, strided<[?], offset: ?>, #hivm.address_space<ub>>, i32) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIV>, llvm.emit_c_interface}
  func.func private @store_ubuf_to_gm_1d_bfloat16_t(memref<?xbf16, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xbf16, strided<[?], offset: ?>, #hivm.address_space<gm>>, i32) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIV>, llvm.emit_c_interface}
  func.func private @store_ubuf_to_gm_2d_float(memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<ub>>, memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<gm>>, i32) attributes {hacc.always_inline, hivm.func_core_type = #hivm.func_core_type<AIV>, llvm.emit_c_interface}
  func.func @fused_recurrent_gated_delta_rule_fwd_kernel(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xbf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg4: memref<?xbf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg5: memref<?xbf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg6: memref<?xf32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg7: memref<?xbf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg8: memref<?xbf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 1 : i32}, %arg9: memref<?xf32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg10: memref<?xf32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 1 : i32}, %arg11: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg12: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg13: memref<?xi64, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg14: f32, %arg15: i64, %arg16: i64, %arg17: i32, %arg18: i32, %arg19: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, func_dyn_memref_args = dense<[false, true, true, true, true, true, true, true, true, true, true, true, true, true, false, false, false, false, false, false]> : vector<20xi1>, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.storage_aligned, mix_mode = "aiv", parallel_mode = "simd"} {
    %c0_i32 = arith.constant 0 : i32
    %c48_i32 = arith.constant 48 : i32
    %cst = arith.constant 0.000000e+00 : bf16
    %c32 = arith.constant 32 : index
    %c128 = arith.constant 128 : index
    %cst_0 = arith.constant 0.000000e+00 : f32
    %c16384_i32 = arith.constant 16384 : i32
    %c1_i64 = arith.constant 1 : i64
    %c262144_i64 = arith.constant 262144 : i64
    %c4_i64 = arith.constant 4 : i64
    %c16_i64 = arith.constant 16 : i64
    %c128_i64 = arith.constant 128 : i64
    %c8_i64 = arith.constant 8 : i64
    %c32_i32 = arith.constant 32 : i32
    %c128_i32 = arith.constant 128 : i32
    %c2_i32 = arith.constant 2 : i32
    %c16_i32 = arith.constant 16 : i32
    %c0 = arith.constant 0 : index
    %cst_1 = arith.constant 9.99999997E-7 : f32
    %c256_i64 = arith.constant 256 : i64
    %c1024_i64 = arith.constant 1024 : i64
    %c1600_i64 = arith.constant 1600 : i64
    %c1728_i64 = arith.constant 1728 : i64
    %c2240_i64 = arith.constant 2240 : i64
    %c2272_i64 = arith.constant 2272 : i64
    %c2528_i64 = arith.constant 2528 : i64
    %c2560_i64 = arith.constant 2560 : i64
    %c3072_i64 = arith.constant 3072 : i64
    %c3104_i64 = arith.constant 3104 : i64
    %c3360_i64 = arith.constant 3360 : i64
    %c3392_i64 = arith.constant 3392 : i64
    %c3424_i64 = arith.constant 3424 : i64
    %c19808_i64 = arith.constant 19808 : i64
    %c36192_i64 = arith.constant 36192 : i64
    %c36320_i64 = arith.constant 36320 : i64
    %c44512_i64 = arith.constant 44512 : i64
    %c44544_i64 = arith.constant 44544 : i64
    %c44576_i64 = arith.constant 44576 : i64
    %c60960_i64 = arith.constant 60960 : i64
    %c78368_i64 = arith.constant 78368 : i64
    %c94880_i64 = arith.constant 94880 : i64
    %c2_i64 = arith.constant 2 : i64
    %c103072_i64 = arith.constant 103072 : i64
    %c0_i64 = arith.constant 0 : i64
    %c103328_i64 = arith.constant 103328 : i64
    %c768_i64 = arith.constant 768 : i64
    %c103584_i64 = arith.constant 103584 : i64
    %c1536_i64 = arith.constant 1536 : i64
    %c120032_i64 = arith.constant 120032 : i64
    %c94752_i64 = arith.constant 94752 : i64
    %c61984_i64 = arith.constant 61984 : i64
    %c103648_i64 = arith.constant 103648 : i64
    %0 = hivm.hir.pointer_cast(%c61984_i64) : memref<32x128xf32, #hivm.address_space<ub>>
    %1 = hivm.hir.pointer_cast(%c103648_i64) : memref<32x128xf32, #hivm.address_space<ub>>
    %2 = hivm.hir.pointer_cast(%c94752_i64) : memref<32xbf16, #hivm.address_space<ub>>
    %3 = hivm.hir.pointer_cast(%c120032_i64) : memref<32xbf16, #hivm.address_space<ub>>
    %4 = hivm.hir.pointer_cast(%c61984_i64) : memref<32x128xf32, #hivm.address_space<ub>>
    %5 = hivm.hir.pointer_cast(%c103648_i64) : memref<32x128xf32, #hivm.address_space<ub>>
    %6 = hivm.hir.pointer_cast(%c1536_i64) : memref<32xbf16, #hivm.address_space<ub>>
    %7 = hivm.hir.pointer_cast(%c103584_i64) : memref<32xbf16, #hivm.address_space<ub>>
    %8 = hivm.hir.pointer_cast(%c768_i64) : memref<128xbf16, #hivm.address_space<ub>>
    %9 = hivm.hir.pointer_cast(%c103328_i64) : memref<128xbf16, #hivm.address_space<ub>>
    %10 = hivm.hir.pointer_cast(%c0_i64) : memref<128xbf16, #hivm.address_space<ub>>
    %11 = hivm.hir.pointer_cast(%c103072_i64) : memref<128xbf16, #hivm.address_space<ub>>
    %12 = hivm.hir.pointer_cast(%c94752_i64) : memref<32x1xf32, #hivm.address_space<ub>>
    %13 = hivm.hir.pointer_cast(%c120032_i64) : memref<32x1xf32, #hivm.address_space<ub>>
    %14 = arith.muli %arg17, %arg18 : i32
    %15 = arith.muli %14, %arg19 : i32
    %16 = hivm.hir.get_block_idx -> i64
    %17 = arith.trunci %16 : i64 to i32
    %18 = arith.muli %arg19, %arg18 : i32
    hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_MTE2>, <EVENT_ID0>]
    scf.for %arg20 = %17 to %15 step %c48_i32  : i32 {
      %19 = arith.index_cast %arg20 : i32 to index
      %20 = arith.index_cast %17 : i32 to index
      %21 = affine.apply #map()[%19, %20]
      %22 = arith.index_cast %21 : index to i64
      %23 = arith.cmpi eq, %22, %c1_i64 : i64
      %24 = arith.select %23, %1, %0 : memref<32x128xf32, #hivm.address_space<ub>>
      %25 = arith.index_cast %arg20 : i32 to index
      %26 = arith.index_cast %17 : i32 to index
      %27 = affine.apply #map()[%25, %26]
      %28 = arith.index_cast %27 : index to i64
      %29 = arith.cmpi eq, %28, %c1_i64 : i64
      %30 = arith.select %29, %5, %4 : memref<32x128xf32, #hivm.address_space<ub>>
      hivm.hir.set_mask_norm
      %31 = arith.remsi %arg20, %arg19 : i32
      %32 = arith.divsi %arg20, %arg19 : i32
      %33 = arith.remsi %32, %arg18 : i32
      %34 = arith.divsi %arg20, %18 : i32
      %35 = arith.remsi %34, %arg17 : i32
      %36 = arith.divsi %31, %c16_i32 : i32
      %37 = arith.remsi %31, %c16_i32 : i32
      %38 = arith.divsi %37, %c2_i32 : i32
      %39 = arith.index_cast %36 : i32 to index
      %reinterpret_cast = memref.reinterpret_cast %arg11 to offset: [%39], sizes: [1], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %40 = memref.load %reinterpret_cast[%c0] {markDCacheInvalidatePatternVisited = 0 : i32} : memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %41 = arith.extsi %40 : i32 to i64
      %42 = affine.apply #map1()[%39]
      %reinterpret_cast_2 = memref.reinterpret_cast %arg11 to offset: [%42], sizes: [1], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %43 = memref.load %reinterpret_cast_2[%c0] {markDCacheInvalidatePatternVisited = 0 : i32} : memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %44 = arith.extsi %43 : i32 to i64
      %45 = arith.subi %44, %41 : i64
      %46 = arith.cmpi eq, %45, %c0_i64 : i64
      scf.if %46 {
      } else {
        %47 = arith.muli %35, %c128_i32 : i32
        %48 = arith.muli %33, %c32_i32 : i32
        %49 = arith.muli %41, %c8_i64 : i64
        %50 = arith.extsi %38 : i32 to i64
        %51 = arith.addi %49, %50 : i64
        %52 = arith.muli %51, %c128_i64 : i64
        %53 = arith.muli %41, %c16_i64 : i64
        %54 = arith.extsi %37 : i32 to i64
        %55 = arith.addi %53, %54 : i64
        %56 = arith.muli %55, %c128_i64 : i64
        %57 = arith.extsi %35 : i32 to i64
        %58 = arith.muli %57, %arg16 : i64
        %59 = arith.addi %58, %41 : i64
        %60 = arith.muli %59, %c16_i64 : i64
        %61 = arith.addi %60, %54 : i64
        %62 = arith.muli %61, %c128_i64 : i64
        %reinterpret_cast_3 = memref.reinterpret_cast %arg12 to offset: [%39], sizes: [1], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
        %63 = memref.load %reinterpret_cast_3[%c0] {markDCacheInvalidatePatternVisited = 0 : i32} : memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
        %64 = arith.extsi %63 : i32 to i64
        %reinterpret_cast_4 = memref.reinterpret_cast %arg13 to offset: [%39], sizes: [1], strides: [1] : memref<?xi64, #hivm.address_space<gm>> to memref<1xi64, strided<[1], offset: ?>, #hivm.address_space<gm>>
        %65 = memref.load %reinterpret_cast_4[%c0] {markDCacheInvalidatePatternVisited = 0 : i32} : memref<1xi64, strided<[1], offset: ?>, #hivm.address_space<gm>>
        %66 = arith.cmpi sle, %65, %c0_i64 : i64
        scf.if %66 {
        } else {
          %67 = arith.muli %65, %c4_i64 : i64
          %68 = arith.remsi %64, %c4_i64 : i64
          %69 = arith.addi %67, %68 : i64
          %70 = arith.muli %69, %c262144_i64 : i64
          %71 = arith.muli %37, %c16384_i32 : i32
          %72 = arith.index_cast %70 : i64 to index
          %73 = arith.index_cast %71 : i32 to index
          %74 = arith.index_cast %48 : i32 to index
          %75 = arith.index_cast %47 : i32 to index
          %76 = affine.apply #map2()[%75, %72, %73, %74]
          %reinterpret_cast_5 = memref.reinterpret_cast %arg9 to offset: [%76], sizes: [32, 128], strides: [128, 1] : memref<?xf32, #hivm.address_space<gm>> to memref<32x128xf32, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
          %77 = affine.max #map3()[%74]
          %78 = affine.min #map4()[%77, %74]
          %79 = affine.apply #map5()[%78, %74]
          %80 = affine.max #map3()[%75]
          %81 = affine.min #map6()[%80, %75]
          %82 = affine.apply #map5()[%81, %75]
          %83 = affine.min #map7()[%78, %74]
          %84 = affine.max #map8()[%83]
          %85 = affine.min #map9()[%81, %75]
          %86 = affine.max #map8()[%85]
          %87 = arith.cmpi slt, %84, %c32 : index
          %88 = arith.cmpi slt, %86, %c128 : index
          %89 = arith.ori %87, %88 : i1
          %subview = memref.subview %reinterpret_cast_5[0, 0] [%84, %86] [1, 1] : memref<32x128xf32, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x?xf32, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
          %subview_6 = memref.subview %24[0, 0] [%84, %86] [1, 1] : memref<32x128xf32, #hivm.address_space<ub>> to memref<?x?xf32, strided<[128, 1]>, #hivm.address_space<ub>>
          scf.if %89 {
            hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
            hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
            %collapse_shape = memref.collapse_shape %24 [[0, 1]] : memref<32x128xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
            hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
            hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
            %cast_8 = memref.cast %collapse_shape : memref<4096xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            func.call @broadcast_scalar_float_to_1d(%cst_0, %cast_8) : (f32, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>) -> ()
            hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
            hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
          } {hivm.unlikely_condition}
          hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_MTE2>, <EVENT_ID0>]
          hivm.hir.pipe_barrier[<PIPE_MTE2>]
          %cast = memref.cast %subview : memref<?x?xf32, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<gm>>
          %cast_7 = memref.cast %subview_6 : memref<?x?xf32, strided<[128, 1]>, #hivm.address_space<ub>> to memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<ub>>
          func.call @load_gm_to_ubuf_2d_float(%cast, %cast_7, %c2_i32, %cst_0, %c0) : (memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<gm>>, memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<ub>>, i32, f32, index) -> ()
          %90 = arith.index_cast %52 : i64 to index
          %91 = arith.index_cast %62 : i64 to index
          %92 = arith.index_cast %56 : i64 to index
          %93 = arith.cmpi slt, %82, %c128 : index
          %94 = arith.cmpi slt, %79, %c32 : index
          hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
          hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID2>]
          %95:7 = scf.for %arg21 = %c0_i64 to %45 step %c1_i64 iter_args(%arg22 = %24, %arg23 = %55, %arg24 = %55, %arg25 = %75, %arg26 = %75, %arg27 = %74, %arg28 = %74) -> (memref<32x128xf32, #hivm.address_space<ub>>, i64, i64, index, index, index, index)  : i64 {
            %96 = arith.index_cast %arg21 : i64 to index
            %97 = arith.index_cast %45 : i64 to index
            %98 = arith.index_cast %arg20 : i32 to index
            %99 = arith.index_cast %17 : i32 to index
            %100 = affine.apply #map10()[%96, %97, %98, %99]
            %101 = arith.index_cast %100 : index to i64
            %102 = arith.cmpi eq, %101, %c1_i64 : i64
            %103 = arith.select %102, %3, %2 : memref<32xbf16, #hivm.address_space<ub>>
            %104 = arith.index_cast %arg21 : i64 to index
            %105 = arith.index_cast %45 : i64 to index
            %106 = arith.index_cast %arg20 : i32 to index
            %107 = arith.index_cast %17 : i32 to index
            %108 = affine.apply #map10()[%104, %105, %106, %107]
            %109 = arith.index_cast %108 : index to i64
            %110 = arith.cmpi eq, %109, %c1_i64 : i64
            %111 = arith.select %110, %7, %6 : memref<32xbf16, #hivm.address_space<ub>>
            %112 = arith.index_cast %arg21 : i64 to index
            %113 = arith.index_cast %45 : i64 to index
            %114 = arith.index_cast %arg20 : i32 to index
            %115 = arith.index_cast %17 : i32 to index
            %116 = affine.apply #map10()[%112, %113, %114, %115]
            %117 = arith.index_cast %116 : index to i64
            %118 = arith.cmpi eq, %117, %c1_i64 : i64
            %119 = arith.select %118, %9, %8 : memref<128xbf16, #hivm.address_space<ub>>
            %120 = arith.index_cast %arg21 : i64 to index
            %121 = arith.index_cast %45 : i64 to index
            %122 = arith.index_cast %arg20 : i32 to index
            %123 = arith.index_cast %17 : i32 to index
            %124 = affine.apply #map10()[%120, %121, %122, %123]
            %125 = arith.index_cast %124 : index to i64
            %126 = arith.cmpi eq, %125, %c1_i64 : i64
            %127 = arith.select %126, %11, %10 : memref<128xbf16, #hivm.address_space<ub>>
            %128 = arith.index_cast %arg21 : i64 to index
            %129 = arith.index_cast %45 : i64 to index
            %130 = arith.index_cast %arg20 : i32 to index
            %131 = arith.index_cast %17 : i32 to index
            %132 = affine.apply #map10()[%128, %129, %130, %131]
            %133 = arith.index_cast %132 : index to i64
            %134 = arith.cmpi eq, %133, %c1_i64 : i64
            %135 = arith.select %134, %13, %12 : memref<32x1xf32, #hivm.address_space<ub>>
            %136 = arith.index_cast %arg21 : i64 to index
            %137 = arith.index_cast %45 : i64 to index
            %138 = arith.index_cast %arg20 : i32 to index
            %139 = arith.index_cast %17 : i32 to index
            %140 = affine.apply #map10()[%136, %137, %138, %139]
            %141 = arith.index_cast %140 : index to i1
            %142 = arith.select %141, %c1_i64, %c2_i64 : i64
            %143 = arith.index_cast %arg24 : i64 to index
            %reinterpret_cast_8 = memref.reinterpret_cast %arg7 to offset: [%143], sizes: [1], strides: [1] : memref<?xbf16, #hivm.address_space<gm>> to memref<1xbf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
            %144 = arith.index_cast %arg23 : i64 to index
            %reinterpret_cast_9 = memref.reinterpret_cast %arg6 to offset: [%144], sizes: [1], strides: [1] : memref<?xf32, #hivm.address_space<gm>> to memref<1xf32, strided<[1], offset: ?>, #hivm.address_space<gm>>
            %145 = affine.apply #map11()[%90, %arg25]
            %reinterpret_cast_10 = memref.reinterpret_cast %arg3 to offset: [%145], sizes: [128], strides: [1] : memref<?xbf16, #hivm.address_space<gm>> to memref<128xbf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
            %146 = affine.apply #map11()[%90, %arg26]
            %reinterpret_cast_11 = memref.reinterpret_cast %arg4 to offset: [%146], sizes: [128], strides: [1] : memref<?xbf16, #hivm.address_space<gm>> to memref<128xbf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
            %147 = affine.apply #map11()[%91, %arg27]
            %reinterpret_cast_12 = memref.reinterpret_cast %arg8 to offset: [%147], sizes: [32], strides: [1] : memref<?xbf16, #hivm.address_space<gm>> to memref<32xbf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
            %148 = affine.apply #map11()[%92, %arg28]
            %reinterpret_cast_13 = memref.reinterpret_cast %arg5 to offset: [%148], sizes: [32], strides: [1] : memref<?xbf16, #hivm.address_space<gm>> to memref<32xbf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
            %subview_14 = memref.subview %reinterpret_cast_10[0] [%82] [1] : memref<128xbf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xbf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
            %subview_15 = memref.subview %127[0] [%82] [1] : memref<128xbf16, #hivm.address_space<ub>> to memref<?xbf16, strided<[1]>, #hivm.address_space<ub>>
            scf.if %93 {
              %cast_110 = memref.cast %127 : memref<128xbf16, #hivm.address_space<ub>> to memref<?xbf16, strided<[?], offset: ?>, #hivm.address_space<ub>>
              func.call @broadcast_scalar_bfloat16_t_to_1d(%cst, %cast_110) : (bf16, memref<?xbf16, strided<[?], offset: ?>, #hivm.address_space<ub>>) -> ()
              hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
              hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
            } {hivm.unlikely_condition}
            %cast_16 = memref.cast %subview_14 : memref<?xbf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xbf16, strided<[?], offset: ?>, #hivm.address_space<gm>>
            %cast_17 = memref.cast %subview_15 : memref<?xbf16, strided<[1]>, #hivm.address_space<ub>> to memref<?xbf16, strided<[?], offset: ?>, #hivm.address_space<ub>>
            func.call @load_gm_to_ubuf_1d_bfloat16_t(%cast_16, %cast_17, %c2_i32, %cst, %c0) : (memref<?xbf16, strided<[?], offset: ?>, #hivm.address_space<gm>>, memref<?xbf16, strided<[?], offset: ?>, #hivm.address_space<ub>>, i32, bf16, index) -> ()
            hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
            %149 = hivm.hir.pointer_cast(%c256_i64) : memref<128xf32, #hivm.address_space<ub>>
            hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
            %cast_18 = memref.cast %127 : memref<128xbf16, #hivm.address_space<ub>> to memref<?xbf16, strided<[?], offset: ?>, #hivm.address_space<ub>>
            %cast_19 = memref.cast %149 : memref<128xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            func.call @vcast_bfloat16_t_to_float_1d_with_mode(%cast_18, %cast_19, %c0_i32) : (memref<?xbf16, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, i32) -> ()
            %subview_20 = memref.subview %reinterpret_cast_11[0] [%82] [1] : memref<128xbf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xbf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
            %subview_21 = memref.subview %119[0] [%82] [1] : memref<128xbf16, #hivm.address_space<ub>> to memref<?xbf16, strided<[1]>, #hivm.address_space<ub>>
            scf.if %93 {
              %cast_110 = memref.cast %119 : memref<128xbf16, #hivm.address_space<ub>> to memref<?xbf16, strided<[?], offset: ?>, #hivm.address_space<ub>>
              func.call @broadcast_scalar_bfloat16_t_to_1d(%cst, %cast_110) : (bf16, memref<?xbf16, strided<[?], offset: ?>, #hivm.address_space<ub>>) -> ()
              hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
              hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
            } {hivm.unlikely_condition}
            %cast_22 = memref.cast %subview_20 : memref<?xbf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xbf16, strided<[?], offset: ?>, #hivm.address_space<gm>>
            %cast_23 = memref.cast %subview_21 : memref<?xbf16, strided<[1]>, #hivm.address_space<ub>> to memref<?xbf16, strided<[?], offset: ?>, #hivm.address_space<ub>>
            func.call @load_gm_to_ubuf_1d_bfloat16_t(%cast_22, %cast_23, %c2_i32, %cst, %c0) : (memref<?xbf16, strided<[?], offset: ?>, #hivm.address_space<gm>>, memref<?xbf16, strided<[?], offset: ?>, #hivm.address_space<ub>>, i32, bf16, index) -> ()
            hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
            %150 = hivm.hir.pointer_cast(%c1024_i64) : memref<128xf32, #hivm.address_space<ub>>
            hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
            %cast_24 = memref.cast %119 : memref<128xbf16, #hivm.address_space<ub>> to memref<?xbf16, strided<[?], offset: ?>, #hivm.address_space<ub>>
            %cast_25 = memref.cast %150 : memref<128xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            func.call @vcast_bfloat16_t_to_float_1d_with_mode(%cast_24, %cast_25, %c0_i32) : (memref<?xbf16, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, i32) -> ()
            %subview_26 = memref.subview %reinterpret_cast_13[0] [%79] [1] : memref<32xbf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xbf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
            %subview_27 = memref.subview %111[0] [%79] [1] : memref<32xbf16, #hivm.address_space<ub>> to memref<?xbf16, strided<[1]>, #hivm.address_space<ub>>
            scf.if %94 {
              %cast_110 = memref.cast %111 : memref<32xbf16, #hivm.address_space<ub>> to memref<?xbf16, strided<[?], offset: ?>, #hivm.address_space<ub>>
              func.call @broadcast_scalar_bfloat16_t_to_1d(%cst, %cast_110) : (bf16, memref<?xbf16, strided<[?], offset: ?>, #hivm.address_space<ub>>) -> ()
              hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
              hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
            } {hivm.unlikely_condition}
            %cast_28 = memref.cast %subview_26 : memref<?xbf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xbf16, strided<[?], offset: ?>, #hivm.address_space<gm>>
            %cast_29 = memref.cast %subview_27 : memref<?xbf16, strided<[1]>, #hivm.address_space<ub>> to memref<?xbf16, strided<[?], offset: ?>, #hivm.address_space<ub>>
            func.call @load_gm_to_ubuf_1d_bfloat16_t(%cast_28, %cast_29, %c2_i32, %cst, %c0) : (memref<?xbf16, strided<[?], offset: ?>, #hivm.address_space<gm>>, memref<?xbf16, strided<[?], offset: ?>, #hivm.address_space<ub>>, i32, bf16, index) -> ()
            hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
            %151 = hivm.hir.pointer_cast(%c1600_i64) : memref<32xf32, #hivm.address_space<ub>>
            hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
            %cast_30 = memref.cast %111 : memref<32xbf16, #hivm.address_space<ub>> to memref<?xbf16, strided<[?], offset: ?>, #hivm.address_space<ub>>
            %cast_31 = memref.cast %151 : memref<32xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            func.call @vcast_bfloat16_t_to_float_1d_with_mode(%cast_30, %cast_31, %c0_i32) : (memref<?xbf16, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, i32) -> ()
            %152 = hivm.hir.pointer_cast(%c1728_i64) : memref<128xf32, #hivm.address_space<ub>>
            hivm.hir.pipe_barrier[<PIPE_V>]
            %153 = hivm.hir.pointer_cast(%c0_i64) : memref<0xf32, #hivm.address_space<ub>>
            %cast_32 = memref.cast %149 : memref<128xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            %cast_33 = memref.cast %149 : memref<128xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            %cast_34 = memref.cast %152 : memref<128xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            %cast_35 = memref.cast %153 : memref<0xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            func.call @vmul_1d_float(%cast_32, %cast_33, %cast_34, %cast_35) : (memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>) -> ()
            %154 = hivm.hir.pointer_cast(%c2240_i64) : memref<1xf32, #hivm.address_space<ub>>
            %155 = hivm.hir.pointer_cast(%c2272_i64) : memref<64xf32, #hivm.address_space<ub>>
            hivm.hir.pipe_barrier[<PIPE_V>]
            %cast_36 = memref.cast %152 : memref<128xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            %cast_37 = memref.cast %154 : memref<1xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            %cast_38 = memref.cast %155 : memref<64xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            func.call @enablevc_reduce_sum_r_float(%cast_36, %cast_37, %cast_38, %cst_0) : (memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, f32) -> ()
            hivm.hir.set_flag[<PIPE_V>, <PIPE_S>, <EVENT_ID0>]
            hivm.hir.wait_flag[<PIPE_V>, <PIPE_S>, <EVENT_ID0>]
            %156 = memref.load %154[%c0] : memref<1xf32, #hivm.address_space<ub>>
            %157 = arith.addf %156, %cst_1 : f32
            %158 = math.sqrt %157 : f32
            %159 = hivm.hir.pointer_cast(%c256_i64) : memref<128xf32, #hivm.address_space<ub>>
            %160 = hivm.hir.pointer_cast(%c2528_i64) : memref<8xf32, #hivm.address_space<ub>>
            %cast_39 = memref.cast %149 : memref<128xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            %cast_40 = memref.cast %159 : memref<128xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            %cast_41 = memref.cast %160 : memref<8xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            func.call @vdiv_vs_1d_float(%cast_39, %158, %cast_40, %cast_41) : (memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, f32, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>) -> ()
            %161 = hivm.hir.pointer_cast(%c2560_i64) : memref<128xf32, #hivm.address_space<ub>>
            %162 = hivm.hir.pointer_cast(%c0_i64) : memref<0xf32, #hivm.address_space<ub>>
            %cast_42 = memref.cast %150 : memref<128xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            %cast_43 = memref.cast %150 : memref<128xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            %cast_44 = memref.cast %161 : memref<128xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            %cast_45 = memref.cast %162 : memref<0xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            func.call @vmul_1d_float(%cast_42, %cast_43, %cast_44, %cast_45) : (memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>) -> ()
            %163 = hivm.hir.pointer_cast(%c3072_i64) : memref<1xf32, #hivm.address_space<ub>>
            %164 = hivm.hir.pointer_cast(%c3104_i64) : memref<64xf32, #hivm.address_space<ub>>
            hivm.hir.pipe_barrier[<PIPE_V>]
            %cast_46 = memref.cast %161 : memref<128xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            %cast_47 = memref.cast %163 : memref<1xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            %cast_48 = memref.cast %164 : memref<64xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            func.call @enablevc_reduce_sum_r_float(%cast_46, %cast_47, %cast_48, %cst_0) : (memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, f32) -> ()
            hivm.hir.set_flag[<PIPE_V>, <PIPE_S>, <EVENT_ID0>]
            hivm.hir.wait_flag[<PIPE_V>, <PIPE_S>, <EVENT_ID0>]
            %165 = memref.load %163[%c0] : memref<1xf32, #hivm.address_space<ub>>
            %166 = arith.addf %165, %cst_1 : f32
            %167 = math.sqrt %166 : f32
            %168 = hivm.hir.pointer_cast(%c1024_i64) : memref<128xf32, #hivm.address_space<ub>>
            %169 = hivm.hir.pointer_cast(%c3360_i64) : memref<8xf32, #hivm.address_space<ub>>
            %cast_49 = memref.cast %150 : memref<128xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            %cast_50 = memref.cast %168 : memref<128xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            %cast_51 = memref.cast %169 : memref<8xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            func.call @vdiv_vs_1d_float(%cast_49, %167, %cast_50, %cast_51) : (memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, f32, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>) -> ()
            %170 = hivm.hir.pointer_cast(%c256_i64) : memref<128xf32, #hivm.address_space<ub>>
            %171 = hivm.hir.pointer_cast(%c0_i64) : memref<0xf32, #hivm.address_space<ub>>
            %cast_52 = memref.cast %159 : memref<128xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            %cast_53 = memref.cast %170 : memref<128xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            %cast_54 = memref.cast %171 : memref<0xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            func.call @vmuls_vs_1d_float(%cast_52, %arg14, %cast_53, %cast_54) : (memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, f32, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>) -> ()
            %172 = memref.load %reinterpret_cast_9[%c0] {markDCacheInvalidatePatternVisited = 0 : i32} : memref<1xf32, strided<[1], offset: ?>, #hivm.address_space<gm>>
            %173 = hivm.hir.pointer_cast(%c3392_i64) : memref<1xf32, #hivm.address_space<ub>>
            memref.store %172, %173[%c0] : memref<1xf32, #hivm.address_space<ub>>
            hivm.hir.set_flag[<PIPE_S>, <PIPE_V>, <EVENT_ID0>]
            %174 = hivm.hir.pointer_cast(%c3392_i64) : memref<1xf32, #hivm.address_space<ub>>
            hivm.hir.wait_flag[<PIPE_S>, <PIPE_V>, <EVENT_ID0>]
            %175 = hivm.hir.pointer_cast(%c0_i64) : memref<0xf32, #hivm.address_space<ub>>
            %cast_55 = memref.cast %173 : memref<1xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            %cast_56 = memref.cast %174 : memref<1xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            %cast_57 = memref.cast %175 : memref<0xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            func.call @vexp_1d_float(%cast_55, %cast_56, %cast_57) : (memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>) -> ()
            hivm.hir.set_flag[<PIPE_V>, <PIPE_S>, <EVENT_ID0>]
            hivm.hir.wait_flag[<PIPE_V>, <PIPE_S>, <EVENT_ID0>]
            %176 = memref.load %174[%c0] : memref<1xf32, #hivm.address_space<ub>>
            %177 = hivm.hir.pointer_cast(%c3424_i64) : memref<32x128xf32, #hivm.address_space<ub>>
            %collapse_shape = memref.collapse_shape %arg22 [[0, 1]] : memref<32x128xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
            %collapse_shape_58 = memref.collapse_shape %177 [[0, 1]] : memref<32x128xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
            %178 = hivm.hir.pointer_cast(%c0_i64) : memref<0xf32, #hivm.address_space<ub>>
            %cast_59 = memref.cast %collapse_shape : memref<4096xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            %cast_60 = memref.cast %collapse_shape_58 : memref<4096xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            %cast_61 = memref.cast %178 : memref<0xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            func.call @vmuls_vs_1d_float(%cast_59, %176, %cast_60, %cast_61) : (memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, f32, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>) -> ()
            %expand_shape = memref.expand_shape %168 [[0, 1]] output_shape [1, 128] : memref<128xf32, #hivm.address_space<ub>> into memref<1x128xf32, #hivm.address_space<ub>>
            %179 = hivm.hir.pointer_cast(%c19808_i64) : memref<32x128xf32, #hivm.address_space<ub>>
            hivm.hir.pipe_barrier[<PIPE_V>]
            %180 = hivm.hir.pointer_cast(%c0_i64) : memref<0xf32, #hivm.address_space<ub>>
            %cast_62 = memref.cast %177 : memref<32x128xf32, #hivm.address_space<ub>> to memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<ub>>
            %cast_63 = memref.cast %expand_shape : memref<1x128xf32, #hivm.address_space<ub>> to memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<ub>>
            %cast_64 = memref.cast %179 : memref<32x128xf32, #hivm.address_space<ub>> to memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<ub>>
            %cast_65 = memref.cast %180 : memref<0xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            func.call @vmul_2d_float(%cast_62, %cast_63, %cast_64, %cast_65) : (memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<ub>>, memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<ub>>, memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>) -> ()
            %181 = hivm.hir.pointer_cast(%c36192_i64) : memref<32x1xf32, #hivm.address_space<ub>>
            %182 = hivm.hir.pointer_cast(%c36320_i64) : memref<2048xf32, #hivm.address_space<ub>>
            hivm.hir.pipe_barrier[<PIPE_V>]
            %cast_66 = memref.cast %179 : memref<32x128xf32, #hivm.address_space<ub>> to memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<ub>>
            %cast_67 = memref.cast %181 : memref<32x1xf32, #hivm.address_space<ub>> to memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<ub>>
            %cast_68 = memref.cast %182 : memref<2048xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            func.call @enablevc_reduce_sum_ar_float(%cast_66, %cast_67, %cast_68, %cst_0) : (memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<ub>>, memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, f32) -> ()
            %collapse_shape_69 = memref.collapse_shape %181 [[0, 1]] : memref<32x1xf32, #hivm.address_space<ub>> into memref<32xf32, #hivm.address_space<ub>>
            %183 = hivm.hir.pointer_cast(%c1600_i64) : memref<32xf32, #hivm.address_space<ub>>
            hivm.hir.pipe_barrier[<PIPE_V>]
            %184 = hivm.hir.pointer_cast(%c0_i64) : memref<0xf32, #hivm.address_space<ub>>
            %cast_70 = memref.cast %151 : memref<32xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            %cast_71 = memref.cast %collapse_shape_69 : memref<32xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            %cast_72 = memref.cast %183 : memref<32xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            %cast_73 = memref.cast %184 : memref<0xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            func.call @vsub_1d_float(%cast_70, %cast_71, %cast_72, %cast_73) : (memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>) -> ()
            %185 = memref.load %reinterpret_cast_8[%c0] {markDCacheInvalidatePatternVisited = 0 : i32} : memref<1xbf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
            %186 = hivm.hir.pointer_cast(%c44512_i64) : memref<1xbf16, #hivm.address_space<ub>>
            memref.store %185, %186[%c0] : memref<1xbf16, #hivm.address_space<ub>>
            hivm.hir.set_flag[<PIPE_S>, <PIPE_V>, <EVENT_ID0>]
            %187 = hivm.hir.pointer_cast(%c44544_i64) : memref<1xf32, #hivm.address_space<ub>>
            hivm.hir.wait_flag[<PIPE_S>, <PIPE_V>, <EVENT_ID0>]
            %cast_74 = memref.cast %186 : memref<1xbf16, #hivm.address_space<ub>> to memref<?xbf16, strided<[?], offset: ?>, #hivm.address_space<ub>>
            %cast_75 = memref.cast %187 : memref<1xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            func.call @vcast_bfloat16_t_to_float_1d_with_mode(%cast_74, %cast_75, %c0_i32) : (memref<?xbf16, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, i32) -> ()
            hivm.hir.set_flag[<PIPE_V>, <PIPE_S>, <EVENT_ID0>]
            hivm.hir.wait_flag[<PIPE_V>, <PIPE_S>, <EVENT_ID0>]
            %188 = memref.load %187[%c0] : memref<1xf32, #hivm.address_space<ub>>
            %189 = hivm.hir.pointer_cast(%c1600_i64) : memref<32xf32, #hivm.address_space<ub>>
            %190 = hivm.hir.pointer_cast(%c0_i64) : memref<0xf32, #hivm.address_space<ub>>
            %cast_76 = memref.cast %183 : memref<32xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            %cast_77 = memref.cast %189 : memref<32xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            %cast_78 = memref.cast %190 : memref<0xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            func.call @vmuls_vs_1d_float(%cast_76, %188, %cast_77, %cast_78) : (memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, f32, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>) -> ()
            %expand_shape_79 = memref.expand_shape %189 [[0, 1]] output_shape [32, 1] : memref<32xf32, #hivm.address_space<ub>> into memref<32x1xf32, #hivm.address_space<ub>>
            %191 = hivm.hir.pointer_cast(%c44576_i64) : memref<32x128xf32, #hivm.address_space<ub>>
            %192 = hivm.hir.pointer_cast(%c60960_i64) : memref<256xf32, #hivm.address_space<ub>>
            hivm.hir.pipe_barrier[<PIPE_V>]
            %cast_80 = memref.cast %expand_shape_79 : memref<32x1xf32, #hivm.address_space<ub>> to memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<ub>>
            %cast_81 = memref.cast %expand_shape : memref<1x128xf32, #hivm.address_space<ub>> to memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<ub>>
            %cast_82 = memref.cast %191 : memref<32x128xf32, #hivm.address_space<ub>> to memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<ub>>
            %cast_83 = memref.cast %192 : memref<256xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            func.call @vmul_2d_float(%cast_80, %cast_81, %cast_82, %cast_83) : (memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<ub>>, memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<ub>>, memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>) -> ()
            %collapse_shape_84 = memref.collapse_shape %191 [[0, 1]] : memref<32x128xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
            %collapse_shape_85 = memref.collapse_shape %30 [[0, 1]] : memref<32x128xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
            hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
            hivm.hir.pipe_barrier[<PIPE_V>]
            %193 = hivm.hir.pointer_cast(%c0_i64) : memref<0xf32, #hivm.address_space<ub>>
            %cast_86 = memref.cast %collapse_shape_58 : memref<4096xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            %cast_87 = memref.cast %collapse_shape_84 : memref<4096xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            %cast_88 = memref.cast %collapse_shape_85 : memref<4096xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            %cast_89 = memref.cast %193 : memref<0xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            func.call @vadd_1d_float(%cast_86, %cast_87, %cast_88, %cast_89) : (memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>) -> ()
            %expand_shape_90 = memref.expand_shape %170 [[0, 1]] output_shape [1, 128] : memref<128xf32, #hivm.address_space<ub>> into memref<1x128xf32, #hivm.address_space<ub>>
            %194 = hivm.hir.pointer_cast(%c78368_i64) : memref<32x128xf32, #hivm.address_space<ub>>
            hivm.hir.pipe_barrier[<PIPE_V>]
            %195 = hivm.hir.pointer_cast(%c0_i64) : memref<0xf32, #hivm.address_space<ub>>
            %cast_91 = memref.cast %30 : memref<32x128xf32, #hivm.address_space<ub>> to memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<ub>>
            %cast_92 = memref.cast %expand_shape_90 : memref<1x128xf32, #hivm.address_space<ub>> to memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<ub>>
            %cast_93 = memref.cast %194 : memref<32x128xf32, #hivm.address_space<ub>> to memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<ub>>
            %cast_94 = memref.cast %195 : memref<0xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            func.call @vmul_2d_float(%cast_91, %cast_92, %cast_93, %cast_94) : (memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<ub>>, memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<ub>>, memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>) -> ()
            %196 = hivm.hir.pointer_cast(%c94880_i64) : memref<2048xf32, #hivm.address_space<ub>>
            hivm.hir.pipe_barrier[<PIPE_V>]
            %cast_95 = memref.cast %194 : memref<32x128xf32, #hivm.address_space<ub>> to memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<ub>>
            %cast_96 = memref.cast %135 : memref<32x1xf32, #hivm.address_space<ub>> to memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<ub>>
            %cast_97 = memref.cast %196 : memref<2048xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            func.call @enablevc_reduce_sum_ar_float(%cast_95, %cast_96, %cast_97, %cst_0) : (memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<ub>>, memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<ub>>, memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, f32) -> ()
            %collapse_shape_98 = memref.collapse_shape %135 [[0, 1]] : memref<32x1xf32, #hivm.address_space<ub>> into memref<32xf32, #hivm.address_space<ub>>
            hivm.hir.pipe_barrier[<PIPE_V>]
            %cast_99 = memref.cast %collapse_shape_98 : memref<32xf32, #hivm.address_space<ub>> to memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>
            %cast_100 = memref.cast %103 : memref<32xbf16, #hivm.address_space<ub>> to memref<?xbf16, strided<[?], offset: ?>, #hivm.address_space<ub>>
            func.call @vcast_float_to_bfloat16_t_1d_with_mode(%cast_99, %cast_100, %c0_i32) : (memref<?xf32, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xbf16, strided<[?], offset: ?>, #hivm.address_space<ub>>, i32) -> ()
            hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
            %subview_101 = memref.subview %103[0] [%79] [1] : memref<32xbf16, #hivm.address_space<ub>> to memref<?xbf16, strided<[1]>, #hivm.address_space<ub>>
            %subview_102 = memref.subview %reinterpret_cast_12[0] [%79] [1] : memref<32xbf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xbf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
            hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
            hivm.hir.pipe_barrier[<PIPE_MTE3>]
            %cast_103 = memref.cast %subview_101 : memref<?xbf16, strided<[1]>, #hivm.address_space<ub>> to memref<?xbf16, strided<[?], offset: ?>, #hivm.address_space<ub>>
            %cast_104 = memref.cast %subview_102 : memref<?xbf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xbf16, strided<[?], offset: ?>, #hivm.address_space<gm>>
            func.call @store_ubuf_to_gm_1d_bfloat16_t(%cast_103, %cast_104, %c0_i32) : (memref<?xbf16, strided<[?], offset: ?>, #hivm.address_space<ub>>, memref<?xbf16, strided<[?], offset: ?>, #hivm.address_space<gm>>, i32) -> ()
            %197 = arith.addi %64, %arg21 : i64
            %198 = arith.addi %197, %c1_i64 : i64
            %199 = arith.remsi %198, %c4_i64 : i64
            %200 = arith.addi %67, %199 : i64
            %201 = arith.muli %200, %c262144_i64 : i64
            %202 = arith.index_cast %201 : i64 to index
            %203 = affine.apply #map2()[%75, %202, %73, %74]
            %reinterpret_cast_105 = memref.reinterpret_cast %arg10 to offset: [%203], sizes: [32, 128], strides: [128, 1] : memref<?xf32, #hivm.address_space<gm>> to memref<32x128xf32, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
            %subview_106 = memref.subview %30[0, 0] [%84, %86] [1, 1] : memref<32x128xf32, #hivm.address_space<ub>> to memref<?x?xf32, strided<[128, 1]>, #hivm.address_space<ub>>
            %subview_107 = memref.subview %reinterpret_cast_105[0, 0] [%84, %86] [1, 1] : memref<32x128xf32, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x?xf32, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
            %cast_108 = memref.cast %subview_106 : memref<?x?xf32, strided<[128, 1]>, #hivm.address_space<ub>> to memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<ub>>
            %cast_109 = memref.cast %subview_107 : memref<?x?xf32, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<gm>>
            func.call @store_ubuf_to_gm_2d_float(%cast_108, %cast_109, %c0_i32) : (memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<ub>>, memref<?x?xf32, strided<[?, ?], offset: ?>, #hivm.address_space<gm>>, i32) -> ()
            hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
            %204 = arith.addi %arg23, %c16_i64 : i64
            %205 = arith.addi %arg24, %c16_i64 : i64
            %206 = affine.apply #map12()[%arg25]
            %207 = affine.apply #map12()[%arg26]
            %208 = affine.apply #map13()[%arg27]
            %209 = affine.apply #map13()[%arg28]
            scf.yield %30, %204, %205, %206, %207, %208, %209 : memref<32x128xf32, #hivm.address_space<ub>>, i64, i64, index, index, index, index
          }
          hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
          hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID2>]
          hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_MTE2>, <EVENT_ID0>]
        }
      } {pipeline.veconly}
    } {autoblockify.subloop}
    hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_MTE2>, <EVENT_ID0>]
    hivm.hir.pipe_barrier[<PIPE_ALL>]
    return
  }
}
